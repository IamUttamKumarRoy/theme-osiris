/* Aether Full Admin Template JS */
(function(){
  'use strict';
  const allowedThemes=['light','dark','obsidian','vercel','deep-space','netflix','microsoft','google','apple','vscode','aws','royal','spotify','figma','slack','airbnb','uber','sapphire','nebula','aurora','phoenix','sakura','sunset','rose','slate','emerald','ocean','midnight-teal','cyber'];
  const labels={light:'Light',dark:'Dark',obsidian:'Obsidian',vercel:'Vercel Black','deep-space':'Deep Space',netflix:'Netflix Red',microsoft:'Microsoft Fluent',google:'Google Material 3',apple:'Apple SF',vscode:'VSCode Dark',aws:'AWS Orange',royal:'Royal',spotify:'Spotify Green',figma:'Figma Purple',slack:'Slack Sidebar',airbnb:'Airbnb Pink',uber:'Uber Black',sapphire:'Sapphire Glass',nebula:'Nebula',aurora:'Aurora',phoenix:'Phoenix',sakura:'Sakura',sunset:'Sunset',rose:'Rose',slate:'Slate',emerald:'Emerald',ocean:'Ocean','midnight-teal':'Midnight Teal',cyber:'Cyber'};
  const root=document.documentElement, wrapper=document.getElementById('adminWrapper'), sidebar=document.getElementById('sidebar'), sidebarToggle=document.getElementById('sidebarCollapse'), overlay=document.getElementById('sidebarOverlay'), header=document.querySelector('.admin-header');
  const swatches=Array.from(document.querySelectorAll('.theme-swatch')), themeLabel=document.getElementById('themePreviewLabel'), themeSearch=document.getElementById('themeSearch'), noResults=document.getElementById('themeNoResults');
  const commandBackdrop=document.getElementById('commandPaletteBackdrop'), commandInput=document.getElementById('commandPaletteInput'), commandList=document.getElementById('commandPaletteList');

  function accent(){return getComputedStyle(root).getPropertyValue('--t-accent').trim()||'#38bdf8'}
  function applyTheme(theme,label){
    if(!allowedThemes.includes(theme)) return;
    root.setAttribute('data-theme',theme);
    root.style.colorScheme=['light','microsoft','google','apple','aws','sapphire','aurora','sakura','sunset','rose','slate','emerald','ocean'].includes(theme)?'light':'dark';
    try{localStorage.setItem('aether-theme',theme)}catch(_){}
    swatches.forEach(btn=>{const active=btn.dataset.theme===theme;btn.classList.toggle('is-active',active);btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',active?'true':'false')});
    if(themeLabel) themeLabel.textContent=label||labels[theme]||theme;
    const meta=document.getElementById('metaThemeColor'); if(meta) requestAnimationFrame(()=>meta.setAttribute('content',accent()));
    document.querySelectorAll('.js-theme-avatar[data-avatar-name]').forEach(img=>{img.src='https://ui-avatars.com/api/?name='+encodeURIComponent(img.dataset.avatarName||'User')+'&background='+accent().replace('#','')+'&color=0f172a&bold=true&size=34'});
  }
  function initTheme(){
    let saved=null;try{saved=localStorage.getItem('aether-theme')}catch(_){}
    const initial=allowedThemes.includes(saved)?saved:(allowedThemes.includes(root.getAttribute('data-theme'))?root.getAttribute('data-theme'):'light');
    applyTheme(initial,labels[initial]);
    swatches.forEach(btn=>{
      btn.setAttribute('aria-pressed','false');
      btn.addEventListener('click',()=>applyTheme(btn.dataset.theme,btn.title||labels[btn.dataset.theme]));
      btn.addEventListener('mouseenter',()=>{if(themeLabel)themeLabel.textContent=btn.title||labels[btn.dataset.theme]||btn.dataset.theme});
    });
    themeSearch?.addEventListener('input',()=>{
      const q=themeSearch.value.trim().toLowerCase();let visible=0;
      swatches.forEach(btn=>{const text=[btn.title,btn.dataset.theme,labels[btn.dataset.theme]].join(' ').toLowerCase();const ok=text.includes(q);btn.hidden=!ok;if(ok)visible++});
      document.querySelectorAll('.theme-grid').forEach(grid=>{grid.hidden=!Array.from(grid.querySelectorAll('.theme-swatch')).some(btn=>!btn.hidden)});
      document.querySelectorAll('.theme-group-label').forEach(label=>{const grid=label.nextElementSibling;label.hidden=grid&&grid.classList.contains('theme-grid')?grid.hidden:false});
      if(noResults) noResults.hidden=visible>0;
    });
  }

  function openMobileSidebar(){sidebar?.classList.add('sidebar-open','active');overlay?.classList.add('active');sidebarToggle?.setAttribute('aria-expanded','true');document.body.style.overflow='hidden'}
  function closeMobileSidebar(){sidebar?.classList.remove('sidebar-open','active');overlay?.classList.remove('active');sidebarToggle?.setAttribute('aria-expanded','false');document.body.style.overflow=''}
  function initSidebar(){
    sidebarToggle?.addEventListener('click',()=>{
      if(window.matchMedia('(max-width: 767.98px)').matches){
        (sidebar?.classList.contains('sidebar-open')||sidebar?.classList.contains('active'))?closeMobileSidebar():openMobileSidebar();
      }else{
        wrapper?.classList.toggle('sidebar-collapsed');
        sidebarToggle.setAttribute('aria-expanded',wrapper?.classList.contains('sidebar-collapsed')?'false':'true');
      }
    });
    overlay?.addEventListener('click',closeMobileSidebar);
    window.addEventListener('resize',()=>{if(!window.matchMedia('(max-width: 767.98px)').matches)closeMobileSidebar()});
  }

  function initHeader(){function update(){header?.classList.toggle('is-scrolled',window.scrollY>8)}update();window.addEventListener('scroll',update,{passive:true})}

  const commands=[
    ['Dashboard Overview','dashboard.html','bi-speedometer2'],
    ['Leads','crm/leads.html','bi-person-lines-fill'],
    ['Lead Details','crm/lead-details.html','bi-person-badge'],
    ['Deals','crm/deals.html','bi-currency-dollar'],
    ['Deal Details','crm/deal-details.html','bi-file-earmark-richtext'],
    ['Pipeline','crm/pipeline.html','bi-kanban'],
    ['Customers','crm/customers.html','bi-building'],
    ['Customer Details','crm/customer-details.html','bi-buildings'],
    ['Activities','crm/activities.html','bi-calendar-check'],
    ['Reports','crm/reports.html','bi-graph-up-arrow'],
    ['Inventory','ecommerce/inventory.html','bi-boxes'],
    ['Coupons','ecommerce/coupons.html','bi-ticket-perforated'],
    ['Refunds','ecommerce/refunds.html','bi-arrow-counterclockwise'],
    ['Returns','ecommerce/returns.html','bi-arrow-return-left'],
    ['Shipping','ecommerce/shipping.html','bi-truck'],
    ['Payment Methods','ecommerce/payment-methods.html','bi-credit-card-2-front'],
    ['Product Reviews','ecommerce/product-reviews.html','bi-star-half'],
    ['Order Details','ecommerce/order-details.html','bi-receipt-cutoff'],
    ['Customer Details','ecommerce/customer-details.html','bi-person-badge'],
    ['Help Center','support/help-center.html','bi-life-preserver'],
    ['FAQ','support/faq.html','bi-question-circle'],
    ['Support Tickets','support/support-tickets.html','bi-ticket-detailed'],
    ['Ticket Details','support/ticket-details.html','bi-file-text'],
    ['Create Ticket','support/create-ticket.html','bi-plus-circle'],
    ['Knowledge Base','support/knowledge-base.html','bi-journal-richtext'],
    ['Blog List','blog/blog-list.html','bi-list-ul'],
    ['Blog Grid','blog/blog-grid.html','bi-grid-3x3-gap'],
    ['Blog Details','blog/blog-details.html','bi-file-richtext'],
    ['Create Post','blog/create-post.html','bi-pencil-square'],
    ['Edit Post','blog/edit-post.html','bi-pencil'],
    ['Categories','blog/categories.html','bi-tags'],
    ['Comments','blog/comments.html','bi-chat-left-text'],
    ['Media Library','media/media-library.html','bi-images'],
    ['Upload Files','media/upload-files.html','bi-cloud-upload'],
    ['File Details','media/file-details.html','bi-file-earmark-richtext'],
    ['Invoices','billing/invoices.html','bi-receipt'],
    ['Invoice Details','billing/invoice-details.html','bi-file-earmark-text'],
    ['Create Invoice','billing/create-invoice.html','bi-file-earmark-plus'],
    ['Payment History','billing/payment-history.html','bi-clock-history'],
    ['Subscriptions','billing/subscriptions.html','bi-arrow-repeat'],
    ['Subscription Details','billing/subscription-details.html','bi-file-check'],
    ['Billing Plans','billing/billing-plans.html','bi-tags'],
    ['API Documentation','developer/api-documentation.html','bi-braces'],
    ['API Keys','developer/api-keys.html','bi-key'],
    ['Webhooks','developer/webhooks.html','bi-diagram-2'],
    ['Error Logs','developer/error-logs.html','bi-bug'],
    ['System Info','developer/system-info.html','bi-pc-display'],
    ['Version Control','developer/version-control.html','bi-git']
  ];
  function renderCommands(q=''){
    if(!commandList)return;const f=q.trim().toLowerCase();const items=commands.filter(([label])=>label.toLowerCase().includes(f));
    commandList.innerHTML=items.length?items.map(([label,href,icon])=>'<a class="command-palette__item text-decoration-none" href="'+window.__aetherBase+href+'"><i class="bi '+icon+'" aria-hidden="true"></i><span>'+label+'</span></a>').join(''):'<div class="command-palette__item text-muted">No matching command found.</div>';
  }
  function openCommand(){renderCommands('');commandBackdrop?.classList.add('show');commandBackdrop?.setAttribute('aria-hidden','false');setTimeout(()=>commandInput?.focus(),30)}
  function closeCommand(){commandBackdrop?.classList.remove('show');commandBackdrop?.setAttribute('aria-hidden','true');if(commandInput)commandInput.value=''}
  function initCommand(){
    document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openCommand()}if(e.key==='Escape'){closeCommand();closeMobileSidebar()}});
    commandInput?.addEventListener('input',()=>renderCommands(commandInput.value));
    commandBackdrop?.addEventListener('click',e=>{if(e.target===commandBackdrop)closeCommand()});
  }
  function initLogout(){document.addEventListener('click',e=>{const btn=e.target.closest('.js-logout');if(!btn)return;if(confirm('Are you sure you want to log out?'))window.location.href=window.__aetherBase+'auth/login.html'})}
  document.addEventListener('DOMContentLoaded',()=>{initTheme();initSidebar();initHeader();initCommand();initLogout()});
})();


/* ThemeForest Ready Enhancements */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    var wrapper = document.getElementById('adminWrapper');
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    var sidebarToggle = document.getElementById('sidebarCollapse');
    var globalSearch = document.getElementById('globalSearchInput');
    var commandBackdrop = document.getElementById('commandPaletteBackdrop');
    var commandInput = document.getElementById('commandPaletteInput');

    /* Ensure sidebar is visible by default on desktop */
    if (wrapper && window.matchMedia('(min-width: 768px)').matches) {
      wrapper.classList.remove('sidebar-collapsed');
    }

    /* Header search opens command palette */
    function openCommandPalette() {
      if (!commandBackdrop) return;
      commandBackdrop.classList.add('show');
      commandBackdrop.setAttribute('aria-hidden', 'false');
      setTimeout(function () {
        if (commandInput) commandInput.focus();
      }, 30);
    }

    if (globalSearch) {
      globalSearch.addEventListener('focus', openCommandPalette);
      globalSearch.addEventListener('click', openCommandPalette);
    }

    /* Escape closes mobile sidebar and command palette */
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;

      if (commandBackdrop && commandBackdrop.classList.contains('show')) {
        commandBackdrop.classList.remove('show');
        commandBackdrop.setAttribute('aria-hidden', 'true');
      }

      if (sidebar && sidebar.classList.contains('sidebar-open')) {
        sidebar.classList.remove('sidebar-open', 'active');
        if (overlay) overlay.classList.remove('active');
        if (sidebarToggle) sidebarToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      }
    });

    /* Auto active link based on current file */
    var currentFile = (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
    document.querySelectorAll('.admin-sidebar__nav a.nav-link[href], .sidebarnav a.nav-link[href]').forEach(function (link) {
      var hrefFile = (link.getAttribute('href') || '').split('/').pop().toLowerCase();
      if (hrefFile === currentFile || (currentFile === 'dashboard.html' && hrefFile === 'index.html')) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
        var collapse = link.closest('.collapse');
        if (collapse) collapse.classList.add('show');
        var trigger = collapse ? document.querySelector('[data-bs-target="#' + collapse.id + '"]') : null;
        if (trigger) trigger.setAttribute('aria-expanded', 'true');
      }
    });
  });
})();
