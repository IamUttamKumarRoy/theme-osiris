Aether UI Components Pages Pack
===============================

Generated UI component demo pages: 30 pages + index.html

Included pages:
- ui-overview.html
- ui-buttons.html
- ui-cards.html
- ui-alerts.html
- ui-badges.html
- ui-avatars.html
- ui-dropdowns.html
- ui-modals.html
- ui-tabs.html
- ui-accordions.html
- ui-toasts.html
- ui-tooltips.html
- ui-popovers.html
- ui-progress.html
- ui-spinners.html
- ui-forms.html
- ui-input-groups.html
- ui-tables.html
- ui-pagination.html
- ui-breadcrumbs.html
- ui-list-groups.html
- ui-navs.html
- ui-timelines.html
- ui-empty-states.html
- ui-typography.html
- ui-icons.html
- ui-carousel.html
- ui-offcanvas.html
- ui-utilities.html
- ui-widgets.html
- index.html

Template structure:
- admin-wrapper
- admin-sidebar with branding and smooth scroll navigation
- admin-header topbar
- topbar theme dropdown with Aether themes
- alerts dropdown
- user dropdown
- admin-content main content
- admin-footer
- command palette container

Assets copied from uploaded template:
- assets/css/theme.css
- assets/css/production-ready.css
- assets/js/dashboard.js

Additional page-specific CSS:
- assets/css/ui-components-pages.css

How to use:
Open index.html in a browser, or open any UI component page directly.
