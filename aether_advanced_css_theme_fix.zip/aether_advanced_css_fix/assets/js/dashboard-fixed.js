/* ============================================================================
   Aether Dashboard Fixed Interactions
   File: assets/js/dashboard-fixed.js

   Fixes:
   - Color theme switching
   - Active swatch state
   - Theme search
   - Mobile sidebar overlay
   - Desktop sidebar collapse
   - Ctrl/Cmd + K command palette
   - Header shadow on scroll
============================================================================ */

(function () {
  'use strict';

  const allowedThemes = [
    'light', 'dark', 'obsidian', 'vercel', 'deep-space', 'netflix',
    'microsoft', 'google', 'apple', 'vscode', 'aws', 'royal',
    'spotify', 'figma', 'slack', 'airbnb', 'uber', 'sapphire',
    'nebula', 'aurora', 'phoenix', 'sakura', 'sunset', 'rose',
    'slate', 'emerald', 'ocean', 'midnight-teal', 'cyber'
  ];

  const themeLabels = {
    light: 'Light',
    dark: 'Dark',
    obsidian: 'Obsidian',
    vercel: 'Vercel Black',
    'deep-space': 'Deep Space',
    netflix: 'Netflix Red',
    microsoft: 'Microsoft Fluent',
    google: 'Google Material 3',
    apple: 'Apple SF',
    vscode: 'VSCode Dark',
    aws: 'AWS Orange',
    royal: 'Royal',
    spotify: 'Spotify Green',
    figma: 'Figma Purple',
    slack: 'Slack Sidebar',
    airbnb: 'Airbnb Pink',
    uber: 'Uber Black',
    sapphire: 'Sapphire Glass',
    nebula: 'Nebula',
    aurora: 'Aurora',
    phoenix: 'Phoenix',
    sakura: 'Sakura',
    sunset: 'Sunset',
    rose: 'Rose',
    slate: 'Slate',
    emerald: 'Emerald',
    ocean: 'Ocean',
    'midnight-teal': 'Midnight Teal',
    cyber: 'Cyber'
  };

  const root = document.documentElement;
  const adminWrapper = document.getElementById('adminWrapper');
  const sidebar = document.getElementById('sidebar');
  const sidebarToggle = document.getElementById('sidebarCollapse');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  const adminHeader = document.querySelector('.admin-header');

  const themePreviewLabel = document.getElementById('themePreviewLabel');
  const themeSearch = document.getElementById('themeSearch');
  const themeNoResults = document.getElementById('themeNoResults');
  const themeSwatches = Array.from(document.querySelectorAll('.theme-swatch'));

  const commandBackdrop = document.getElementById('commandPaletteBackdrop');
  const commandInput = document.getElementById('commandPaletteInput');
  const commandList = document.getElementById('commandPaletteList');

  function getThemeColor() {
    const value = getComputedStyle(root).getPropertyValue('--t-accent').trim();
    return value || '#38bdf8';
  }

  function applyTheme(theme, label) {
    if (!allowedThemes.includes(theme)) return;

    root.setAttribute('data-theme', theme);
    root.style.colorScheme = ['light', 'microsoft', 'google', 'apple', 'aws', 'sapphire', 'aurora', 'sakura', 'sunset', 'rose', 'slate', 'emerald', 'ocean'].includes(theme)
      ? 'light'
      : 'dark';

    try {
      localStorage.setItem('adminuk-theme', theme);
    } catch (_) {}

    themeSwatches.forEach((button) => {
      const isActive = button.dataset.theme === theme;
      button.classList.toggle('is-active', isActive);
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });

    if (themePreviewLabel) {
      themePreviewLabel.textContent = label || themeLabels[theme] || theme;
    }

    const metaThemeColor = document.getElementById('metaThemeColor');
    if (metaThemeColor) {
      requestAnimationFrame(() => {
        metaThemeColor.setAttribute('content', getThemeColor());
      });
    }

    updateAvatarColors();
  }

  function updateAvatarColors() {
    const accent = getThemeColor().replace('#', '');
    document.querySelectorAll('.js-theme-avatar[data-avatar-name]').forEach((avatar) => {
      const name = encodeURIComponent(avatar.dataset.avatarName || 'User');
      avatar.src = 'https://ui-avatars.com/api/?name=' + name + '&background=' + accent + '&color=0f172a&bold=true&size=34';
    });
  }

  function initTheme() {
    let savedTheme = null;

    try {
      savedTheme = localStorage.getItem('adminuk-theme');
    } catch (_) {}

    const initialTheme = allowedThemes.includes(savedTheme)
      ? savedTheme
      : (allowedThemes.includes(root.getAttribute('data-theme')) ? root.getAttribute('data-theme') : 'light');

    applyTheme(initialTheme, themeLabels[initialTheme]);
  }

  function initThemePicker() {
    themeSwatches.forEach((button) => {
      button.setAttribute('aria-pressed', 'false');

      button.addEventListener('click', function () {
        applyTheme(button.dataset.theme, button.title || themeLabels[button.dataset.theme]);
      });

      button.addEventListener('mouseenter', function () {
        if (themePreviewLabel) {
          themePreviewLabel.textContent = button.title || themeLabels[button.dataset.theme] || button.dataset.theme;
        }
      });
    });

    const themeDropdown = document.getElementById('themeDropdown');
    themeDropdown?.addEventListener('hidden.bs.dropdown', function () {
      const currentTheme = root.getAttribute('data-theme') || 'light';
      if (themePreviewLabel) themePreviewLabel.textContent = themeLabels[currentTheme] || currentTheme;
    });

    themeSearch?.addEventListener('input', function () {
      const query = themeSearch.value.trim().toLowerCase();
      let visibleCount = 0;

      themeSwatches.forEach((button) => {
        const label = [
          button.title,
          button.dataset.theme,
          themeLabels[button.dataset.theme]
        ].join(' ').toLowerCase();

        const matched = label.includes(query);
        button.hidden = !matched;
        if (matched) visibleCount++;
      });

      document.querySelectorAll('.theme-grid').forEach((grid) => {
        const hasVisible = Array.from(grid.querySelectorAll('.theme-swatch')).some((button) => !button.hidden);
        grid.hidden = !hasVisible;
      });

      document.querySelectorAll('.theme-group-label').forEach((label) => {
        const nextGrid = label.nextElementSibling;
        label.hidden = nextGrid && nextGrid.classList.contains('theme-grid') ? nextGrid.hidden : false;
      });

      if (themeNoResults) {
        themeNoResults.hidden = visibleCount > 0;
      }
    });
  }

  function openMobileSidebar() {
    sidebar?.classList.add('sidebar-open', 'active');
    sidebarOverlay?.classList.add('active');
    sidebarToggle?.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileSidebar() {
    sidebar?.classList.remove('sidebar-open', 'active');
    sidebarOverlay?.classList.remove('active');
    sidebarToggle?.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  function initSidebar() {
    sidebarToggle?.addEventListener('click', function () {
      const isMobile = window.matchMedia('(max-width: 767.98px)').matches;

      if (isMobile) {
        const isOpen = sidebar?.classList.contains('sidebar-open') || sidebar?.classList.contains('active');
        isOpen ? closeMobileSidebar() : openMobileSidebar();
        return;
      }

      adminWrapper?.classList.toggle('sidebar-collapsed');
      const isCollapsed = adminWrapper?.classList.contains('sidebar-collapsed');
      sidebarToggle.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
    });

    sidebarOverlay?.addEventListener('click', closeMobileSidebar);

    window.addEventListener('resize', function () {
      if (!window.matchMedia('(max-width: 767.98px)').matches) {
        closeMobileSidebar();
      }
    });
  }

  function initHeaderScroll() {
    function updateHeader() {
      adminHeader?.classList.toggle('is-scrolled', window.scrollY > 8);
    }

    updateHeader();
    window.addEventListener('scroll', updateHeader, { passive: true });
  }

  const commands = [
    ['Dashboard', 'index.html', 'bi-speedometer2'],
    ['Analytics Dashboard', 'analytics-dashboard.html', 'bi-bar-chart-line'],
    ['eCommerce Dashboard', 'ecommerce-dashboard.html', 'bi-bag-check'],
    ['CRM Dashboard', 'crm-dashboard.html', 'bi-people'],
    ['Project Dashboard', 'project-dashboard.html', 'bi-kanban'],
    ['Finance Dashboard', 'finance-dashboard.html', 'bi-wallet2'],
    ['SaaS Dashboard', 'saas-dashboard.html', 'bi-cloud-check'],
    ['Support Dashboard', 'support-dashboard.html', 'bi-headset'],
    ['Profile', 'profile.html', 'bi-person'],
    ['Saved Items', 'saved-items.html', 'bi-bookmark'],
    ['System Config', 'system-config.html', 'bi-sliders']
  ];

  function renderCommands(query) {
    if (!commandList) return;

    const q = (query || '').trim().toLowerCase();
    const items = commands.filter(([label]) => label.toLowerCase().includes(q));

    commandList.innerHTML = items.length
      ? items.map(([label, href, icon]) => (
          '<a class="command-palette__item text-decoration-none" href="' + href + '">' +
            '<i class="bi ' + icon + '" aria-hidden="true"></i>' +
            '<span>' + label + '</span>' +
          '</a>'
        )).join('')
      : '<div class="command-palette__item text-muted">No matching command found.</div>';
  }

  function openCommandPalette() {
    renderCommands('');
    commandBackdrop?.classList.add('show');
    commandBackdrop?.setAttribute('aria-hidden', 'false');
    setTimeout(() => commandInput?.focus(), 30);
  }

  function closeCommandPalette() {
    commandBackdrop?.classList.remove('show');
    commandBackdrop?.setAttribute('aria-hidden', 'true');
    if (commandInput) commandInput.value = '';
  }

  function initCommandPalette() {
    document.addEventListener('keydown', function (event) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        openCommandPalette();
      }

      if (event.key === 'Escape') {
        closeCommandPalette();
        closeMobileSidebar();
      }
    });

    commandInput?.addEventListener('input', function () {
      renderCommands(commandInput.value);
    });

    commandBackdrop?.addEventListener('click', function (event) {
      if (event.target === commandBackdrop) {
        closeCommandPalette();
      }
    });
  }

  function initLogout() {
    document.addEventListener('click', function (event) {
      const logoutButton = event.target.closest('.js-logout');
      if (!logoutButton) return;

      const confirmed = window.confirm('Are you sure you want to log out?');
      if (confirmed) {
        window.location.href = 'login.html';
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initTheme();
    initThemePicker();
    initSidebar();
    initHeaderScroll();
    initCommandPalette();
    initLogout();
  });
})();
