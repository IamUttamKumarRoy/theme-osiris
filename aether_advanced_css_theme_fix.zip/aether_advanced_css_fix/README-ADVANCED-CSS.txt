Aether Advanced CSS + Theme Fix

Files included:
- assets/css/aether-dashboard-advanced.css
- assets/js/dashboard-fixed.js

How to install:

1. Place the files in your project:
   assets/css/aether-dashboard-advanced.css
   assets/js/dashboard-fixed.js

2. In every HTML page, load the advanced CSS AFTER your current main CSS:

   <link rel="stylesheet" href="assets/css/theme.css">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="assets/css/aether-dashboard-production.css">
   <link rel="stylesheet" href="assets/css/aether-dashboard-advanced.css">

3. Replace your old dashboard script or load this file after it:

   <script src="assets/js/dashboard-fixed.js"></script>

Best option:
- Use only dashboard-fixed.js instead of the older dashboard.js if both handle the same sidebar/theme/command-palette actions.

What this fixes:
- Theme swatches now switch color scheme correctly.
- Active theme state works with .is-active, .active, and aria-pressed.
- Theme search hides unmatched swatches and groups.
- Mobile sidebar overlay works more reliably.
- Header shadow works on scroll.
- Cards, sidebar, dropdowns, forms, tables, command palette, and footer get a more premium UI.
