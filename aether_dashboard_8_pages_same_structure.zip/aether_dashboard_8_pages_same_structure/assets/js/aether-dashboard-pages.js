(function(){
  const themes=['light','dark','obsidian','deep-space','netflix','vscode','royal','emerald','ocean','sakura','sunset','cyber'];
  const root=document.documentElement;
  const saved=localStorage.getItem('adminuk-theme');
  if(saved&&themes.includes(saved))root.setAttribute('data-theme',saved);

  const toggle=document.getElementById('sidebarCollapse');
  const overlay=document.getElementById('sidebarOverlay');
  toggle?.addEventListener('click',()=>{window.innerWidth<992?document.body.classList.toggle('sidebar-open'):document.body.classList.toggle('sidebar-collapsed')});
  overlay?.addEventListener('click',()=>document.body.classList.remove('sidebar-open'));

  document.querySelectorAll('.theme-swatch').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const theme=btn.dataset.theme;
      root.setAttribute('data-theme',theme);
      localStorage.setItem('adminuk-theme',theme);
      const label=document.getElementById('themePreviewLabel');
      if(label)label.textContent=btn.title||theme;
    });
  });

  const palette=document.getElementById('commandPaletteBackdrop');
  const input=document.getElementById('commandPaletteInput');
  const list=document.getElementById('commandPaletteList');
  const commands=[
    ['Dashboard Overview','index.html','bi-speedometer2'],['Analytics Dashboard','analytics-dashboard.html','bi-bar-chart-line'],
    ['eCommerce Dashboard','ecommerce-dashboard.html','bi-bag-check'],['CRM Dashboard','crm-dashboard.html','bi-people'],
    ['Project Dashboard','project-dashboard.html','bi-kanban'],['Finance Dashboard','finance-dashboard.html','bi-wallet2'],
    ['SaaS Dashboard','saas-dashboard.html','bi-cloud-check'],['Support Dashboard','support-dashboard.html','bi-headset'],
    ['Profile','profile.html','bi-person'],['Settings','settings.html','bi-gear']
  ];
  function render(q=''){
    if(!list)return;
    const f=q.toLowerCase();
    const items=commands.filter(c=>c[0].toLowerCase().includes(f));
    list.innerHTML=items.map(c=>`<a class="command-item" href="${c[1]}"><i class="bi ${c[2]}"></i><span>${c[0]}</span></a>`).join('')||'<div class="p-3 small-muted">No matching commands.</div>';
  }
  function openPalette(){render();palette?.classList.add('show');setTimeout(()=>input?.focus(),50)}
  function closePalette(){palette?.classList.remove('show')}
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openPalette()}if(e.key==='Escape')closePalette()});
  input?.addEventListener('input',()=>render(input.value));
  palette?.addEventListener('click',e=>{if(e.target===palette)closePalette()});
  document.addEventListener('click',e=>{if(e.target.closest('.js-logout')&&confirm('Are you sure you want to log out?'))location.href='login.html'});
})();