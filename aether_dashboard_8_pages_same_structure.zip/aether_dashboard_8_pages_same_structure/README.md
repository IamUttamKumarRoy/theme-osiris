# Aether Dashboard - 8 Dashboard Pages

This package contains 8 dashboard pages created in the same structure as the provided Aether Admin Dashboard.

## Included dashboard pages
- index.html - Dashboard Overview
- analytics-dashboard.html - Analytics Dashboard
- ecommerce-dashboard.html - eCommerce Dashboard
- crm-dashboard.html - CRM Dashboard
- project-dashboard.html - Project Dashboard
- finance-dashboard.html - Finance Dashboard
- saas-dashboard.html - SaaS Dashboard
- support-dashboard.html - Support Dashboard

## Extra pages
- profile.html
- saved-items.html
- settings.html
- login.html
- 404.html

## Assets
- assets/css/aether-dashboard-pages.css
- assets/js/aether-dashboard-pages.js

## How to preview
Open index.html in your browser. Keep the assets folder beside the HTML files.
