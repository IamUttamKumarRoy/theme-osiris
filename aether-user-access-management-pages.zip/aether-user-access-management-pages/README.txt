Aether User & Access Management Pages Pack
=========================================

Generated pages:
- user-list.html
- user-grid.html
- user-profile.html
- user-details.html
- edit-user.html
- create-user.html
- roles-permissions.html
- role-details.html
- create-role.html
- access-control.html
- user-sessions.html
- user-activity.html
- organization-members.html
- invite-user.html
- index.html

Included structure:
- admin-wrapper
- admin-sidebar with branding and smooth scroll navigation
- admin-header topbar
- topbar theme dropdown
- alerts dropdown
- user dropdown
- admin-content main area
- admin-footer
- command palette container

Assets copied from uploaded/latest Aether template:
- assets/css/theme.css
- assets/css/production-ready.css
- assets/js/dashboard.js

Additional page-specific CSS:
- assets/css/user-access-management.css

How to use:
Open index.html in a browser, or open any page directly.
