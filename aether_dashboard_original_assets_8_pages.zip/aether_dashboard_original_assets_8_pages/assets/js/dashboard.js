
(function () {
  'use strict';
  const allowedThemes = ['light','dark','obsidian','vercel','deep-space','netflix','microsoft','google','apple','vscode','aws','royal','spotify','figma','slack','airbnb','uber','sapphire','nebula','aurora','phoenix','sakura','sunset','rose','slate','emerald','ocean','midnight-teal','cyber'];
  const root = document.documentElement;
  const saved = localStorage.getItem('adminuk-theme');
  if (saved && allowedThemes.includes(saved)) root.setAttribute('data-theme', saved);

  const wrapper = document.getElementById('adminWrapper');
  const sidebar = document.getElementById('sidebar');
  const toggle = document.getElementById('sidebarCollapse');
  const overlay = document.getElementById('sidebarOverlay');
  const themeLabel = document.getElementById('themePreviewLabel');
  const themeSearch = document.getElementById('themeSearch');
  const themeNoResults = document.getElementById('themeNoResults');
  const palette = document.getElementById('commandPaletteBackdrop');
  const paletteInput = document.getElementById('commandPaletteInput');
  const paletteList = document.getElementById('commandPaletteList');

  function setTheme(theme, label) {
    if (!allowedThemes.includes(theme)) return;
    root.setAttribute('data-theme', theme);
    localStorage.setItem('adminuk-theme', theme);
    document.querySelectorAll('.theme-swatch').forEach(btn => btn.classList.toggle('is-active', btn.dataset.theme === theme));
    if (themeLabel) themeLabel.textContent = label || theme;
    const meta = document.getElementById('metaThemeColor');
    const accent = getComputedStyle(root).getPropertyValue('--t-accent').trim();
    if (meta && accent) meta.setAttribute('content', accent);
  }

  document.querySelectorAll('.theme-swatch').forEach(btn => btn.addEventListener('click', () => setTheme(btn.dataset.theme, btn.title)));
  const current = root.getAttribute('data-theme') || 'light';
  const currentBtn = document.querySelector('.theme-swatch[data-theme="' + current + '"]');
  setTheme(current, currentBtn ? currentBtn.title : current);

  if (themeSearch) {
    themeSearch.addEventListener('input', () => {
      const q = themeSearch.value.trim().toLowerCase();
      let count = 0;
      document.querySelectorAll('.theme-swatch').forEach(btn => {
        const match = (btn.title + ' ' + btn.dataset.theme).toLowerCase().includes(q);
        btn.hidden = !match;
        if (match) count += 1;
      });
      if (themeNoResults) themeNoResults.hidden = count > 0;
    });
  }

  function openSidebar() {
    sidebar?.classList.add('sidebar-open', 'active');
    overlay?.classList.add('active');
    toggle?.setAttribute('aria-expanded', 'true');
  }
  function closeSidebar() {
    sidebar?.classList.remove('sidebar-open', 'active');
    overlay?.classList.remove('active');
    toggle?.setAttribute('aria-expanded', 'false');
  }
  toggle?.addEventListener('click', () => {
    if (window.innerWidth < 768) {
      const open = sidebar?.classList.contains('sidebar-open') || sidebar?.classList.contains('active');
      open ? closeSidebar() : openSidebar();
    } else {
      wrapper?.classList.toggle('sidebar-collapsed');
      toggle.setAttribute('aria-expanded', wrapper?.classList.contains('sidebar-collapsed') ? 'false' : 'true');
    }
  });
  overlay?.addEventListener('click', closeSidebar);

  const commands = [
    ['Dashboard','index.html','bi-speedometer2'],['Analytics','analytics-dashboard.html','bi-bar-chart-line'],['eCommerce','ecommerce-dashboard.html','bi-bag-check'],['CRM','crm-dashboard.html','bi-people'],['Projects','project-dashboard.html','bi-kanban'],['Finance','finance-dashboard.html','bi-wallet2'],['SaaS','saas-dashboard.html','bi-cloud-check'],['Support','support-dashboard.html','bi-headset'],['Profile','profile.html','bi-person'],['Saved Items','saved-items.html','bi-bookmark'],['System Config','system-config.html','bi-sliders']
  ];
  function renderCommands(q = '') {
    if (!paletteList) return;
    const needle = q.toLowerCase();
    const items = commands.filter(([label]) => label.toLowerCase().includes(needle));
    paletteList.innerHTML = items.length ? items.map(([label, href, icon]) => '<a class="command-palette__item text-decoration-none" href="' + href + '"><i class="bi ' + icon + '" aria-hidden="true"></i><span>' + label + '</span></a>').join('') : '<div class="command-palette__item text-muted">No matching command found.</div>';
  }
  function openPalette() { renderCommands(''); palette?.classList.add('show'); palette?.setAttribute('aria-hidden', 'false'); setTimeout(() => paletteInput?.focus(), 40); }
  function closePalette() { palette?.classList.remove('show'); palette?.setAttribute('aria-hidden', 'true'); }
  document.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); openPalette(); }
    if (event.key === 'Escape') { closePalette(); closeSidebar(); }
  });
  paletteInput?.addEventListener('input', () => renderCommands(paletteInput.value));
  palette?.addEventListener('click', event => { if (event.target === palette) closePalette(); });
  document.addEventListener('click', event => {
    if (!event.target.closest('.js-logout')) return;
    if (confirm('Are you sure you want to log out?')) window.location.href = 'login.html';
  });
})();
