# Aether Dashboard - Original Assets 8 Pages

Generated from the provided premium dashboard HTML, theme.css, and main production CSS.

## Dashboard pages
- index.html
- analytics-dashboard.html
- ecommerce-dashboard.html
- crm-dashboard.html
- project-dashboard.html
- finance-dashboard.html
- saas-dashboard.html
- support-dashboard.html

## Extra pages
- profile.html
- saved-items.html
- system-config.html
- login.html
- 404.html

## Assets
- assets/css/theme.css
- assets/css/aether-dashboard-production.css
- assets/js/dashboard.js

Open index.html after extracting the ZIP.
