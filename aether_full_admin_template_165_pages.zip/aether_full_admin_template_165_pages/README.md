# Aether Full Admin Template

Generated premium Bootstrap 5 admin dashboard package based on the provided Aether Admin Dashboard structure.

## Total generated content

- Main pages: 165
- Section index pages: 13
- Total HTML files: 179

## Page counts by module

- Dashboard: 8 pages
- User Management: 10 pages
- Authentication: 12 pages
- Projects & Tasks: 10 pages
- CRM: 15 pages
- Ecommerce: 20 pages
- Finance: 10 pages
- Analytics: 10 pages
- Support System: 10 pages
- Settings: 12 pages
- System Monitoring: 10 pages
- Documentation: 8 pages
- UI Components: 30 pages

## Main assets

- assets/css/theme.css
- assets/css/aether-dashboard-production.css
- assets/css/aether-dashboard-advanced.css
- assets/js/dashboard.js

## How to preview

Open `index.html` in a browser after extracting the ZIP.

## Notes

This package keeps the same Aether shell:
- Sidebar navigation
- Header tools
- Theme picker
- Notifications dropdown
- User dropdown
- Command palette
- Page header
- Stat cards
- Dashboard panels
- Footer

The color theme switcher is handled in `assets/js/dashboard.js`.
