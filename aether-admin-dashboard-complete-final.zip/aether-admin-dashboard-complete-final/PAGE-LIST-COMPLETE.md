# Aether Complete Template Page List

## Dashboard
- [OK] Dashboard Overview: dashboard.html
- [OK] Template Index: index.html
- [OK] Aether Production: dashboards/dashboard-aether-production.html
- [OK] Analytics: dashboards/dashboard-analytics.html
- [OK] CRM Dashboard: dashboards/dashboard-crm.html
- [OK] Ecommerce Dashboard: dashboards/dashboard-ecommerce.html
- [OK] Marketing: dashboards/dashboard-marketing.html
- [OK] Projects: dashboards/dashboard-projects.html
- [OK] No Sidebar Dashboard: dashboards/dashboard-aether-nosidebar.html
- [OK] Dark Dashboard: dashboards/dashboard-dark.html
- [OK] Minimal Dashboard: dashboards/dashboard-minimal.html
- [OK] RTL Dashboard: dashboards/dashboard-rtl.html

## Users
- [OK] Create User: users/create-user.html
- [OK] Edit User: users/edit-user.html
- [OK] Invite User: users/invite-user.html
- [OK] Organization Members: users/organization-members.html
- [OK] User Activity: users/user-activity.html
- [OK] User Details: users/user-details.html
- [OK] User Grid: users/user-grid.html
- [OK] User List: users/user-list.html
- [OK] User Profile: users/user-profile.html
- [OK] User Sessions: users/user-sessions.html

## Roles & Permissions
- [OK] Create Role: roles/create-role.html
- [OK] Role Details: roles/role-details.html
- [OK] Roles Permissions: roles/roles-permissions.html
- [OK] Access Control: security/access-control.html
- [OK] Permission Matrix: security/permission-matrix.html
- [OK] Role Management: security/role-management.html

## Security & Compliance
- [OK] Activity Log: security/activity-log.html
- [OK] Audit Reports: security/audit-reports.html
- [OK] GDPR Compliance: security/compliance-gdpr.html
- [OK] Security Logs: security/security-logs.html
- [OK] System Status: security/system-status.html

## Ecommerce
- [OK] Ecommerce Dashboard: ecommerce/ecommerce-dashboard.html
- [OK] Orders: ecommerce/orders.html
- [OK] Order Details: ecommerce/order-details.html
- [OK] Inventory: ecommerce/inventory.html
- [OK] Products: ecommerce/products.html
- [OK] Product Details: ecommerce/product-details.html
- [OK] Add Product: ecommerce/add-product.html
- [OK] Product Reviews: ecommerce/product-reviews.html
- [OK] Customers: ecommerce/customers.html
- [OK] Customer Details: ecommerce/customer-details.html
- [OK] Coupons: ecommerce/coupons.html
- [OK] Refunds: ecommerce/refunds.html
- [OK] Returns: ecommerce/returns.html
- [OK] Shipping: ecommerce/shipping.html
- [OK] Payment Methods: ecommerce/payment-methods.html
- [OK] Pricing Plans: ecommerce/pricing-plans.html
- [OK] Invoice: ecommerce/invoice.html
- [OK] Subscription Confirmed: ecommerce/subscription-confirmed.html
- [OK] Cart: ecommerce/cart.html
- [OK] Checkout: ecommerce/checkout.html
- [OK] Wishlist: ecommerce/wishlist.html

## CRM
- [OK] Leads: crm/leads.html
- [OK] Lead Details: crm/lead-details.html
- [OK] Deals: crm/deals.html
- [OK] Deal Details: crm/deal-details.html
- [OK] Pipeline: crm/pipeline.html
- [OK] Customers: crm/customers.html
- [OK] Customer Details: crm/customer-details.html
- [OK] Activities: crm/activities.html
- [OK] Reports: crm/reports.html

## Support / Helpdesk
- [OK] Help Center: support/help-center.html
- [OK] FAQ: support/faq.html
- [OK] Support Tickets: support/support-tickets.html
- [OK] Ticket Details: support/ticket-details.html
- [OK] Create Ticket: support/create-ticket.html
- [OK] Knowledge Base: support/knowledge-base.html

## Blog / CMS
- [OK] Blog List: blog/blog-list.html
- [OK] Blog Grid: blog/blog-grid.html
- [OK] Blog Details: blog/blog-details.html
- [OK] Create Post: blog/create-post.html
- [OK] Edit Post: blog/edit-post.html
- [OK] Categories: blog/categories.html
- [OK] Comments: blog/comments.html

## File / Media
- [OK] Media Library: media/media-library.html
- [OK] Upload Files: media/upload-files.html
- [OK] File Details: media/file-details.html

## Billing
- [OK] Invoices: billing/invoices.html
- [OK] Invoice Details: billing/invoice-details.html
- [OK] Create Invoice: billing/create-invoice.html
- [OK] Payment History: billing/payment-history.html
- [OK] Subscriptions: billing/subscriptions.html
- [OK] Subscription Details: billing/subscription-details.html
- [OK] Billing Plans: billing/billing-plans.html

## Communication
- [OK] Communication Dashboard: communication/communication-dashboard.html
- [OK] Message Inbox: communication/message-inbox.html
- [OK] Newsletter Management: communication/newsletter-management.html
- [OK] Team Collaboration: communication/team-collaboration.html
- [OK] Chat: communication/chat.html
- [OK] Video Meeting: communication/video-meeting.html
- [OK] Notifications: communication/notifications.html
- [OK] Contacts: communication/contacts.html
- [OK] Group Chat: communication/group-chat.html
- [OK] Voice Call: communication/voice-call.html

## Monitoring
- [OK] Monitoring Dashboard: monitoring/monitoring-dashboard.html
- [OK] Performance Monitoring: monitoring/performance-monitoring.html
- [OK] Server Health: monitoring/server-health.html
- [OK] Transactions: monitoring/transactions.html
- [OK] Uptime Reports: monitoring/uptime-reports.html
- [OK] Logs Viewer: monitoring/logs-viewer.html
- [OK] SLA Tracking: monitoring/sla-tracking.html

## Data & Tables
- [OK] Tables: data-tables/tables.html
- [OK] Tables All: data-tables/tables-all.html
- [OK] Search Results: data-tables/search-results.html
- [OK] Datatables Advanced: data-tables/datatables-advanced.html
- [OK] Export Tables: data-tables/export-tables.html
- [OK] Pivot Tables: data-tables/pivot-tables.html
- [OK] Data Grid: data-tables/data-grid.html

## Charts
- [OK] Charts Line: charts/charts-line.html
- [OK] Charts Bar: charts/charts-bar.html
- [OK] Charts Pie: charts/charts-pie.html
- [OK] Charts Heatmap: charts/charts-heatmap.html
- [OK] Charts Radial: charts/charts-radial.html
- [OK] Charts Candlestick: charts/charts-candlestick.html
- [OK] Charts Mixed: charts/charts-mixed.html
- [OK] Charts Dashboard: charts/charts-dashboard.html

## Forms
- [OK] Forms Basic: forms/forms-basic.html
- [OK] Forms Wizard: forms/forms-wizard.html
- [OK] Forms Editors: forms/forms-editors.html
- [OK] Forms File Upload: forms/forms-file-upload.html
- [OK] Forms Validation: forms/forms-validation.html
- [OK] Forms Advanced: forms/forms-advanced.html
- [OK] Forms Layouts: forms/forms-layouts.html
- [OK] Forms Dark: forms/forms-dark.html

## Projects
- [OK] Project Management: projects/project-management.html
- [OK] Project Kanban: projects/project-kanban.html
- [OK] Project Calendar: projects/project-calendar.html
- [OK] Project Dashboard: projects/project-dashboard.html
- [OK] Project Tasks: projects/project-tasks.html
- [OK] Project Reports: projects/project-reports.html

## Productivity
- [OK] File Manager: productivity/file-manager.html
- [OK] Email Compose: productivity/email-compose.html
- [OK] Email Read: productivity/email-read.html
- [OK] Email Starred: productivity/email-starred.html
- [OK] Email Trash: productivity/email-trash.html
- [OK] Notes: productivity/notes.html
- [OK] Task Manager: productivity/task-manager.html
- [OK] Productivity Dashboard: productivity/productivity-dashboard.html

## Marketing
- [OK] Landing Page: marketing/landing-page.html
- [OK] Testimonials: marketing/testimonials.html
- [OK] Contact: marketing/contact.html
- [OK] Features: marketing/features.html
- [OK] Pricing: marketing/pricing.html
- [OK] Marketing Dashboard: marketing/marketing-dashboard.html

## UI Components
- [OK] UI Overview: ui/ui-overview.html
- [OK] Accordions: ui/ui-accordions.html
- [OK] Alerts: ui/ui-alerts.html
- [OK] Avatars: ui/ui-avatars.html
- [OK] Badges: ui/ui-badges.html
- [OK] Breadcrumbs: ui/ui-breadcrumbs.html
- [OK] Buttons: ui/ui-buttons.html
- [OK] Cards: ui/ui-cards.html
- [OK] Carousel: ui/ui-carousel.html
- [OK] Dropdowns: ui/ui-dropdowns.html
- [OK] Empty States: ui/ui-empty-states.html
- [OK] Forms: ui/ui-forms.html
- [OK] Icons: ui/ui-icons.html
- [OK] Input Groups: ui/ui-input-groups.html
- [OK] List Groups: ui/ui-list-groups.html
- [OK] Modals: ui/ui-modals.html
- [OK] Navs: ui/ui-navs.html
- [OK] Offcanvas: ui/ui-offcanvas.html
- [OK] Pagination: ui/ui-pagination.html
- [OK] Popovers: ui/ui-popovers.html
- [OK] Progress: ui/ui-progress.html
- [OK] Spinners: ui/ui-spinners.html
- [OK] Tables: ui/ui-tables.html
- [OK] Tabs: ui/ui-tabs.html
- [OK] Timelines: ui/ui-timelines.html
- [OK] Toasts: ui/ui-toasts.html
- [OK] Tooltips: ui/ui-tooltips.html
- [OK] Typography: ui/ui-typography.html
- [OK] Utilities: ui/ui-utilities.html
- [OK] Widgets: ui/ui-widgets.html

## Documentation
- [OK] Installation: docs/installation.html
- [OK] Customization: docs/customization.html
- [OK] Changelog: docs/changelog.html
- [OK] Credits: docs/credits.html
- [OK] Folder Structure: docs/folder-structure.html
- [OK] Plugin Guide: docs/plugin-guide.html
- [OK] Theme Guide: docs/theme-guide.html

## System / Developer
- [OK] API Documentation: developer/api-documentation.html
- [OK] API Keys: developer/api-keys.html
- [OK] Webhooks: developer/webhooks.html
- [OK] Error Logs: developer/error-logs.html
- [OK] System Info: developer/system-info.html
- [OK] Version Control: developer/version-control.html

## Legal
- [OK] Privacy Policy: legal/privacy-policy.html
- [OK] Terms of Use: legal/terms.html

## Auth & Utility
- [OK] Login: auth/login.html
- [OK] Register: auth/register.html
- [OK] Forgot Password: auth/forgot-password.html
- [OK] Reset Password: auth/reset-password.html
- [OK] Email Verification: auth/email-verification.html
- [OK] Two Factor Auth: auth/two-factor-auth.html
- [OK] Lock Screen: auth/lock-screen.html
- [OK] Social Login: auth/social-login.html
- [OK] OTP Verification: auth/otp-verification.html
- [OK] Password Strength: auth/password-strength.html
- [OK] Auth Split Layout: auth/auth-split-layout.html
- [OK] Auth Dark: auth/auth-dark.html
- [OK] Error 403: errors/error-403.html
- [OK] Error 404: errors/error-404.html
- [OK] Error 500: errors/error-500.html
- [OK] Maintenance Mode: errors/maintenance-mode.html
- [OK] Coming Soon: errors/coming-soon.html
- [OK] Offline: errors/offline.html
- [OK] Under Construction: errors/under-construction.html
