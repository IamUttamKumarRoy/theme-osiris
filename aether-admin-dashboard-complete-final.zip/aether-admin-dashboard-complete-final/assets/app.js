
document.addEventListener('click', function(e){
  const q = e.target.closest('.quantity button');
  if(q){
    const box = q.parentElement;
    const span = box.querySelector('span');
    let value = parseInt(span.textContent, 10);
    if(q.textContent.trim() === '+') value++;
    if(q.textContent.trim() === '-' && value > 1) value--;
    span.textContent = value;
  }
  const toastBtn = e.target.closest('[data-toast]');
  if(toastBtn){
    let toast = document.createElement('div');
    toast.textContent = toastBtn.getAttribute('data-toast');
    toast.style.cssText = 'position:fixed;right:22px;bottom:22px;background:#111827;color:#fff;padding:12px 16px;border-radius:14px;box-shadow:0 16px 40px rgba(0,0,0,.22);font:800 13px Inter,system-ui;z-index:9999';
    document.body.appendChild(toast);
    setTimeout(()=>toast.remove(),2200);
  }
});
