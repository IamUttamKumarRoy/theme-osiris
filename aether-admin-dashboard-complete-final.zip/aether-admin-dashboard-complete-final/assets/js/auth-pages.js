/* ========================================================================== 
   Auth Pages JS
   --------------------------------------------------------------------------
   Shared interactions for auth screens: validation, alerts, loading state,
   password toggle, OTP inputs, password strength, lock screen clock, and demo
   OAuth button helpers.
   Theme switching lives in theme-switcher.js.
========================================================================== */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', () => {
    initAuthForms();
    initPasswordToggles();
    initOtpInputs();
    initPasswordStrength();
    initDemoActions();
    initLockClock();
  });

  function initAuthForms() {
    document.querySelectorAll('[data-auth-form]').forEach(form => {
      const fields = Array.from(form.querySelectorAll('[data-validate]'));

      fields.forEach(field => {
        const eventName = isCheckbox(field) ? 'change' : 'input';
        field.addEventListener(eventName, () => validateField(field, { showValid: true }));
        field.addEventListener('blur', () => validateField(field, { showValid: true }));
      });

      form.addEventListener('submit', event => {
        event.preventDefault();
        hideAlert(form);

        const isValid = validateForm(form);
        if (!isValid) {
          showAlert(form, 'Please fix the highlighted fields and try again.', 'danger');
          focusFirstInvalid(form);
          return;
        }

        submitAuthForm(form);
      });
    });
  }

  function validateForm(form) {
    return Array.from(form.querySelectorAll('[data-validate]'))
      .map(field => validateField(field, { showValid: true }))
      .every(Boolean);
  }

  function validateField(field, options = {}) {
    const rules = String(field.dataset.validate || '').split('|').filter(Boolean);
    const label = field.dataset.label || getFieldLabel(field) || 'This field';
    let error = '';

    if (rules.includes('required') && !getFieldValue(field)) {
      error = field.dataset.errorRequired || `${label} is required.`;
    }

    if (!error && rules.includes('checkbox') && !field.checked) {
      error = field.dataset.errorRequired || `${label} is required.`;
    }

    if (!error && rules.includes('email') && getFieldValue(field)) {
      if (!isValidEmail(getFieldValue(field))) error = field.dataset.errorEmail || 'Please enter a valid email address.';
    }

    if (!error && rules.includes('minlength')) {
      const minLength = Number(field.dataset.minLength || field.getAttribute('minlength') || 1);
      if (getFieldValue(field).length < minLength) {
        error = field.dataset.errorMinlength || `${label} must be at least ${minLength} characters.`;
      }
    }

    if (!error && rules.includes('exactlength')) {
      const exactLength = Number(field.dataset.exactLength || field.getAttribute('maxlength') || 1);
      if (getFieldValue(field).length !== exactLength) {
        error = field.dataset.errorExactlength || `${label} must be ${exactLength} characters.`;
      }
    }

    if (!error && rules.includes('password')) {
      const minLength = Number(field.dataset.minLength || field.getAttribute('minlength') || 8);
      if (field.value.length < minLength) {
        error = field.dataset.errorPassword || `Password must be at least ${minLength} characters.`;
      }
    }

    if (!error && rules.includes('confirm')) {
      const matchSelector = field.dataset.match;
      const matchField = matchSelector ? document.querySelector(matchSelector) : null;
      if (matchField && field.value !== matchField.value) {
        error = field.dataset.errorConfirm || 'Passwords do not match.';
      }
    }

    setFieldState(field, error, options.showValid);
    return !error;
  }

  function setFieldState(field, error, showValid) {
    const hasError = Boolean(error);
    const feedback = getFeedback(field);
    const feedbackMessage = feedback?.querySelector('[data-feedback-message]');
    const group = field.closest('.input-group');

    field.classList.toggle('is-invalid', hasError);
    field.classList.toggle('is-valid', !hasError && showValid && hasUserValue(field));
    field.setAttribute('aria-invalid', String(hasError));

    if (group) {
      group.classList.toggle('is-invalid', hasError);
      group.classList.toggle('is-valid', !hasError && showValid && hasUserValue(field));
    }

    if (feedback && feedbackMessage && error) {
      feedbackMessage.textContent = error;
    }
  }

  function submitAuthForm(form) {
    const button = form.querySelector('[data-auth-submit-button]');
    const loadingText = button?.dataset.loadingText || 'Please wait...';
    const successMessage = form.dataset.successMessage || 'Success. Your request has been completed.';
    const redirectUrl = form.dataset.redirect;

    setSubmitState(form, true, loadingText);

    window.setTimeout(() => {
      showAlert(form, successMessage, 'success');
      setSubmitState(form, false);

      if (redirectUrl) {
        window.setTimeout(() => {
          window.location.href = redirectUrl;
        }, 800);
      } else if (!form.dataset.demoOnly) {
        // Keep normal backend compatibility when no redirect is configured.
        form.submit();
      }
    }, 650);
  }

  function setSubmitState(form, isLoading, loadingText) {
    const button = form.querySelector('[data-auth-submit-button]');
    if (!button) return;

    if (!button.dataset.defaultText) button.dataset.defaultText = button.innerHTML.trim();

    form.classList.toggle('is-submitting', isLoading);
    button.disabled = isLoading;
    button.setAttribute('aria-busy', String(isLoading));

    if (isLoading) {
      button.innerHTML = `<span class="btn-spinner" aria-hidden="true"></span>${escapeHtml(loadingText)}`;
    } else {
      button.innerHTML = button.dataset.defaultText;
    }
  }

  function showAlert(scope, message, type = 'success') {
    const alert = scope.querySelector('[data-auth-alert]') || document.querySelector('[data-auth-alert]');
    if (!alert) return;

    const icon = alert.querySelector('[data-auth-alert-icon]');
    const text = alert.querySelector('[data-auth-alert-message]');
    const isSuccess = type === 'success';

    alert.hidden = false;
    alert.classList.remove('alert-success', 'alert-danger', 'is-success', 'is-error');
    alert.classList.add(isSuccess ? 'alert-success' : 'alert-danger', isSuccess ? 'is-success' : 'is-error', 'show');

    if (icon) {
      icon.className = `bi ${isSuccess ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'}`;
    }

    if (text) text.textContent = message;
  }

  function hideAlert(scope) {
    const alert = scope.querySelector('[data-auth-alert]') || document.querySelector('[data-auth-alert]');
    if (!alert) return;
    alert.hidden = true;
    alert.classList.remove('show', 'alert-success', 'alert-danger', 'is-success', 'is-error');
  }

  function focusFirstInvalid(form) {
    const firstInvalid = form.querySelector('.is-invalid');
    if (!firstInvalid) return;
    firstInvalid.focus({ preventScroll: true });
    firstInvalid.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'center' });
  }

  function initPasswordToggles() {
    document.querySelectorAll('[data-password-toggle], #togglePassword').forEach(button => {
      button.addEventListener('click', () => {
        const targetId = button.getAttribute('aria-controls');
        const input = (targetId && document.getElementById(targetId)) || button.closest('.input-group')?.querySelector('input');
        if (!input) return;

        const shouldShow = input.type === 'password';
        input.type = shouldShow ? 'text' : 'password';
        button.setAttribute('aria-pressed', String(shouldShow));
        button.setAttribute('aria-label', shouldShow ? 'Hide password' : 'Show password');

        const icon = button.querySelector('.bi');
        if (icon) {
          icon.classList.toggle('bi-eye', !shouldShow);
          icon.classList.toggle('bi-eye-slash', shouldShow);
        }
      });
    });
  }

  function initOtpInputs() {
    document.querySelectorAll('.auth-otp-grid').forEach(grid => {
      const inputs = Array.from(grid.querySelectorAll('[data-otp-input]'));
      const form = grid.closest('form');
      const hidden = form?.querySelector('[data-otp-hidden]');

      const syncHidden = () => {
        if (hidden) hidden.value = inputs.map(input => input.value).join('');
      };

      inputs.forEach((input, index) => {
        input.addEventListener('input', () => {
          input.value = input.value.replace(/\D/g, '').slice(0, 1);
          syncHidden();
          if (input.value && inputs[index + 1]) inputs[index + 1].focus();
        });

        input.addEventListener('keydown', event => {
          if (event.key === 'Backspace' && !input.value && inputs[index - 1]) inputs[index - 1].focus();
        });

        input.addEventListener('paste', event => {
          const text = (event.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, inputs.length);
          if (!text) return;
          event.preventDefault();
          inputs.forEach((item, itemIndex) => { item.value = text[itemIndex] || ''; });
          syncHidden();
          (inputs[Math.min(text.length, inputs.length) - 1] || input).focus();
        });
      });
    });
  }

  function initPasswordStrength() {
    document.querySelectorAll('[data-password-strength]').forEach(input => {
      const bar = document.querySelector(input.dataset.passwordStrength);
      const liveText = document.querySelector(`[data-strength-text-for="${input.id}"]`);

      const update = () => {
        const value = input.value;
        const score = getPasswordScore(value);
        const label = getPasswordLabel(score, value.length);

        if (bar) bar.dataset.strength = String(score);
        if (liveText) liveText.textContent = `Password strength: ${label}`;

        document.querySelectorAll(`[data-rule-for="${input.id}"]`).forEach(rule => {
          const type = rule.dataset.rule;
          const isValid = isPasswordRuleValid(type, value);
          rule.classList.toggle('is-valid', isValid);

          const icon = rule.querySelector('.bi');
          if (icon) {
            icon.classList.toggle('bi-circle', !isValid);
            icon.classList.toggle('bi-check-circle-fill', isValid);
          }
        });
      };

      input.addEventListener('input', update);
      update();
    });
  }

  function getPasswordScore(value) {
    let score = 0;
    if (value.length >= 8) score += 1;
    if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score += 1;
    if (/\d/.test(value)) score += 1;
    if (/[^A-Za-z0-9]/.test(value)) score += 1;
    return score;
  }

  function getPasswordLabel(score, length) {
    if (!length) return 'empty';
    if (score <= 1) return 'weak';
    if (score === 2) return 'fair';
    if (score === 3) return 'good';
    return 'strong';
  }

  function isPasswordRuleValid(type, value) {
    return (
      (type === 'length' && value.length >= 8) ||
      (type === 'case' && /[a-z]/.test(value) && /[A-Z]/.test(value)) ||
      (type === 'number' && /\d/.test(value)) ||
      (type === 'symbol' && /[^A-Za-z0-9]/.test(value))
    );
  }

  function initDemoActions() {
    document.querySelectorAll('[data-auth-demo-action]').forEach(button => {
      button.addEventListener('click', () => {
        const form = button.closest('[data-auth-form]');
        const label = button.dataset.authDemoAction || 'This provider';
        showAlert(form || document, `${label} is a demo button. Connect your OAuth endpoint in production.`, 'danger');
      });
    });
  }

  function initLockClock() {
    const clock = document.querySelector('[data-lock-clock]');
    if (!clock) return;
    const tick = () => {
      clock.textContent = new Date().toLocaleString(undefined, { weekday: 'long', hour: '2-digit', minute: '2-digit' });
    };
    tick();
    window.setInterval(tick, 30000);
  }

  function getFieldValue(field) {
    if (isCheckbox(field)) return field.checked ? field.value || '1' : '';
    return String(field.value || '').trim();
  }

  function hasUserValue(field) {
    return isCheckbox(field) ? field.checked : Boolean(getFieldValue(field));
  }

  function getFeedback(field) {
    return document.querySelector(`[data-feedback-for="${field.id}"]`);
  }

  function getFieldLabel(field) {
    if (!field.id) return '';
    return document.querySelector(`label[for="${field.id}"]`)?.textContent?.trim() || '';
  }

  function isCheckbox(field) {
    return field.type === 'checkbox' || field.type === 'radio';
  }

  function isValidEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    }[char]));
  }

  function prefersReducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }
})();
