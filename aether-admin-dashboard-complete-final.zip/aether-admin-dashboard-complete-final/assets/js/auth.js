/* ========================================================================
   Aether Auth JS
   Reusable auth page controller. Validation and UI logic only.
======================================================================== */
(function () {
    'use strict';

    const STORAGE_KEYS = Object.freeze({
        theme: 'uttam-theme',
        rememberedEmail: 'uttam-remembered-email'
    });

    const DEFAULT_THEME = document.documentElement.dataset.defaultTheme || 'cosmic-aurora';
    const REMEMBER_EMAIL_MAX_AGE_MS = 1000 * 60 * 60 * 24 * 30;

    const themes = Object.freeze({
        light: { name: 'Light', color: '#2563eb', mode: 'light' },
        dark: { name: 'Dark', color: '#38bdf8', mode: 'dark' },
        obsidian: { name: 'Obsidian', color: '#d4af37', mode: 'dark' },
        vercel: { name: 'Vercel Black', color: '#ffffff', mode: 'dark' },
        'deep-space': { name: 'Deep Space', color: '#8b5cf6', mode: 'dark' },
        netflix: { name: 'Netflix Red', color: '#e50914', mode: 'dark' },
        microsoft: { name: 'Microsoft Fluent', color: '#0078d4', mode: 'light' },
        google: { name: 'Google Material 3', color: '#6750a4', mode: 'light' },
        apple: { name: 'Apple SF', color: '#007aff', mode: 'light' },
        vscode: { name: 'VSCode Dark', color: '#007acc', mode: 'dark' },
        aws: { name: 'AWS Orange', color: '#ff9900', mode: 'dark' },
        royal: { name: 'Royal', color: '#9333ea', mode: 'light' },
        spotify: { name: 'Spotify Green', color: '#1db954', mode: 'dark' },
        figma: { name: 'Figma Purple', color: '#a259ff', mode: 'light' },
        slack: { name: 'Slack Sidebar', color: '#611f69', mode: 'light' },
        airbnb: { name: 'Airbnb Pink', color: '#ff5a5f', mode: 'light' },
        uber: { name: 'Uber Black', color: '#ffffff', mode: 'dark' },
        sapphire: { name: 'Sapphire Glass', color: '#2563eb', mode: 'light' },
        nebula: { name: 'Nebula', color: '#c026d3', mode: 'dark' },
        aurora: { name: 'Aurora', color: '#06b6d4', mode: 'light' },
        phoenix: { name: 'Phoenix', color: '#ef4444', mode: 'light' },
        sakura: { name: 'Sakura', color: '#ec4899', mode: 'light' },
        sunset: { name: 'Sunset', color: '#f97316', mode: 'light' },
        rose: { name: 'Rose', color: '#fb7185', mode: 'light' },
        slate: { name: 'Slate', color: '#64748b', mode: 'light' },
        emerald: { name: 'Emerald', color: '#10b981', mode: 'light' },
        ocean: { name: 'Ocean', color: '#0ea5e9', mode: 'light' },
        'midnight-teal': { name: 'Midnight Teal', color: '#14b8a6', mode: 'dark' },
        cyber: { name: 'Cyber', color: '#00ff41', mode: 'dark' },
        'cosmic-aurora': { name: 'Cosmic Aurora', color: '#a855f7', mode: 'dark' }
    });

    function safeStorageGet(key) {
        try { return localStorage.getItem(key); } catch (_) { return null; }
    }

    function safeStorageSet(key, value) {
        try { localStorage.setItem(key, value); } catch (_) {}
    }

    function safeStorageRemove(key) {
        try { localStorage.removeItem(key); } catch (_) {}
    }

    function hasTheme(themeKey) {
        return Object.prototype.hasOwnProperty.call(themes, themeKey);
    }

    function getCurrentTheme() {
        const forced = document.documentElement.dataset.forceTheme;
        if (hasTheme(forced)) return forced;
        const saved = safeStorageGet(STORAGE_KEYS.theme);
        return hasTheme(saved) ? saved : DEFAULT_THEME;
    }

    function applyTheme(themeKey) {
        const forced = document.documentElement.dataset.forceTheme;
        const safeTheme = hasTheme(forced) ? forced : (hasTheme(themeKey) ? themeKey : DEFAULT_THEME);
        const theme = themes[safeTheme];

        document.documentElement.setAttribute('data-theme', safeTheme);
        document.documentElement.setAttribute('data-bs-theme', theme.mode);
        document.documentElement.style.setProperty('color-scheme', theme.mode);

        if (!hasTheme(forced)) safeStorageSet(STORAGE_KEYS.theme, safeTheme);

        document.querySelectorAll('[data-auth-theme-select]').forEach((select) => {
            select.value = safeTheme;
            select.disabled = hasTheme(forced);
        });
    }

    function buildThemeSelector(select) {
        if (!select) return;
        const fragment = document.createDocumentFragment();
        Object.entries(themes).forEach(([key, theme]) => {
            const option = document.createElement('option');
            option.value = key;
            option.textContent = theme.name;
            option.dataset.mode = theme.mode;
            option.dataset.color = theme.color;
            fragment.appendChild(option);
        });
        select.innerHTML = '';
        select.appendChild(fragment);
        select.value = getCurrentTheme();
    }

    function isValidEmail(value) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(value).trim());
    }

    function readRememberedEmail() {
        const raw = safeStorageGet(STORAGE_KEYS.rememberedEmail);
        if (!raw) return '';
        try {
            const parsed = JSON.parse(raw);
            const fresh = parsed.savedAt && Date.now() - parsed.savedAt < REMEMBER_EMAIL_MAX_AGE_MS;
            if (fresh && isValidEmail(parsed.email)) return parsed.email;
        } catch (_) {
            if (isValidEmail(raw)) return raw;
        }
        safeStorageRemove(STORAGE_KEYS.rememberedEmail);
        return '';
    }

    function saveRememberedEmail(email, remember) {
        if (!remember) {
            safeStorageRemove(STORAGE_KEYS.rememberedEmail);
            return;
        }
        safeStorageSet(STORAGE_KEYS.rememberedEmail, JSON.stringify({
            email: String(email || '').trim(),
            savedAt: Date.now()
        }));
    }

    function createSpinner() {
        return '<span class="auth-btn-spinner" aria-hidden="true"></span>';
    }

    function getFields(form) {
        return Array.from(form.querySelectorAll('[data-validate]'));
    }

    function getFieldFeedback(form, field) {
        return form.querySelector(`[data-feedback-for="${field.id}"]`);
    }

    function setFieldState(form, field, valid, message) {
        const group = field.closest('.auth-control-group, .input-group');
        const feedback = getFieldFeedback(form, field);
        field.classList.toggle('is-invalid', !valid);
        field.classList.toggle('is-valid', valid && field.value !== '' && field.type !== 'checkbox');
        if (group) {
            group.classList.toggle('is-invalid', !valid);
            group.classList.toggle('is-valid', valid && field.value !== '' && field.type !== 'checkbox');
        }
        if (field.type === 'checkbox') field.classList.toggle('is-invalid', !valid);
        if (feedback) {
            const msg = feedback.querySelector('[data-feedback-message]');
            if (msg && message) msg.textContent = message;
            feedback.classList.toggle('is-visible', !valid);
            feedback.style.display = valid ? '' : 'flex';
        }
        if (valid) field.removeAttribute('aria-invalid');
        else field.setAttribute('aria-invalid', 'true');
    }

    function validateField(form, field) {
        const rules = String(field.dataset.validate || '').split('|').filter(Boolean);
        const label = field.dataset.label || field.getAttribute('name') || 'This field';
        const value = String(field.value || '').trim();

        if (rules.includes('checkbox') && !field.checked) {
            setFieldState(form, field, false, field.dataset.errorRequired || `Please accept ${label}.`);
            return false;
        }
        if (rules.includes('required') && !value) {
            setFieldState(form, field, false, field.dataset.errorRequired || `${label} is required.`);
            return false;
        }
        if (rules.includes('email') && value && !isValidEmail(value)) {
            setFieldState(form, field, false, field.dataset.errorEmail || 'Please enter a valid email address.');
            return false;
        }
        if (rules.includes('password') && value) {
            const min = Number(field.dataset.minLength || 8);
            if (value.length < min) {
                setFieldState(form, field, false, field.dataset.errorPassword || `Password must be at least ${min} characters.`);
                return false;
            }
        }
        if (rules.includes('confirm')) {
            const target = form.querySelector(field.dataset.match);
            if (target && value !== target.value) {
                setFieldState(form, field, false, field.dataset.errorConfirm || 'Passwords do not match.');
                return false;
            }
        }
        setFieldState(form, field, true, '');
        return true;
    }

    function scorePassword(value) {
        let score = 0;
        if (value.length >= 8) score += 1;
        if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score += 1;
        if (/\d/.test(value)) score += 1;
        if (/[^A-Za-z0-9]/.test(value)) score += 1;
        return score;
    }

    function updatePasswordStrength(form, input) {
        const value = input.value || '';
        const score = scorePassword(value);
        const bar = form.querySelector(input.dataset.passwordStrength || '');
        if (bar) bar.dataset.strength = String(score);

        form.querySelectorAll(`[data-rule-for="${input.id}"]`).forEach((rule) => {
            const type = rule.dataset.rule;
            const valid =
                (type === 'length' && value.length >= 8) ||
                (type === 'case' && /[a-z]/.test(value) && /[A-Z]/.test(value)) ||
                (type === 'number' && /\d/.test(value)) ||
                (type === 'symbol' && /[^A-Za-z0-9]/.test(value));
            rule.classList.toggle('is-valid', valid);
            const icon = rule.querySelector('i');
            if (icon) icon.className = valid ? 'bi bi-check-circle-fill me-1' : 'bi bi-circle me-1';
        });
    }

    function updateOtp(form) {
        const inputs = Array.from(form.querySelectorAll('[data-otp-input]'));
        const hidden = form.querySelector('[data-otp-hidden]');
        const value = inputs.map((input) => input.value.replace(/\D/g, '')).join('');
        if (hidden) hidden.value = value;
        return value;
    }

    function setOtpState(form, valid, message) {
        const grid = form.querySelector('[data-otp-grid]');
        const feedback = form.querySelector('[data-otp-feedback]');
        if (grid) {
            grid.classList.toggle('is-invalid', !valid);
            grid.classList.toggle('is-valid', valid);
        }
        if (feedback) {
            const msg = feedback.querySelector('[data-feedback-message]');
            if (msg && message) msg.textContent = message;
            feedback.classList.toggle('is-visible', !valid);
            feedback.style.display = valid ? '' : 'flex';
        }
    }

    function validateOtp(form) {
        const inputs = Array.from(form.querySelectorAll('[data-otp-input]'));
        if (!inputs.length) return true;
        const code = updateOtp(form);
        const valid = /^\d{6}$/.test(code);
        setOtpState(form, valid, 'Enter the 6-digit security code.');
        return valid;
    }

    function serializeForm(form) {
        const data = new FormData(form);
        return Object.fromEntries(data.entries());
    }

    function showAlert(form, type, message) {
        const alert = form.querySelector('[data-auth-alert]');
        const icon = form.querySelector('[data-auth-alert-icon]');
        const msg = form.querySelector('[data-auth-alert-message]');
        if (!alert || !msg) return;
        alert.className = `auth-alert is-visible is-${type || 'info'}`;
        msg.textContent = message || '';
        if (icon) {
            icon.className = type === 'success' ? 'bi bi-check-circle-fill' : type === 'danger' ? 'bi bi-exclamation-triangle-fill' : 'bi bi-info-circle-fill';
        }
    }

    function setFormLoading(form, isLoading) {
        const button = form.querySelector('[data-auth-submit-button]');
        if (!button) return;
        if (isLoading) {
            button.dataset.originalText = button.innerHTML;
            button.innerHTML = `${createSpinner()}<span>${button.dataset.loadingText || 'Processing...'}</span>`;
            button.disabled = true;
            form.querySelectorAll('input, button, select, textarea').forEach((el) => {
                if (el !== button && !el.hasAttribute('data-auth-theme-select')) el.disabled = true;
            });
        } else {
            button.innerHTML = button.dataset.originalText || button.textContent;
            button.disabled = false;
            form.querySelectorAll('input, button, select, textarea').forEach((el) => { el.disabled = false; });
            const forced = document.documentElement.dataset.forceTheme;
            if (forced) document.querySelectorAll('[data-auth-theme-select]').forEach((el) => { el.disabled = true; });
        }
    }

    async function ajaxSubmit(form) {
        const response = await fetch(form.action, {
            method: form.method || 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(serializeForm(form))
        });
        if (!response.ok) throw new Error('Request failed. Please try again.');
        return response.json().catch(() => ({}));
    }

    class AuthForm {
        constructor(form) {
            this.form = form;
            this.touched = new WeakSet();
            this.handleSubmit = this.handleSubmit.bind(this);
        }

        init() {
            this.bindValidation();
            this.bindOtp();
            this.bindRememberedEmail();
            this.form.addEventListener('submit', this.handleSubmit);
        }

        bindValidation() {
            getFields(this.form).forEach((field) => {
                if (field.dataset.passwordStrength) updatePasswordStrength(this.form, field);
                field.addEventListener('input', () => {
                    if (field.dataset.passwordStrength) updatePasswordStrength(this.form, field);
                    if (this.touched.has(field)) validateField(this.form, field);
                    getFields(this.form).filter((f) => f.dataset.match === `#${field.id}`).forEach((confirm) => {
                        if (this.touched.has(confirm)) validateField(this.form, confirm);
                    });
                });
                field.addEventListener('blur', () => {
                    this.touched.add(field);
                    validateField(this.form, field);
                });
                if (field.type === 'checkbox') {
                    field.addEventListener('change', () => validateField(this.form, field));
                }
            });
        }

        bindRememberedEmail() {
            const remember = this.form.querySelector('[data-auth-remember]');
            const email = this.form.querySelector('[data-auth-email]');
            if (!remember || !email) return;
            const remembered = readRememberedEmail();
            if (remembered && !email.value) {
                email.value = remembered;
                remember.checked = true;
            }
        }

        bindOtp() {
            const inputs = Array.from(this.form.querySelectorAll('[data-otp-input]'));
            if (!inputs.length) return;
            inputs.forEach((input, index) => {
                input.addEventListener('input', () => {
                    input.value = input.value.replace(/\D/g, '').slice(0, 1);
                    if (input.value && inputs[index + 1]) inputs[index + 1].focus();
                    updateOtp(this.form);
                    setOtpState(this.form, true, '');
                });
                input.addEventListener('keydown', (event) => {
                    if (event.key === 'Backspace' && !input.value && inputs[index - 1]) inputs[index - 1].focus();
                    if (event.key === 'ArrowLeft' && inputs[index - 1]) inputs[index - 1].focus();
                    if (event.key === 'ArrowRight' && inputs[index + 1]) inputs[index + 1].focus();
                });
                input.addEventListener('paste', (event) => {
                    event.preventDefault();
                    const text = (event.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, inputs.length);
                    text.split('').forEach((char, i) => { if (inputs[i]) inputs[i].value = char; });
                    updateOtp(this.form);
                    if (inputs[Math.min(text.length, inputs.length) - 1]) inputs[Math.min(text.length, inputs.length) - 1].focus();
                });
            });
        }

        validate() {
            const fieldsValid = getFields(this.form).map((field) => validateField(this.form, field)).every(Boolean);
            const otpValid = validateOtp(this.form);
            return fieldsValid && otpValid;
        }

        async handleSubmit(event) {
            if (!this.validate()) {
                event.preventDefault();
                const firstInvalid = this.form.querySelector('.is-invalid, [aria-invalid="true"]');
                if (firstInvalid) firstInvalid.focus({ preventScroll: false });
                showAlert(this.form, 'danger', 'Please fix the highlighted fields and try again.');
                return;
            }

            const remember = this.form.querySelector('[data-auth-remember]');
            const email = this.form.querySelector('[data-auth-email]');
            if (remember && email) saveRememberedEmail(email.value, remember.checked);

            const submitEvent = new CustomEvent('auth:submit', {
                bubbles: true,
                cancelable: true,
                detail: { form: this.form, data: serializeForm(this.form) }
            });
            this.form.dispatchEvent(submitEvent);

            if (submitEvent.defaultPrevented) {
                event.preventDefault();
                return;
            }

            if (this.form.dataset.authAjax === 'true') {
                event.preventDefault();
                setFormLoading(this.form, true);
                try {
                    const result = await ajaxSubmit(this.form);
                    showAlert(this.form, 'success', result.message || this.form.dataset.successMessage || 'Request completed successfully.');
                } catch (error) {
                    showAlert(this.form, 'danger', error.message || 'Request failed. Please try again.');
                } finally {
                    setFormLoading(this.form, false);
                }
            }
        }
    }

    function initPasswordToggles() {
        document.querySelectorAll('[data-password-toggle]').forEach((button) => {
            const target = document.getElementById(button.getAttribute('aria-controls')) || button.closest('.input-group, .auth-control-group')?.querySelector('input');
            if (!target) return;
            button.addEventListener('click', () => {
                const show = target.type === 'password';
                target.type = show ? 'text' : 'password';
                button.setAttribute('aria-pressed', String(show));
                button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
                const icon = button.querySelector('i');
                if (icon) icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
                target.focus();
            });
        });
    }

    function initResendButtons() {
        document.querySelectorAll('[data-auth-resend]').forEach((button) => {
            button.addEventListener('click', () => {
                const form = button.closest('form');
                const seconds = Number(button.dataset.cooldown || 30);
                const original = button.dataset.defaultText || button.textContent;
                let left = seconds;
                button.disabled = true;
                showAlert(form, 'info', button.dataset.resendMessage || 'A new code has been sent.');
                const timer = setInterval(() => {
                    button.textContent = `Resend in ${left}s`;
                    left -= 1;
                    if (left < 0) {
                        clearInterval(timer);
                        button.disabled = false;
                        button.textContent = original;
                    }
                }, 1000);
            });
        });
    }

    function initLockClock() {
        const clock = document.querySelector('[data-lock-clock]');
        if (!clock) return;
        const update = () => {
            clock.textContent = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date());
        };
        update();
        setInterval(update, 30000);
    }



    function initUtilityCountdowns() {
        document.querySelectorAll('[data-auth-countdown]').forEach((container) => {
            const targetRaw = container.dataset.targetDate;
            const targetDate = targetRaw ? new Date(targetRaw) : new Date(Date.now() + 1000 * 60 * 60 * 24 * 21);
            const parts = {
                days: container.querySelector('[data-countdown-days]'),
                hours: container.querySelector('[data-countdown-hours]'),
                minutes: container.querySelector('[data-countdown-minutes]'),
                seconds: container.querySelector('[data-countdown-seconds]')
            };
            const pad = (value) => String(value).padStart(2, '0');
            const update = () => {
                const diff = Math.max(0, targetDate.getTime() - Date.now());
                const days = Math.floor(diff / 86400000);
                const hours = Math.floor((diff % 86400000) / 3600000);
                const minutes = Math.floor((diff % 3600000) / 60000);
                const seconds = Math.floor((diff % 60000) / 1000);
                if (parts.days) parts.days.textContent = pad(days);
                if (parts.hours) parts.hours.textContent = pad(hours);
                if (parts.minutes) parts.minutes.textContent = pad(minutes);
                if (parts.seconds) parts.seconds.textContent = pad(seconds);
            };
            update();
            setInterval(update, 1000);
        });
    }

    function initUtilityActions() {
        document.querySelectorAll('[data-auth-retry]').forEach((button) => {
            button.addEventListener('click', () => {
                const card = button.closest('.auth-card') || document;
                const original = button.innerHTML;
                button.disabled = true;
                button.innerHTML = `${createSpinner()}<span>${button.dataset.loadingText || 'Checking...'}</span>`;
                setTimeout(() => {
                    const online = navigator.onLine;
                    showAlert(card, online ? 'success' : 'info', online ? 'Connection restored. You can continue.' : 'Still offline. Please check your network and try again.');
                    button.disabled = false;
                    button.innerHTML = original;
                }, 900);
            });
        });
    }

    function initTheme() {
        document.querySelectorAll('[data-auth-theme-select]').forEach((select) => {
            buildThemeSelector(select);
            select.addEventListener('change', () => applyTheme(select.value));
        });
        applyTheme(getCurrentTheme());
    }

    document.addEventListener('DOMContentLoaded', () => {
        initTheme();
        initPasswordToggles();
        initResendButtons();
        initLockClock();
        initUtilityCountdowns();
        initUtilityActions();
        document.querySelectorAll('[data-auth-form]').forEach((form) => new AuthForm(form).init());
    });

    window.UttamAuth = Object.freeze({
        applyTheme,
        showAlert,
        setFormLoading,
        serializeForm,
        themes
    });
})();
