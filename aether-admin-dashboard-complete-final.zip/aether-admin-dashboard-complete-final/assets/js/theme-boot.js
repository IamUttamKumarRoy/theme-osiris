/* ========================================================================
   Aether Auth Theme Boot
   Runs before CSS to prevent theme flash.
======================================================================== */
(function () {
    'use strict';

    try {
        var themeModes = {
            light: 'light', dark: 'dark', obsidian: 'dark', vercel: 'dark', 'deep-space': 'dark', netflix: 'dark',
            microsoft: 'light', google: 'light', apple: 'light', vscode: 'dark', aws: 'dark', royal: 'light',
            spotify: 'dark', figma: 'light', slack: 'light', airbnb: 'light', uber: 'dark', sapphire: 'light',
            nebula: 'dark', aurora: 'light', phoenix: 'light', sakura: 'light', sunset: 'light', rose: 'light',
            slate: 'light', emerald: 'light', ocean: 'light', 'midnight-teal': 'dark', cyber: 'dark', 'cosmic-aurora': 'dark'
        };

        var root = document.documentElement;
        var forcedTheme = root.getAttribute('data-force-theme');
        var defaultTheme = root.getAttribute('data-default-theme') || 'cosmic-aurora';
        var savedTheme = localStorage.getItem('uttam-theme');
        var theme = themeModes[forcedTheme] ? forcedTheme : (themeModes[savedTheme] ? savedTheme : defaultTheme);
        var mode = themeModes[theme] || 'dark';

        root.setAttribute('data-theme', theme);
        root.setAttribute('data-bs-theme', mode);
        root.style.colorScheme = mode;
    } catch (_) {}
})();
