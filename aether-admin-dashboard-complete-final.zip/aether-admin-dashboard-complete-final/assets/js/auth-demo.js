/* ========================================================================
   Aether Auth Demo Adapter
   Front-end demo only. Remove this file in production and connect forms to
   your backend endpoints or use data-auth-ajax="true".
======================================================================== */
(function () {
    'use strict';

    function friendlyFlowName(form) {
        return form.dataset.authFlow || 'auth';
    }

    document.addEventListener('auth:submit', function (event) {
        event.preventDefault();
        const form = event.detail.form;
        const flow = friendlyFlowName(form);
        const successMessage = form.dataset.successMessage || 'Request completed successfully.';
        const redirect = form.dataset.redirect;

        window.UttamAuth.setFormLoading(form, true);

        window.setTimeout(function () {
            const suffix = redirect ? ' Demo redirect target: ' + redirect : '';
            window.UttamAuth.showAlert(form, 'success', successMessage + suffix);
            window.UttamAuth.setFormLoading(form, false);
        }, flow === 'social' ? 500 : 800);
    });

    document.addEventListener('click', function (event) {
        const button = event.target.closest('[data-social-provider]');
        if (!button) return;
        const form = button.closest('form') || document.querySelector('[data-auth-form]');
        const provider = button.dataset.socialProvider || 'provider';
        button.disabled = true;
        if (form) window.UttamAuth.showAlert(form, 'info', 'Connecting to ' + provider + ' demo flow...');
        window.setTimeout(function () {
            button.disabled = false;
            if (form) window.UttamAuth.showAlert(form, 'success', provider + ' login is ready for backend integration.');
        }, 700);
    });
})();
