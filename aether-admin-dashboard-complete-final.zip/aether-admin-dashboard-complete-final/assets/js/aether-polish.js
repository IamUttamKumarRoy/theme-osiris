(function(){
  'use strict';
  function showToast(message){
    if(!message) return;
    var toast=document.querySelector('.aether-toast');
    if(!toast){toast=document.createElement('div');toast.className='aether-toast';toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');document.body.appendChild(toast)}
    toast.textContent=message;
    toast.classList.add('is-visible');
    clearTimeout(window.__aetherToastTimer);
    window.__aetherToastTimer=setTimeout(function(){toast.classList.remove('is-visible')},2200);
  }
  document.addEventListener('click',function(e){
    var btn=e.target.closest('[data-toast]');
    if(btn) showToast(btn.getAttribute('data-toast'));
  });
})();


/* AETHER_FINAL_FIX_PASS */
(function(){'use strict';function ready(fn){if(document.readyState!=='loading')fn();else document.addEventListener('DOMContentLoaded',fn)}ready(function(){var nav=document.querySelector('.admin-sidebar__nav');if(nav&&!location.hash)nav.scrollTop=0;document.querySelectorAll('[data-toast]').forEach(function(btn){btn.addEventListener('click',function(){var msg=btn.getAttribute('data-toast')||'Action completed';var toast=document.querySelector('.aether-toast');if(!toast){toast=document.createElement('div');toast.className='aether-toast';document.body.appendChild(toast)}toast.textContent=msg;toast.classList.add('is-visible');clearTimeout(window.__aetherToastTimer);window.__aetherToastTimer=setTimeout(function(){toast.classList.remove('is-visible')},2200)})})})})();
