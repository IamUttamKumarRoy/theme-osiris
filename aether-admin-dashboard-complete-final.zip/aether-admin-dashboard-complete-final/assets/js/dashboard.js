/* Aether Full Admin Template JS */
(function(){
  'use strict';
  const allowedThemes=['light','dark','obsidian','vercel','deep-space','netflix','microsoft','google','apple','vscode','aws','royal','spotify','figma','slack','airbnb','uber','sapphire','nebula','aurora','phoenix','sakura','sunset','rose','slate','emerald','ocean','midnight-teal','cyber'];
  const labels={light:'Light',dark:'Dark',obsidian:'Obsidian',vercel:'Vercel Black','deep-space':'Deep Space',netflix:'Netflix Red',microsoft:'Microsoft Fluent',google:'Google Material 3',apple:'Apple SF',vscode:'VSCode Dark',aws:'AWS Orange',royal:'Royal',spotify:'Spotify Green',figma:'Figma Purple',slack:'Slack Sidebar',airbnb:'Airbnb Pink',uber:'Uber Black',sapphire:'Sapphire Glass',nebula:'Nebula',aurora:'Aurora',phoenix:'Phoenix',sakura:'Sakura',sunset:'Sunset',rose:'Rose',slate:'Slate',emerald:'Emerald',ocean:'Ocean','midnight-teal':'Midnight Teal',cyber:'Cyber'};
  const root=document.documentElement, wrapper=document.getElementById('adminWrapper'), sidebar=document.getElementById('sidebar'), sidebarToggle=document.getElementById('sidebarCollapse'), overlay=document.getElementById('sidebarOverlay'), header=document.querySelector('.admin-header');
  const swatches=Array.from(document.querySelectorAll('.theme-swatch')), themeLabel=document.getElementById('themePreviewLabel'), themeSearch=document.getElementById('themeSearch'), noResults=document.getElementById('themeNoResults');
  const commandBackdrop=document.getElementById('commandPaletteBackdrop'), commandInput=document.getElementById('commandPaletteInput'), commandList=document.getElementById('commandPaletteList');

  function accent(){return getComputedStyle(root).getPropertyValue('--t-accent').trim()||'#38bdf8'}
  function applyTheme(theme,label){
    if(!allowedThemes.includes(theme)) return;
    root.setAttribute('data-theme',theme);
    root.style.colorScheme=['light','microsoft','google','apple','aws','sapphire','aurora','sakura','sunset','rose','slate','emerald','ocean'].includes(theme)?'light':'dark';
    try{localStorage.setItem('aether-theme',theme)}catch(_){}
    swatches.forEach(btn=>{const active=btn.dataset.theme===theme;btn.classList.toggle('is-active',active);btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',active?'true':'false')});
    if(themeLabel) themeLabel.textContent=label||labels[theme]||theme;
    const meta=document.getElementById('metaThemeColor'); if(meta) requestAnimationFrame(()=>meta.setAttribute('content',accent()));
    document.querySelectorAll('.js-theme-avatar[data-avatar-name]').forEach(img=>{img.src='https://ui-avatars.com/api/?name='+encodeURIComponent(img.dataset.avatarName||'User')+'&background='+accent().replace('#','')+'&color=0f172a&bold=true&size=34'});
  }
  function initTheme(){
    let saved=null;try{saved=localStorage.getItem('aether-theme')}catch(_){}
    const initial=allowedThemes.includes(saved)?saved:(allowedThemes.includes(root.getAttribute('data-theme'))?root.getAttribute('data-theme'):'light');
    applyTheme(initial,labels[initial]);
    swatches.forEach(btn=>{
      btn.setAttribute('aria-pressed','false');
      btn.addEventListener('click',()=>applyTheme(btn.dataset.theme,btn.title||labels[btn.dataset.theme]));
      btn.addEventListener('mouseenter',()=>{if(themeLabel)themeLabel.textContent=btn.title||labels[btn.dataset.theme]||btn.dataset.theme});
    });
    themeSearch?.addEventListener('input',()=>{
      const q=themeSearch.value.trim().toLowerCase();let visible=0;
      swatches.forEach(btn=>{const text=[btn.title,btn.dataset.theme,labels[btn.dataset.theme]].join(' ').toLowerCase();const ok=text.includes(q);btn.hidden=!ok;if(ok)visible++});
      document.querySelectorAll('.theme-grid').forEach(grid=>{grid.hidden=!Array.from(grid.querySelectorAll('.theme-swatch')).some(btn=>!btn.hidden)});
      document.querySelectorAll('.theme-group-label').forEach(label=>{const grid=label.nextElementSibling;label.hidden=grid&&grid.classList.contains('theme-grid')?grid.hidden:false});
      if(noResults) noResults.hidden=visible>0;
    });
  }

  function openMobileSidebar(){sidebar?.classList.add('sidebar-open','active');overlay?.classList.add('active');sidebarToggle?.setAttribute('aria-expanded','true');document.body.style.overflow='hidden'}
  function closeMobileSidebar(){sidebar?.classList.remove('sidebar-open','active');overlay?.classList.remove('active');sidebarToggle?.setAttribute('aria-expanded','false');document.body.style.overflow=''}
  function initSidebar(){
    sidebarToggle?.addEventListener('click',()=>{
      if(window.matchMedia('(max-width: 767.98px)').matches){
        (sidebar?.classList.contains('sidebar-open')||sidebar?.classList.contains('active'))?closeMobileSidebar():openMobileSidebar();
      }else{
        wrapper?.classList.toggle('sidebar-collapsed');
        sidebarToggle.setAttribute('aria-expanded',wrapper?.classList.contains('sidebar-collapsed')?'false':'true');
      }
    });
    overlay?.addEventListener('click',closeMobileSidebar);
    window.addEventListener('resize',()=>{if(!window.matchMedia('(max-width: 767.98px)').matches)closeMobileSidebar()});
  }

  function initHeader(){function update(){header?.classList.toggle('is-scrolled',window.scrollY>8)}update();window.addEventListener('scroll',update,{passive:true})}

  const commands=[
    ['Dashboard Overview','dashboard.html','bi-speedometer2'],
    ['Template Index','index.html','bi-grid-1x2'],
    ['Aether Production','dashboards/dashboard-aether-production.html','bi-speedometer2'],
    ['Analytics','dashboards/dashboard-analytics.html','bi-graph-up-arrow'],
    ['CRM Dashboard','dashboards/dashboard-crm.html','bi-people'],
    ['Ecommerce Dashboard','dashboards/dashboard-ecommerce.html','bi-bag-check'],
    ['Marketing','dashboards/dashboard-marketing.html','bi-megaphone'],
    ['Projects','dashboards/dashboard-projects.html','bi-kanban'],
    ['No Sidebar Dashboard','dashboards/dashboard-aether-nosidebar.html','bi-layout-sidebar-inset'],
    ['Dark Dashboard','dashboards/dashboard-dark.html','bi-moon-stars'],
    ['Minimal Dashboard','dashboards/dashboard-minimal.html','bi-window'],
    ['RTL Dashboard','dashboards/dashboard-rtl.html','bi-arrow-left-right'],
    ['Create User','users/create-user.html','bi-person-plus'],
    ['Edit User','users/edit-user.html','bi-pencil-square'],
    ['Invite User','users/invite-user.html','bi-envelope-plus'],
    ['Organization Members','users/organization-members.html','bi-building'],
    ['User Activity','users/user-activity.html','bi-activity'],
    ['User Details','users/user-details.html','bi-person-badge'],
    ['User Grid','users/user-grid.html','bi-grid-3x3-gap'],
    ['User List','users/user-list.html','bi-list-ul'],
    ['User Profile','users/user-profile.html','bi-person-circle'],
    ['User Sessions','users/user-sessions.html','bi-clock-history'],
    ['Create Role','roles/create-role.html','bi-shield-plus'],
    ['Role Details','roles/role-details.html','bi-shield'],
    ['Roles Permissions','roles/roles-permissions.html','bi-sliders'],
    ['Access Control','security/access-control.html','bi-shield-check'],
    ['Permission Matrix','security/permission-matrix.html','bi-key'],
    ['Role Management','security/role-management.html','bi-shield-lock'],
    ['Activity Log','security/activity-log.html','bi-clock-history'],
    ['Audit Reports','security/audit-reports.html','bi-clipboard-data'],
    ['GDPR Compliance','security/compliance-gdpr.html','bi-file-lock'],
    ['Security Logs','security/security-logs.html','bi-shield-exclamation'],
    ['System Status','security/system-status.html','bi-hdd-network'],
    ['Ecommerce Dashboard','ecommerce/ecommerce-dashboard.html','bi-speedometer2'],
    ['Orders','ecommerce/orders.html','bi-receipt'],
    ['Order Details','ecommerce/order-details.html','bi-receipt-cutoff'],
    ['Inventory','ecommerce/inventory.html','bi-boxes'],
    ['Products','ecommerce/products.html','bi-box-seam'],
    ['Product Details','ecommerce/product-details.html','bi-box'],
    ['Add Product','ecommerce/add-product.html','bi-plus-square'],
    ['Product Reviews','ecommerce/product-reviews.html','bi-star'],
    ['Customers','ecommerce/customers.html','bi-people'],
    ['Customer Details','ecommerce/customer-details.html','bi-person-vcard'],
    ['Coupons','ecommerce/coupons.html','bi-ticket-perforated'],
    ['Refunds','ecommerce/refunds.html','bi-arrow-counterclockwise'],
    ['Returns','ecommerce/returns.html','bi-arrow-return-left'],
    ['Shipping','ecommerce/shipping.html','bi-truck'],
    ['Payment Methods','ecommerce/payment-methods.html','bi-credit-card'],
    ['Pricing Plans','ecommerce/pricing-plans.html','bi-tags'],
    ['Invoice','ecommerce/invoice.html','bi-file-earmark-text'],
    ['Subscription Confirmed','ecommerce/subscription-confirmed.html','bi-patch-check'],
    ['Cart','ecommerce/cart.html','bi-cart'],
    ['Checkout','ecommerce/checkout.html','bi-credit-card-2-front'],
    ['Wishlist','ecommerce/wishlist.html','bi-heart'],
    ['Leads','crm/leads.html','bi-person-plus'],
    ['Lead Details','crm/lead-details.html','bi-person-lines-fill'],
    ['Deals','crm/deals.html','bi-currency-dollar'],
    ['Deal Details','crm/deal-details.html','bi-briefcase'],
    ['Pipeline','crm/pipeline.html','bi-kanban'],
    ['Customers','crm/customers.html','bi-people'],
    ['Customer Details','crm/customer-details.html','bi-person-vcard'],
    ['Activities','crm/activities.html','bi-calendar-check'],
    ['Reports','crm/reports.html','bi-bar-chart-line'],
    ['Help Center','support/help-center.html','bi-life-preserver'],
    ['FAQ','support/faq.html','bi-question-circle'],
    ['Support Tickets','support/support-tickets.html','bi-ticket-detailed'],
    ['Ticket Details','support/ticket-details.html','bi-card-checklist'],
    ['Create Ticket','support/create-ticket.html','bi-plus-circle'],
    ['Knowledge Base','support/knowledge-base.html','bi-journal-bookmark'],
    ['Blog List','blog/blog-list.html','bi-list-ul'],
    ['Blog Grid','blog/blog-grid.html','bi-grid-3x3-gap'],
    ['Blog Details','blog/blog-details.html','bi-file-richtext'],
    ['Create Post','blog/create-post.html','bi-pencil-square'],
    ['Edit Post','blog/edit-post.html','bi-pen'],
    ['Categories','blog/categories.html','bi-tags'],
    ['Comments','blog/comments.html','bi-chat-square-text'],
    ['Media Library','media/media-library.html','bi-images'],
    ['Upload Files','media/upload-files.html','bi-cloud-arrow-up'],
    ['File Details','media/file-details.html','bi-file-earmark'],
    ['Invoices','billing/invoices.html','bi-receipt'],
    ['Invoice Details','billing/invoice-details.html','bi-file-earmark-text'],
    ['Create Invoice','billing/create-invoice.html','bi-file-earmark-plus'],
    ['Payment History','billing/payment-history.html','bi-clock-history'],
    ['Subscriptions','billing/subscriptions.html','bi-arrow-repeat'],
    ['Subscription Details','billing/subscription-details.html','bi-card-list'],
    ['Billing Plans','billing/billing-plans.html','bi-tags'],
    ['Communication Dashboard','communication/communication-dashboard.html','bi-speedometer2'],
    ['Message Inbox','communication/message-inbox.html','bi-inbox'],
    ['Newsletter Management','communication/newsletter-management.html','bi-envelope-paper'],
    ['Team Collaboration','communication/team-collaboration.html','bi-people'],
    ['Chat','communication/chat.html','bi-chat-dots'],
    ['Video Meeting','communication/video-meeting.html','bi-camera-video'],
    ['Notifications','communication/notifications.html','bi-bell'],
    ['Contacts','communication/contacts.html','bi-person-rolodex'],
    ['Group Chat','communication/group-chat.html','bi-chat-dots'],
    ['Voice Call','communication/voice-call.html','bi-telephone'],
    ['Monitoring Dashboard','monitoring/monitoring-dashboard.html','bi-speedometer2'],
    ['Performance Monitoring','monitoring/performance-monitoring.html','bi-cpu'],
    ['Server Health','monitoring/server-health.html','bi-server'],
    ['Transactions','monitoring/transactions.html','bi-arrow-left-right'],
    ['Uptime Reports','monitoring/uptime-reports.html','bi-wifi'],
    ['Logs Viewer','monitoring/logs-viewer.html','bi-terminal'],
    ['SLA Tracking','monitoring/sla-tracking.html','bi-stopwatch'],
    ['Tables','data-tables/tables.html','bi-table'],
    ['Tables All','data-tables/tables-all.html','bi-table'],
    ['Search Results','data-tables/search-results.html','bi-search'],
    ['Datatables Advanced','data-tables/datatables-advanced.html','bi-table'],
    ['Export Tables','data-tables/export-tables.html','bi-download'],
    ['Pivot Tables','data-tables/pivot-tables.html','bi-grid'],
    ['Data Grid','data-tables/data-grid.html','bi-grid-3x3'],
    ['Charts Line','charts/charts-line.html','bi-graph-up'],
    ['Charts Bar','charts/charts-bar.html','bi-bar-chart'],
    ['Charts Pie','charts/charts-pie.html','bi-pie-chart'],
    ['Charts Heatmap','charts/charts-heatmap.html','bi-grid-3x3'],
    ['Charts Radial','charts/charts-radial.html','bi-circle'],
    ['Charts Candlestick','charts/charts-candlestick.html','bi-currency-exchange'],
    ['Charts Mixed','charts/charts-mixed.html','bi-bar-chart-line'],
    ['Charts Dashboard','charts/charts-dashboard.html','bi-speedometer2'],
    ['Forms Basic','forms/forms-basic.html','bi-input-cursor-text'],
    ['Forms Wizard','forms/forms-wizard.html','bi-signpost-split'],
    ['Forms Editors','forms/forms-editors.html','bi-pencil-square'],
    ['Forms File Upload','forms/forms-file-upload.html','bi-cloud-upload'],
    ['Forms Validation','forms/forms-validation.html','bi-check2-square'],
    ['Forms Advanced','forms/forms-advanced.html','bi-sliders'],
    ['Forms Layouts','forms/forms-layouts.html','bi-layout-text-window'],
    ['Forms Dark','forms/forms-dark.html','bi-moon-stars'],
    ['Project Management','projects/project-management.html','bi-kanban'],
    ['Project Kanban','projects/project-kanban.html','bi-columns-gap'],
    ['Project Calendar','projects/project-calendar.html','bi-calendar3'],
    ['Project Dashboard','projects/project-dashboard.html','bi-speedometer2'],
    ['Project Tasks','projects/project-tasks.html','bi-check2-square'],
    ['Project Reports','projects/project-reports.html','bi-file-bar-graph'],
    ['File Manager','productivity/file-manager.html','bi-folder2-open'],
    ['Email Compose','productivity/email-compose.html','bi-pencil-square'],
    ['Email Read','productivity/email-read.html','bi-envelope-open'],
    ['Email Starred','productivity/email-starred.html','bi-star'],
    ['Email Trash','productivity/email-trash.html','bi-trash'],
    ['Notes','productivity/notes.html','bi-journal-text'],
    ['Task Manager','productivity/task-manager.html','bi-check2-square'],
    ['Productivity Dashboard','productivity/productivity-dashboard.html','bi-speedometer2'],
    ['Landing Page','marketing/landing-page.html','bi-window'],
    ['Testimonials','marketing/testimonials.html','bi-chat-quote'],
    ['Contact','marketing/contact.html','bi-envelope'],
    ['Features','marketing/features.html','bi-stars'],
    ['Pricing','marketing/pricing.html','bi-tags'],
    ['Marketing Dashboard','marketing/marketing-dashboard.html','bi-speedometer2'],
    ['UI Overview','ui/ui-overview.html','bi-grid'],
    ['Accordions','ui/ui-accordions.html','bi-menu-button-wide'],
    ['Alerts','ui/ui-alerts.html','bi-exclamation-triangle'],
    ['Avatars','ui/ui-avatars.html','bi-person-circle'],
    ['Badges','ui/ui-badges.html','bi-award'],
    ['Breadcrumbs','ui/ui-breadcrumbs.html','bi-signpost'],
    ['Buttons','ui/ui-buttons.html','bi-square'],
    ['Cards','ui/ui-cards.html','bi-card-text'],
    ['Carousel','ui/ui-carousel.html','bi-images'],
    ['Dropdowns','ui/ui-dropdowns.html','bi-menu-down'],
    ['Empty States','ui/ui-empty-states.html','bi-inbox'],
    ['Forms','ui/ui-forms.html','bi-input-cursor'],
    ['Icons','ui/ui-icons.html','bi-bootstrap'],
    ['Input Groups','ui/ui-input-groups.html','bi-input-cursor-text'],
    ['List Groups','ui/ui-list-groups.html','bi-list'],
    ['Modals','ui/ui-modals.html','bi-window-stack'],
    ['Navs','ui/ui-navs.html','bi-menu-app'],
    ['Offcanvas','ui/ui-offcanvas.html','bi-layout-sidebar'],
    ['Pagination','ui/ui-pagination.html','bi-three-dots'],
    ['Popovers','ui/ui-popovers.html','bi-chat-square'],
    ['Progress','ui/ui-progress.html','bi-bar-chart-steps'],
    ['Spinners','ui/ui-spinners.html','bi-arrow-clockwise'],
    ['Tables','ui/ui-tables.html','bi-table'],
    ['Tabs','ui/ui-tabs.html','bi-segmented-nav'],
    ['Timelines','ui/ui-timelines.html','bi-clock-history'],
    ['Toasts','ui/ui-toasts.html','bi-chat-left-text'],
    ['Tooltips','ui/ui-tooltips.html','bi-info-circle'],
    ['Typography','ui/ui-typography.html','bi-type'],
    ['Utilities','ui/ui-utilities.html','bi-tools'],
    ['Widgets','ui/ui-widgets.html','bi-columns'],
    ['Installation','docs/installation.html','bi-download'],
    ['Customization','docs/customization.html','bi-sliders'],
    ['Changelog','docs/changelog.html','bi-clock-history'],
    ['Credits','docs/credits.html','bi-heart'],
    ['Folder Structure','docs/folder-structure.html','bi-folder2'],
    ['Plugin Guide','docs/plugin-guide.html','bi-plug'],
    ['Theme Guide','docs/theme-guide.html','bi-palette'],
    ['API Documentation','developer/api-documentation.html','bi-code-slash'],
    ['API Keys','developer/api-keys.html','bi-key'],
    ['Webhooks','developer/webhooks.html','bi-diagram-3'],
    ['Error Logs','developer/error-logs.html','bi-bug'],
    ['System Info','developer/system-info.html','bi-pc-display'],
    ['Version Control','developer/version-control.html','bi-git'],
    ['Privacy Policy','legal/privacy-policy.html','bi-file-lock'],
    ['Terms of Use','legal/terms.html','bi-file-earmark-text'],
    ['Login','auth/login.html','bi-box-arrow-in-right'],
    ['Register','auth/register.html','bi-person-plus'],
    ['Forgot Password','auth/forgot-password.html','bi-question-circle'],
    ['Reset Password','auth/reset-password.html','bi-arrow-repeat'],
    ['Email Verification','auth/email-verification.html','bi-envelope-check'],
    ['Two Factor Auth','auth/two-factor-auth.html','bi-shield-check'],
    ['Lock Screen','auth/lock-screen.html','bi-lock'],
    ['Social Login','auth/social-login.html','bi-google'],
    ['OTP Verification','auth/otp-verification.html','bi-123'],
    ['Password Strength','auth/password-strength.html','bi-shield-lock'],
    ['Auth Split Layout','auth/auth-split-layout.html','bi-layout-split'],
    ['Auth Dark','auth/auth-dark.html','bi-moon-stars'],
    ['Error 403','errors/error-403.html','bi-exclamation-triangle'],
    ['Error 404','errors/error-404.html','bi-exclamation-triangle'],
    ['Error 500','errors/error-500.html','bi-exclamation-triangle'],
    ['Maintenance Mode','errors/maintenance-mode.html','bi-tools'],
    ['Coming Soon','errors/coming-soon.html','bi-hourglass-split'],
    ['Offline','errors/offline.html','bi-wifi-off'],
    ['Under Construction','errors/under-construction.html','bi-cone-striped']
  ];
  function renderCommands(q=''){
    if(!commandList)return;const f=q.trim().toLowerCase();const items=commands.filter(([label])=>label.toLowerCase().includes(f));
    commandList.innerHTML=items.length?items.map(([label,href,icon])=>'<a class="command-palette__item text-decoration-none" href="'+window.__aetherBase+href+'"><i class="bi '+icon+'" aria-hidden="true"></i><span>'+label+'</span></a>').join(''):'<div class="command-palette__item text-muted">No matching command found.</div>';
  }
  function openCommand(){renderCommands('');commandBackdrop?.classList.add('show');commandBackdrop?.setAttribute('aria-hidden','false');setTimeout(()=>commandInput?.focus(),30)}
  function closeCommand(){commandBackdrop?.classList.remove('show');commandBackdrop?.setAttribute('aria-hidden','true');if(commandInput)commandInput.value=''}
  function initCommand(){
    document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openCommand()}if(e.key==='Escape'){closeCommand();closeMobileSidebar()}});
    commandInput?.addEventListener('input',()=>renderCommands(commandInput.value));
    commandBackdrop?.addEventListener('click',e=>{if(e.target===commandBackdrop)closeCommand()});
  }
  function initLogout(){document.addEventListener('click',e=>{const btn=e.target.closest('.js-logout');if(!btn)return;if(confirm('Are you sure you want to log out?'))window.location.href=window.__aetherBase+'auth/login.html'})}
  document.addEventListener('DOMContentLoaded',()=>{initTheme();initSidebar();initHeader();initCommand();initLogout()});
})();


/* ThemeForest Ready Enhancements */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    var wrapper = document.getElementById('adminWrapper');
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    var sidebarToggle = document.getElementById('sidebarCollapse');
    var globalSearch = document.getElementById('globalSearchInput');
    var commandBackdrop = document.getElementById('commandPaletteBackdrop');
    var commandInput = document.getElementById('commandPaletteInput');

    /* Ensure sidebar is visible by default on desktop */
    if (wrapper && window.matchMedia('(min-width: 768px)').matches) {
      wrapper.classList.remove('sidebar-collapsed');
    }

    /* Header search opens command palette */
    function openCommandPalette() {
      if (!commandBackdrop) return;
      commandBackdrop.classList.add('show');
      commandBackdrop.setAttribute('aria-hidden', 'false');
      setTimeout(function () {
        if (commandInput) commandInput.focus();
      }, 30);
    }

    if (globalSearch) {
      globalSearch.addEventListener('focus', openCommandPalette);
      globalSearch.addEventListener('click', openCommandPalette);
    }

    /* Escape closes mobile sidebar and command palette */
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;

      if (commandBackdrop && commandBackdrop.classList.contains('show')) {
        commandBackdrop.classList.remove('show');
        commandBackdrop.setAttribute('aria-hidden', 'true');
      }

      if (sidebar && sidebar.classList.contains('sidebar-open')) {
        sidebar.classList.remove('sidebar-open', 'active');
        if (overlay) overlay.classList.remove('active');
        if (sidebarToggle) sidebarToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      }
    });

    /* Auto active link based on current file */
    var currentFile = (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
    document.querySelectorAll('.admin-sidebar__nav a.nav-link[href], .sidebarnav a.nav-link[href]').forEach(function (link) {
      var hrefFile = (link.getAttribute('href') || '').split('/').pop().toLowerCase();
      if (hrefFile === currentFile || (currentFile === 'dashboard.html' && hrefFile === 'index.html')) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
        var collapse = link.closest('.collapse');
        if (collapse) collapse.classList.add('show');
        var trigger = collapse ? document.querySelector('[data-bs-target="#' + collapse.id + '"]') : null;
        if (trigger) trigger.setAttribute('aria-expanded', 'true');
      }
    });
  });
})();
