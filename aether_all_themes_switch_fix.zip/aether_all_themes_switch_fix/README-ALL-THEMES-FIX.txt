Aether All Themes Switch Fix

Files included:
- assets/css/aether-all-themes.css
- assets/js/aether-all-themes.js

Problem:
Your HTML contains 29 allowed themes, but theme switching may not visibly work if theme.css does not define full [data-theme="..."] token blocks for every theme.

This patch fixes all themes:
light, dark, obsidian, vercel, deep-space, netflix, microsoft, google, apple,
vscode, aws, royal, spotify, figma, slack, airbnb, uber, sapphire, nebula,
aurora, phoenix, sakura, sunset, rose, slate, emerald, ocean, midnight-teal, cyber.

Install:

1. Add the CSS file:
assets/css/aether-all-themes.css

2. Add the JS file:
assets/js/aether-all-themes.js

3. Use this load order in every HTML page:

<link rel="stylesheet" href="assets/css/theme.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/aether-all-themes.css">
<link rel="stylesheet" href="assets/css/aether-dashboard-production.css">
<link rel="stylesheet" href="assets/css/aether-dashboard-advanced.css">
<link rel="stylesheet" href="assets/css/aether-dropdown-zfix.css">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/dashboard.js"></script>
<script src="assets/js/aether-all-themes.js"></script>
<script src="assets/js/dashboard-zfix.js"></script>

For nested pages, use ../assets/... or ../../assets/... based on folder depth.

4. Make sure every theme button uses:
<button class="theme-swatch" data-theme="obsidian" title="Obsidian"></button>

The data-theme value must exactly match one item from allowedThemes.

Developer API:
You can switch theme from the console:
AetherTheme.set('cyber')
AetherTheme.set('obsidian')
AetherTheme.reset()
