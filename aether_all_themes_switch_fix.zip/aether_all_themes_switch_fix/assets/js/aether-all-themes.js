/* ============================================================================
   Aether All Themes Switcher Fix
   File: assets/js/aether-all-themes.js

   Load this AFTER Bootstrap and AFTER/INSTEAD OF dashboard.js.

   This script guarantees all allowed themes switch correctly:
   - Sets html[data-theme]
   - Persists to localStorage key adminuk-theme
   - Updates active swatches
   - Updates aria-pressed
   - Updates meta theme-color
   - Updates avatar accent color
   - Works on all nested pages
============================================================================ */

(function () {
  'use strict';

  const allowedThemes = [
    'light', 'dark', 'obsidian', 'vercel', 'deep-space', 'netflix',
    'microsoft', 'google', 'apple', 'vscode', 'aws', 'royal',
    'spotify', 'figma', 'slack', 'airbnb', 'uber', 'sapphire',
    'nebula', 'aurora', 'phoenix', 'sakura', 'sunset', 'rose',
    'slate', 'emerald', 'ocean', 'midnight-teal', 'cyber'
  ];

  const lightThemes = new Set([
    'light', 'microsoft', 'google', 'apple', 'airbnb', 'sapphire',
    'aurora', 'sakura', 'sunset', 'rose', 'slate', 'emerald', 'ocean'
  ]);

  const labels = {
    light: 'Light',
    dark: 'Dark',
    obsidian: 'Obsidian',
    vercel: 'Vercel Black',
    'deep-space': 'Deep Space',
    netflix: 'Netflix Red',
    microsoft: 'Microsoft Fluent',
    google: 'Google Material 3',
    apple: 'Apple SF',
    vscode: 'VSCode Dark',
    aws: 'AWS Orange',
    royal: 'Royal',
    spotify: 'Spotify Green',
    figma: 'Figma Purple',
    slack: 'Slack Sidebar',
    airbnb: 'Airbnb Pink',
    uber: 'Uber Black',
    sapphire: 'Sapphire Glass',
    nebula: 'Nebula',
    aurora: 'Aurora',
    phoenix: 'Phoenix',
    sakura: 'Sakura',
    sunset: 'Sunset',
    rose: 'Rose',
    slate: 'Slate',
    emerald: 'Emerald',
    ocean: 'Ocean',
    'midnight-teal': 'Midnight Teal',
    cyber: 'Cyber'
  };

  const root = document.documentElement;

  function isAllowed(theme) {
    return allowedThemes.includes(theme);
  }

  function cssVar(name, fallback) {
    const value = getComputedStyle(root).getPropertyValue(name).trim();
    return value || fallback;
  }

  function getSavedTheme() {
    try {
      return localStorage.getItem('adminuk-theme');
    } catch (_) {
      return null;
    }
  }

  function saveTheme(theme) {
    try {
      localStorage.setItem('adminuk-theme', theme);
    } catch (_) {}
  }

  function updateMetaThemeColor() {
    const meta = document.getElementById('metaThemeColor');
    if (!meta) return;

    requestAnimationFrame(function () {
      meta.setAttribute('content', cssVar('--t-accent', '#38bdf8'));
    });
  }

  function updateThemeSwatches(theme) {
    document.querySelectorAll('.theme-swatch').forEach(function (button) {
      const active = button.dataset.theme === theme;
      button.classList.toggle('is-active', active);
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }

  function updateThemeLabel(theme) {
    const label = document.getElementById('themePreviewLabel');
    if (label) {
      label.textContent = labels[theme] || theme;
    }
  }

  function updateAvatarColors() {
    const accent = cssVar('--t-accent', '#38bdf8').replace('#', '');
    document.querySelectorAll('.js-theme-avatar[data-avatar-name]').forEach(function (avatar) {
      const name = encodeURIComponent(avatar.dataset.avatarName || 'User');
      avatar.src = 'https://ui-avatars.com/api/?name=' + name + '&background=' + accent + '&color=0f172a&bold=true&size=34';
    });
  }

  function applyTheme(theme, options) {
    options = options || {};

    if (!isAllowed(theme)) {
      theme = 'light';
    }

    root.setAttribute('data-theme', theme);
    root.style.colorScheme = lightThemes.has(theme) ? 'light' : 'dark';

    // Helps Bootstrap 5.3 color-mode aware components if present.
    root.setAttribute('data-bs-theme', lightThemes.has(theme) ? 'light' : 'dark');

    saveTheme(theme);
    updateThemeSwatches(theme);
    updateThemeLabel(theme);
    updateMetaThemeColor();
    updateAvatarColors();

    if (!options.silent) {
      document.dispatchEvent(new CustomEvent('aether:themechange', {
        detail: {
          theme: theme,
          label: labels[theme] || theme
        }
      }));
    }
  }

  function initThemeFromStorage() {
    const saved = getSavedTheme();
    const current = root.getAttribute('data-theme');
    const theme = isAllowed(saved) ? saved : (isAllowed(current) ? current : 'light');
    applyTheme(theme, { silent: true });
  }

  function initSwatchClicks() {
    document.querySelectorAll('.theme-swatch').forEach(function (button) {
      const theme = button.dataset.theme;

      if (!isAllowed(theme)) {
        button.disabled = true;
        button.title = (button.title || theme) + ' (not configured)';
        return;
      }

      button.setAttribute('type', 'button');
      button.setAttribute('aria-pressed', 'false');

      button.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        applyTheme(theme);
      });

      button.addEventListener('mouseenter', function () {
        const label = document.getElementById('themePreviewLabel');
        if (label) {
          label.textContent = button.title || labels[theme] || theme;
        }
      });

      button.addEventListener('focus', function () {
        const label = document.getElementById('themePreviewLabel');
        if (label) {
          label.textContent = button.title || labels[theme] || theme;
        }
      });
    });

    const themeDropdown = document.getElementById('themeDropdown');
    if (themeDropdown) {
      themeDropdown.addEventListener('hidden.bs.dropdown', function () {
        updateThemeLabel(root.getAttribute('data-theme') || 'light');
      });
    }
  }

  function initThemeSearch() {
    const themeSearch = document.getElementById('themeSearch');
    const themeNoResults = document.getElementById('themeNoResults');

    if (!themeSearch) return;

    themeSearch.addEventListener('input', function () {
      const query = themeSearch.value.trim().toLowerCase();
      let visibleCount = 0;

      document.querySelectorAll('.theme-swatch').forEach(function (button) {
        const theme = button.dataset.theme || '';
        const text = [
          theme,
          labels[theme],
          button.title,
          button.getAttribute('aria-label')
        ].join(' ').toLowerCase();

        const matched = text.includes(query);
        button.hidden = !matched;
        if (matched) visibleCount++;
      });

      document.querySelectorAll('.theme-grid').forEach(function (grid) {
        const hasVisibleSwatch = Array.from(grid.querySelectorAll('.theme-swatch')).some(function (button) {
          return !button.hidden;
        });
        grid.hidden = !hasVisibleSwatch;
      });

      document.querySelectorAll('.theme-group-label').forEach(function (groupLabel) {
        const grid = groupLabel.nextElementSibling;
        if (grid && grid.classList.contains('theme-grid')) {
          groupLabel.hidden = grid.hidden;
        }
      });

      if (themeNoResults) {
        themeNoResults.hidden = visibleCount > 0;
      }
    });
  }

  function exposePublicAPI() {
    window.AetherTheme = {
      allowedThemes: allowedThemes.slice(),
      current: function () {
        return root.getAttribute('data-theme') || 'light';
      },
      set: applyTheme,
      reset: function () {
        applyTheme('light');
      }
    };
  }

  document.addEventListener('DOMContentLoaded', function () {
    initThemeFromStorage();
    initSwatchClicks();
    initThemeSearch();
    exposePublicAPI();
  });

  // Also apply early if script is loaded at end but DOMContentLoaded already happened.
  if (document.readyState !== 'loading') {
    initThemeFromStorage();
    exposePublicAPI();
  }
})();
