Aether Dropdown + Z-Index Fix

Files included:
- assets/css/aether-dropdown-zfix.css
- assets/js/dashboard-zfix.js

Install:

1. Copy both files into your project.

2. Add the CSS after all existing CSS files:

<link rel="stylesheet" href="assets/css/theme.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/aether-dashboard-production.css">
<link rel="stylesheet" href="assets/css/aether-dashboard-advanced.css">
<link rel="stylesheet" href="assets/css/aether-dropdown-zfix.css">

3. Add the JS after your main dashboard.js:

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/dashboard.js"></script>
<script src="assets/js/dashboard-zfix.js"></script>

For nested pages, adjust the path:

<link rel="stylesheet" href="../assets/css/aether-dropdown-zfix.css">
<script src="../assets/js/dashboard-zfix.js"></script>

What this fixes:
- Theme dropdown appears above cards and page content.
- User dropdown appears above page header and content.
- Notification dropdown appears above content.
- Theme swatch active state stays synced.
- Mobile sidebar and command palette have safer z-index layers.
