/* ============================================================================
   Aether Dropdown + Theme Z-Index Runtime Fix
   File: assets/js/dashboard-zfix.js

   Load this file AFTER dashboard.js.

   Purpose:
   - Adds parent stacking class when dropdown opens
   - Forces theme swatch active state consistency
   - Fixes Bootstrap dropdown stacking with transformed page content
============================================================================ */

(function () {
  'use strict';

  const root = document.documentElement;
  const dropdownParents = document.querySelectorAll('.admin-header .dropdown, .header-tools .dropdown');

  function elevateDropdown(event) {
    const dropdown = event.target.closest('.dropdown');
    if (!dropdown) return;

    dropdown.classList.add('auk-dropdown-open');

    document.querySelectorAll('.admin-header .dropdown').forEach((item) => {
      if (item !== dropdown) item.classList.remove('auk-dropdown-open');
    });
  }

  function resetDropdown(event) {
    const dropdown = event.target.closest('.dropdown');
    if (!dropdown) return;
    dropdown.classList.remove('auk-dropdown-open');
  }

  dropdownParents.forEach((dropdown) => {
    dropdown.addEventListener('show.bs.dropdown', elevateDropdown);
    dropdown.addEventListener('shown.bs.dropdown', elevateDropdown);
    dropdown.addEventListener('hide.bs.dropdown', resetDropdown);
    dropdown.addEventListener('hidden.bs.dropdown', resetDropdown);
  });

  document.addEventListener('click', function (event) {
    if (!event.target.closest('.admin-header .dropdown')) {
      document.querySelectorAll('.admin-header .dropdown.auk-dropdown-open').forEach((dropdown) => {
        dropdown.classList.remove('auk-dropdown-open');
      });
    }
  });

  function syncThemeSwatches() {
    const currentTheme = root.getAttribute('data-theme') || 'light';

    document.querySelectorAll('.theme-swatch').forEach((button) => {
      const active = button.dataset.theme === currentTheme;
      button.classList.toggle('is-active', active);
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });

    const label = document.getElementById('themePreviewLabel');
    const activeButton = document.querySelector('.theme-swatch.is-active');
    if (label && activeButton) {
      label.textContent = activeButton.title || currentTheme;
    }
  }

  document.addEventListener('DOMContentLoaded', syncThemeSwatches);
  document.addEventListener('click', function (event) {
    if (event.target.closest('.theme-swatch')) {
      setTimeout(syncThemeSwatches, 30);
    }
  });

  // Observe theme changes made by existing dashboard.js
  const observer = new MutationObserver(syncThemeSwatches);
  observer.observe(root, { attributes: true, attributeFilter: ['data-theme'] });
})();
