# Premium Authentication Pages

Generated pages:

- register.html
- forgot_password.html
- reset_password.html
- email_verification.html
- two-factor-auth.html
- lock-screen.html

Support files added:

- assets/css/auth-pages.css
- assets/js/auth-pages.js

Drop these files into the same project structure as your existing login page. The pages expect these existing assets to already be available:

- assets/vendor/bootstrap/css/bootstrap.min.css
- assets/vendor/bootstrap-icons/bootstrap-icons.css
- assets/css/theme_tokens.css
- assets/css/login.css
- assets/vendor/bootstrap/js/bootstrap.bundle.min.js

The forms are front-end/demo safe by default. To submit with JSON over fetch, add `data-auth-ajax="true"` to a form and keep the form `action`/`method` values pointed at your backend route.
