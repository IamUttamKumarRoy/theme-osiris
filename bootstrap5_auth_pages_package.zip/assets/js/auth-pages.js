(() => {
    'use strict';

    const STORAGE_KEYS = Object.freeze({
        theme: 'uttam-theme'
    });

    const themes = Object.freeze({
        'light': { name: 'Light', color: '#2563eb', mode: 'light' },
        'dark': { name: 'Dark', color: '#38bdf8', mode: 'dark' },
        'obsidian': { name: 'Obsidian', color: '#d4af37', mode: 'dark' },
        'vercel': { name: 'Vercel Black', color: '#ffffff', mode: 'dark' },
        'deep-space': { name: 'Deep Space', color: '#8b5cf6', mode: 'dark' },
        'netflix': { name: 'Netflix Red', color: '#e50914', mode: 'dark' },
        'microsoft': { name: 'Microsoft Fluent', color: '#0078d4', mode: 'light' },
        'google': { name: 'Google Material 3', color: '#6750a4', mode: 'light' },
        'apple': { name: 'Apple SF', color: '#007aff', mode: 'light' },
        'vscode': { name: 'VSCode Dark', color: '#007acc', mode: 'dark' },
        'aws': { name: 'AWS Orange', color: '#ff9900', mode: 'dark' },
        'royal': { name: 'Royal', color: '#9333ea', mode: 'light' },
        'spotify': { name: 'Spotify Green', color: '#1db954', mode: 'dark' },
        'figma': { name: 'Figma Purple', color: '#a259ff', mode: 'light' },
        'slack': { name: 'Slack Sidebar', color: '#611f69', mode: 'light' },
        'airbnb': { name: 'Airbnb Pink', color: '#ff5a5f', mode: 'light' },
        'uber': { name: 'Uber Black', color: '#ffffff', mode: 'dark' },
        'sapphire': { name: 'Sapphire Glass', color: '#2563eb', mode: 'light' },
        'nebula': { name: 'Nebula', color: '#c026d3', mode: 'dark' },
        'aurora': { name: 'Aurora', color: '#06b6d4', mode: 'light' },
        'phoenix': { name: 'Phoenix', color: '#ef4444', mode: 'light' },
        'sakura': { name: 'Sakura', color: '#ec4899', mode: 'light' },
        'sunset': { name: 'Sunset', color: '#f97316', mode: 'light' },
        'rose': { name: 'Rose', color: '#fb7185', mode: 'light' },
        'slate': { name: 'Slate', color: '#64748b', mode: 'light' },
        'emerald': { name: 'Emerald', color: '#10b981', mode: 'light' },
        'ocean': { name: 'Ocean', color: '#0ea5e9', mode: 'light' },
        'midnight-teal': { name: 'Midnight Teal', color: '#14b8a6', mode: 'dark' },
        'cyber': { name: 'Cyber', color: '#00ff41', mode: 'dark' },
        'cosmic-aurora': { name: 'Cosmic Aurora', color: '#a855f7', mode: 'dark' }
    });

    function safeStorageGet(key) {
        try {
            return localStorage.getItem(key);
        } catch (_) {
            return null;
        }
    }

    function safeStorageSet(key, value) {
        try {
            localStorage.setItem(key, value);
        } catch (_) {}
    }

    function isValidEmail(value) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(value || '').trim());
    }

    function getThemeSelectors() {
        return Array.from(document.querySelectorAll('[data-auth-theme-selector], #themeSelector'));
    }

    function buildThemeSelector(selector) {
        if (!selector) return;
        const fragment = document.createDocumentFragment();

        Object.entries(themes).forEach(([key, theme]) => {
            const option = document.createElement('option');
            option.value = key;
            option.textContent = theme.name;
            fragment.appendChild(option);
        });

        selector.innerHTML = '';
        selector.appendChild(fragment);
    }

    function applyTheme(themeKey) {
        const safeTheme = Object.prototype.hasOwnProperty.call(themes, themeKey) ? themeKey : 'cosmic-aurora';
        const theme = themes[safeTheme];

        document.documentElement.setAttribute('data-theme', safeTheme);
        document.documentElement.setAttribute('data-bs-theme', theme.mode);
        document.documentElement.style.setProperty('color-scheme', theme.mode);
        safeStorageSet(STORAGE_KEYS.theme, safeTheme);

        getThemeSelectors().forEach((selector) => {
            selector.value = safeTheme;
        });
    }

    function initThemeSelectors() {
        const selectors = getThemeSelectors();
        selectors.forEach((selector) => {
            buildThemeSelector(selector);
            selector.addEventListener('change', function () {
                applyTheme(this.value);
            });
        });
        applyTheme(safeStorageGet(STORAGE_KEYS.theme) || document.documentElement.getAttribute('data-theme') || 'cosmic-aurora');
    }

    function getFormAlert(form) {
        return form.querySelector('[data-auth-alert], #auth-alert');
    }

    function showAlert(form, type, message) {
        const alert = getFormAlert(form);
        if (!alert) return;

        const icon = alert.querySelector('[data-auth-alert-icon], #auth-alert-icon');
        const msg = alert.querySelector('[data-auth-alert-message], #auth-alert-msg');
        const isError = type === 'error';

        alert.className = 'alert-auth show ' + (isError ? 'alert-danger' : 'alert-success');
        if (icon) icon.className = 'bi ' + (isError ? 'bi-x-circle-fill' : 'bi-check-circle-fill');
        if (msg) msg.textContent = message;
    }

    function hideAlert(form) {
        const alert = getFormAlert(form);
        if (!alert) return;

        const icon = alert.querySelector('[data-auth-alert-icon], #auth-alert-icon');
        const msg = alert.querySelector('[data-auth-alert-message], #auth-alert-msg');

        alert.className = 'alert-auth';
        if (icon) icon.className = 'bi';
        if (msg) msg.textContent = '';
    }

    function findFeedback(input) {
        if (!input.id) return null;
        return document.querySelector(`[data-feedback-for="${CSS.escape(input.id)}"]`);
    }

    function setValidationState(input, valid, message = '') {
        const group = input.closest('.input-group');
        const feedback = findFeedback(input);
        const target = group || input;

        input.classList.toggle('is-invalid', !valid);
        input.classList.toggle('is-valid', valid);
        target.classList.toggle('is-invalid', !valid);
        target.classList.toggle('is-valid', valid);

        if (feedback) {
            const textEl = feedback.querySelector('[data-feedback-message]') || feedback.querySelector('span');
            if (textEl && message) textEl.textContent = message;
            feedback.classList.toggle('show', !valid);
        }

        if (!valid) input.setAttribute('aria-invalid', 'true');
        else input.removeAttribute('aria-invalid');
    }

    function getPasswordStrength(value) {
        let score = 0;
        if (value.length >= 8) score += 1;
        if (/[A-Z]/.test(value) && /[a-z]/.test(value)) score += 1;
        if (/\d/.test(value)) score += 1;
        if (/[^A-Za-z0-9]/.test(value)) score += 1;
        return score;
    }

    function updatePasswordStrength(input) {
        const targetSelector = input.getAttribute('data-password-strength');
        if (!targetSelector) return;

        const bar = document.querySelector(targetSelector);
        if (!bar) return;

        const score = getPasswordStrength(input.value || '');
        bar.setAttribute('data-strength', String(score));

        document.querySelectorAll(`[data-rule-for="${CSS.escape(input.id)}"]`).forEach((rule) => {
            const ruleName = rule.getAttribute('data-rule');
            const value = input.value || '';
            let ok = false;

            if (ruleName === 'length') ok = value.length >= 8;
            if (ruleName === 'case') ok = /[A-Z]/.test(value) && /[a-z]/.test(value);
            if (ruleName === 'number') ok = /\d/.test(value);
            if (ruleName === 'symbol') ok = /[^A-Za-z0-9]/.test(value);

            rule.classList.toggle('is-valid', ok);
            const icon = rule.querySelector('i');
            if (icon) {
                icon.classList.toggle('bi-circle', !ok);
                icon.classList.toggle('bi-check-circle-fill', ok);
            }
        });
    }

    function validateInput(input) {
        const rules = String(input.getAttribute('data-validate') || '').split('|').filter(Boolean);
        const label = input.getAttribute('data-label') || input.getAttribute('name') || 'This field';
        const value = input.value || '';

        if (rules.includes('checkbox')) {
            const valid = input.checked;
            setValidationState(input, valid, input.getAttribute('data-error-required') || `${label} is required.`);
            return valid;
        }

        if (rules.includes('required') && !value.trim()) {
            setValidationState(input, false, input.getAttribute('data-error-required') || `${label} is required.`);
            return false;
        }

        if (rules.includes('email') && value.trim() && !isValidEmail(value)) {
            setValidationState(input, false, input.getAttribute('data-error-email') || 'Enter a valid email address.');
            return false;
        }

        if (rules.includes('password') && value.length < Number(input.getAttribute('data-min-length') || 8)) {
            setValidationState(input, false, input.getAttribute('data-error-password') || 'Password must be at least 8 characters.');
            return false;
        }

        if (rules.includes('confirm')) {
            const matchSelector = input.getAttribute('data-match');
            const match = matchSelector ? document.querySelector(matchSelector) : null;
            if (match && value !== match.value) {
                setValidationState(input, false, input.getAttribute('data-error-confirm') || 'Passwords do not match.');
                return false;
            }
        }

        setValidationState(input, true);
        return true;
    }

    function setOtpState(form, valid, message = '') {
        const otpInputs = Array.from(form.querySelectorAll('[data-otp-input]'));
        const feedback = form.querySelector('[data-otp-feedback]');

        otpInputs.forEach((input) => {
            input.classList.toggle('is-invalid', !valid);
            input.classList.toggle('is-valid', valid);
            if (!valid) input.setAttribute('aria-invalid', 'true');
            else input.removeAttribute('aria-invalid');
        });

        if (feedback) {
            const textEl = feedback.querySelector('[data-feedback-message]') || feedback.querySelector('span');
            if (textEl && message) textEl.textContent = message;
            feedback.classList.toggle('show', !valid);
        }
    }

    function syncOtpValue(form) {
        const otpInputs = Array.from(form.querySelectorAll('[data-otp-input]'));
        const hidden = form.querySelector('[data-otp-hidden]');
        const value = otpInputs.map((input) => input.value).join('');
        if (hidden) hidden.value = value;
        return value;
    }

    function validateOtp(form) {
        const otpInputs = Array.from(form.querySelectorAll('[data-otp-input]'));
        if (!otpInputs.length) return true;

        const code = syncOtpValue(form);
        const valid = code.length === otpInputs.length && /^\d+$/.test(code);
        setOtpState(form, valid, `Enter the ${otpInputs.length}-digit verification code.`);
        return valid;
    }

    function validateForm(form) {
        const controls = Array.from(form.querySelectorAll('[data-validate]'));
        let firstInvalid = null;
        let valid = true;

        controls.forEach((control) => {
            const ok = validateInput(control);
            if (!ok && !firstInvalid) firstInvalid = control;
            valid = ok && valid;
        });

        const otpOk = validateOtp(form);
        if (!otpOk && !firstInvalid) firstInvalid = form.querySelector('[data-otp-input]');
        valid = otpOk && valid;

        if (firstInvalid) firstInvalid.focus();
        return valid;
    }

    function setLoading(form, on) {
        const submit = form.querySelector('[data-auth-submit-button], button[type="submit"]');
        if (!submit) return;

        const originalText = submit.getAttribute('data-original-text') || submit.innerHTML;
        const loadingText = submit.getAttribute('data-loading-text') || 'Please wait...';

        if (!submit.getAttribute('data-original-text')) submit.setAttribute('data-original-text', originalText);
        submit.disabled = on;
        submit.setAttribute('aria-busy', on ? 'true' : 'false');
        submit.innerHTML = on
            ? `<span class="btn-spinner" aria-hidden="true"></span><span>${loadingText}</span>`
            : originalText;

        Array.from(form.elements).forEach((element) => {
            if (element !== submit) element.disabled = on;
        });
    }

    async function submitForm(form) {
        const useAjax = form.getAttribute('data-auth-ajax') === 'true';
        if (!useAjax) {
            await new Promise((resolve) => window.setTimeout(resolve, 650));
            return {
                message: form.getAttribute('data-success-message') || 'Request completed successfully.'
            };
        }

        const response = await fetch(form.action, {
            method: form.method || 'POST',
            body: new FormData(form),
            credentials: 'same-origin',
            headers: { Accept: 'application/json' }
        });

        let payload = {};
        try {
            payload = await response.json();
        } catch (_) {}

        if (!response.ok) {
            throw new Error(payload.message || 'Something went wrong. Please try again.');
        }

        return payload;
    }

    function initPasswordToggles() {
        document.querySelectorAll('[data-password-toggle]').forEach((button) => {
            const targetId = button.getAttribute('aria-controls');
            const input = targetId ? document.getElementById(targetId) : null;
            if (!input) return;

            button.addEventListener('click', function () {
                const show = input.getAttribute('type') === 'password';
                input.setAttribute('type', show ? 'text' : 'password');

                const icon = this.querySelector('i');
                if (icon) {
                    icon.classList.toggle('bi-eye', !show);
                    icon.classList.toggle('bi-eye-slash', show);
                }

                this.setAttribute('aria-pressed', show ? 'true' : 'false');
                this.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            });
        });
    }

    function initOtpInputs() {
        document.querySelectorAll('[data-otp-input]').forEach((input) => {
            input.addEventListener('input', function () {
                this.value = this.value.replace(/\D/g, '').slice(0, 1);
                const form = this.closest('form');
                if (form) {
                    setOtpState(form, true);
                    syncOtpValue(form);
                }

                if (this.value) {
                    const next = this.nextElementSibling;
                    if (next && next.matches('[data-otp-input]')) next.focus();
                }
            });

            input.addEventListener('keydown', function (event) {
                if (event.key === 'Backspace' && !this.value) {
                    const prev = this.previousElementSibling;
                    if (prev && prev.matches('[data-otp-input]')) prev.focus();
                }
            });

            input.addEventListener('paste', function (event) {
                const form = this.closest('form');
                if (!form) return;

                const pasted = (event.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
                if (!pasted) return;

                event.preventDefault();
                const inputs = Array.from(form.querySelectorAll('[data-otp-input]'));
                pasted.split('').forEach((digit, index) => {
                    if (inputs[index]) inputs[index].value = digit;
                });
                syncOtpValue(form);
                const focusTarget = inputs[Math.min(pasted.length, inputs.length) - 1];
                if (focusTarget) focusTarget.focus();
            });
        });
    }

    function initResendButtons() {
        document.querySelectorAll('[data-auth-resend]').forEach((button) => {
            button.addEventListener('click', function () {
                const form = this.closest('form');
                const defaultText = this.getAttribute('data-default-text') || this.textContent;
                const seconds = Number(this.getAttribute('data-resend-seconds') || 30);
                let remaining = seconds;

                if (form) {
                    showAlert(form, 'success', this.getAttribute('data-resend-message') || 'A new verification code has been sent.');
                }

                this.disabled = true;
                this.textContent = `Resend in ${remaining}s`;

                const timer = window.setInterval(() => {
                    remaining -= 1;
                    this.textContent = `Resend in ${remaining}s`;

                    if (remaining <= 0) {
                        window.clearInterval(timer);
                        this.disabled = false;
                        this.textContent = defaultText;
                    }
                }, 1000);
            });
        });
    }

    function initForms() {
        document.querySelectorAll('[data-auth-form]').forEach((form) => {
            form.addEventListener('input', (event) => {
                const target = event.target;
                hideAlert(form);

                if (target.matches('[data-validate]')) {
                    if (target.getAttribute('data-password-strength')) updatePasswordStrength(target);
                    if (target.classList.contains('is-invalid') || target.classList.contains('is-valid')) {
                        validateInput(target);
                    }

                    const confirmSelector = `[data-validate*="confirm"][data-match="#${CSS.escape(target.id)}"]`;
                    form.querySelectorAll(confirmSelector).forEach((confirm) => {
                        if (confirm.value) validateInput(confirm);
                    });
                }
            });

            form.addEventListener('blur', (event) => {
                const target = event.target;
                if (target.matches('[data-validate]')) validateInput(target);
            }, true);

            form.addEventListener('submit', async (event) => {
                event.preventDefault();
                hideAlert(form);

                if (!validateForm(form)) return;

                setLoading(form, true);
                try {
                    const payload = await submitForm(form);
                    showAlert(form, 'success', payload.message || form.getAttribute('data-success-message') || 'Request completed successfully.');

                    const redirect = payload.redirectUrl || form.getAttribute('data-redirect');
                    if (redirect) {
                        window.setTimeout(() => window.location.assign(redirect), 650);
                    }
                } catch (error) {
                    showAlert(form, 'error', error.message || 'Something went wrong. Please try again.');
                } finally {
                    setLoading(form, false);
                }
            });
        });
    }

    function initLockClock() {
        const clock = document.querySelector('[data-lock-clock]');
        if (!clock) return;

        const updateClock = () => {
            clock.textContent = new Intl.DateTimeFormat(undefined, {
                hour: '2-digit',
                minute: '2-digit',
                weekday: 'short',
                month: 'short',
                day: 'numeric'
            }).format(new Date());
        };

        updateClock();
        window.setInterval(updateClock, 30000);
    }

    document.addEventListener('DOMContentLoaded', () => {
        initThemeSelectors();
        initPasswordToggles();
        initOtpInputs();
        initResendButtons();
        initForms();
        initLockClock();
    });
})();
