document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      const filter = btn.dataset.filter;
      document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.portfolio-entry').forEach(item => {
        item.style.display = (filter === 'all' || item.dataset.category === filter) ? '' : 'none';
      });
    });
  });

  document.querySelectorAll('[data-countdown]').forEach(box => {
    const target = new Date(box.dataset.countdown).getTime();
    const parts = {
      days: box.querySelector('[data-days]'),
      hours: box.querySelector('[data-hours]'),
      minutes: box.querySelector('[data-minutes]'),
      seconds: box.querySelector('[data-seconds]')
    };
    const tick = () => {
      const diff = Math.max(0, target - Date.now());
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);
      parts.days.textContent = String(days).padStart(2, '0');
      parts.hours.textContent = String(hours).padStart(2, '0');
      parts.minutes.textContent = String(minutes).padStart(2, '0');
      parts.seconds.textContent = String(seconds).padStart(2, '0');
    };
    tick(); setInterval(tick, 1000);
  });
});
