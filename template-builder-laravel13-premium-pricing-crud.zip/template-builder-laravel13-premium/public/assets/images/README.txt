Place your real images, icons, videos, and PDF downloads here. The demo uses CSS gradients and placeholders so it works immediately after seeding.
