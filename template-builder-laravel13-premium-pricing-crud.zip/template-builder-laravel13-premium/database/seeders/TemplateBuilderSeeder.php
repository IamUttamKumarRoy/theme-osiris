<?php

namespace Database\Seeders;

use App\Models\BlogCategory;
use App\Models\BlogPost;
use App\Models\CaseStudy;
use App\Models\Faq;
use App\Models\Industry;
use App\Models\Menu;
use App\Models\MenuItem;
use App\Models\Page;
use App\Models\PortfolioItem;
use App\Models\PricingPlan;
use App\Models\ResumeItem;
use App\Models\Service;
use App\Models\SiteSetting;
use App\Models\Skill;
use App\Models\TeamMember;
use App\Models\Testimonial;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class TemplateBuilderSeeder extends Seeder
{
    public function run(): void
    {
        $now = Carbon::now();

        SiteSetting::insert([
            ['setting_key' => 'site_name', 'setting_value' => 'NexaTemplate Studio', 'setting_group' => 'brand', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'tagline', 'setting_value' => 'Premium Laravel template builder for freelancers, agencies, consultants, and startups.', 'setting_group' => 'brand', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'phone', 'setting_value' => '+1 (555) 123-4567', 'setting_group' => 'contact', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'email', 'setting_value' => 'hello@nexatemplate.test', 'setting_group' => 'contact', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'address', 'setting_value' => '1200 Market Street, Suite 800, San Francisco, CA', 'setting_group' => 'contact', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'office_hours', 'setting_value' => 'Monday-Friday, 9:00 AM-6:00 PM', 'setting_group' => 'contact', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'map_embed', 'setting_value' => 'https://maps.google.com/maps?q=San%20Francisco&t=&z=12&ie=UTF8&iwloc=&output=embed', 'setting_group' => 'contact', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'resume_pdf_url', 'setting_value' => '/assets/sample-resume.pdf', 'setting_group' => 'downloads', 'created_at' => $now, 'updated_at' => $now],
            ['setting_key' => 'coming_soon_date', 'setting_value' => env('COMING_SOON_DATE', '2026-12-31T23:59:59'), 'setting_group' => 'launch', 'created_at' => $now, 'updated_at' => $now],
        ]);

        $pages = collect([
            ['Home', 'home', 'home', 'Premium Home Template', 'Dynamic home page with full scroll-selling sections.'],
            ['Home Minimal', 'home-minimal', 'home_minimal', 'Minimal Homepage Variation', 'Text-first homepage variation for freelancers.'],
            ['Home Image Heavy', 'home-image-heavy', 'home_image', 'Image-Heavy Homepage Variation', 'Visual homepage variation for agencies and studios.'],
            ['Home Video Slider', 'home-video-slider', 'home_video', 'Video Slider Homepage Variation', 'Motion-first homepage variation for startups.'],
            ['About', 'about', 'about', 'About Template', 'Story, stats, values, and credibility blocks.'],
            ['Skills', 'skills', 'skills', 'Skills Template', 'Technical skill bars and soft skill tag cloud.'],
            ['Services', 'services', 'services', 'Services Template', '3-column service cards with icons.'],
            ['Portfolio', 'portfolio', 'portfolio', 'Portfolio Template', 'Filterable portfolio gallery.'],
            ['Case Studies', 'case-studies', 'case_studies', 'Case Studies Template', 'Challenge, solution, results case-study cards.'],
            ['Resume / CV', 'resume-cv', 'resume', 'Resume/CV Template', 'Timeline layout with download PDF button.'],
            ['Testimonials', 'testimonials', 'testimonials', 'Testimonials Template', 'Carousel, static grid, and video testimonial placeholder.'],
            ['Pricing', 'pricing', 'pricing', 'Pricing Template', '3-column pricing with featured plan.'],
            ['FAQ', 'faq', 'faq', 'FAQ Template', 'Categorized accordion FAQ page.'],
            ['Industries Served', 'industries-served', 'industries', 'Industries Template', 'Industry cards and logo cloud.'],
            ['Team', 'team', 'team', 'Team Template', 'Team cards with roles and social links.'],
            ['Blog', 'blog', 'blog', 'Blog Template', 'Featured post hero, grid, and list layouts.'],
            ['Contact', 'contact', 'contact', 'Contact Template', 'Contact form, map, email, phone, and office hours.'],
            ['Landing Page', 'landing-page', 'landing', 'Landing Page Template', 'Header-free conversion landing page.'],
            ['404 Error Page', '404', 'error', '404 Error Page', 'Branded error page with navigation recovery.'],
            ['Coming Soon', 'coming-soon', 'coming_soon', 'Coming Soon Template', 'Email capture, countdown, and launch timeline.'],
        ])->mapWithKeys(function ($item) use ($now) {
            $page = Page::create([
                'title' => $item[0],
                'slug' => $item[1],
                'template_type' => $item[2],
                'meta_title' => $item[3],
                'meta_description' => $item[4],
                'status' => 'published',
                'is_system' => in_array($item[1], ['404']),
                'published_at' => $now,
            ]);
            return [$item[1] => $page];
        });

        $this->seedReusableContent($now);
        $this->seedSections($pages);
        $this->seedMenu($pages, $now);
    }

    private function seedReusableContent(Carbon $now): void
    {
        $services = [
            ['Brand Strategy', 'brand-strategy', 'Define your positioning, messaging, audience, and visual direction before design starts.', 'bi-bullseye', '$1,500', true],
            ['Website Design', 'website-design', 'Modern, responsive, conversion-focused websites built with reusable sections.', 'bi-window-sidebar', '$2,800', true],
            ['Laravel Development', 'laravel-development', 'Custom Laravel applications, dynamic dashboards, CMS workflows, and API-ready systems.', 'bi-code-slash', '$4,500', true],
            ['SEO Content Systems', 'seo-content-systems', 'Content architecture, blog systems, schema-ready layouts, and AEO-friendly pages.', 'bi-search', '$1,200', false],
            ['Startup Landing Pages', 'startup-landing-pages', 'Focused landing pages with no distractions, strong copy flow, and lead capture forms.', 'bi-rocket-takeoff', '$900', false],
            ['Template Customization', 'template-customization', 'Turn the builder into a client-ready site with colors, sections, and content configured.', 'bi-sliders', '$650', false],
        ];
        foreach ($services as $i => $s) {
            $service = Service::create([
                'title' => $s[0], 'slug' => $s[1], 'short_description' => $s[2],
                'full_description' => 'This service uses a strategic discovery process, clean Bootstrap 5 interfaces, dynamic Laravel data, and conversion-focused content blocks. Every deliverable is designed to be reusable, editable, and scalable for future pages.',
                'icon' => $s[3], 'price_from' => $s[4], 'is_featured' => $s[5], 'sort_order' => $i + 1,
            ]);
            foreach ([
                ['What is included', 'A complete service blueprint, content structure, responsive UI components, conversion CTA blocks, and implementation guidance.'],
                ['Why choose it', 'It gives you a professional framework that can be reused across multiple clients, niches, and campaigns.'],
                ['Best fit', 'Ideal for freelancers, agencies, consultants, startups, and local businesses that need fast but polished digital presence.'],
            ] as $j => $detail) {
                $service->details()->create(['section_title' => $detail[0], 'section_content' => $detail[1], 'icon' => 'bi-check2-circle', 'sort_order' => $j + 1]);
            }
            foreach ([
                ['Discovery', 'Clarify goals, audience, offer, and content requirements.'],
                ['Design System', 'Select sections, colors, cards, CTA styles, and layout variants.'],
                ['Build', 'Implement dynamic Laravel content, views, and reusable Bootstrap components.'],
                ['Launch', 'Test responsiveness, forms, SEO basics, and final conversion flow.'],
            ] as $j => $step) {
                $service->processSteps()->create(['step_title' => $step[0], 'step_description' => $step[1], 'step_number' => $j + 1, 'sort_order' => $j + 1]);
            }
        }

        foreach ([
            ['SaaS Dashboard Redesign', 'saas-dashboard-redesign', 'Web Design', 'A clean SaaS dashboard concept using cards, metrics, and action-driven layouts.', true],
            ['Personal Portfolio System', 'personal-portfolio-system', 'Branding', 'A high-end freelancer portfolio with CV timeline, project filters, and testimonials.', true],
            ['Healthcare Consultant Site', 'healthcare-consultant-site', 'Development', 'A professional service website with long-form service detail pages and FAQ accordions.', false],
            ['Agency Case Study Library', 'agency-case-study-library', 'Development', 'A dynamic case-study library with challenge, solution, and results modules.', false],
            ['Startup Launch Funnel', 'startup-launch-funnel', 'Landing Page', 'A header-free conversion funnel with pricing, benefits, and lead forms.', true],
            ['Local Business Website Kit', 'local-business-website-kit', 'Web Design', 'Service cards, contact details, map embed, and quick quote forms for local brands.', false],
        ] as $i => $p) {
            PortfolioItem::create(['title' => $p[0], 'slug' => $p[1], 'category' => $p[2], 'description' => $p[3], 'image_url' => null, 'project_url' => '#', 'is_featured' => $p[4], 'sort_order' => $i + 1]);
        }

        foreach ([
            ['Scaling a Consulting Brand', 'scaling-a-consulting-brand', 'Northstar Advisory', 'Professional Services', 'A strategic rebuild that turned scattered service pages into a polished consultant platform.', 'The client had disconnected pages, inconsistent CTAs, and weak trust signals.', 'We built a modular service system, sticky CTAs, case-study reports, and a stronger contact funnel.', 'The site became easier to maintain and helped the brand present a more credible, premium experience.', true, [['Leads', '+48%'], ['Time on Site', '+62%'], ['Pages Reused', '14']]],
            ['Launching a SaaS Waitlist', 'launching-a-saas-waitlist', 'PulseStack', 'SaaS', 'A focused landing page campaign with minimal navigation and high-impact conversion sections.', 'Visitors were distracted by too many links and unclear product messaging.', 'We removed global navigation, added problem-solution flow, pricing anchors, and email capture.', 'The waitlist grew with a cleaner, more persuasive landing page journey.', true, [['Signup Rate', '+31%'], ['CTA Clicks', '+44%'], ['Build Time', '7 Days']]],
            ['Building an Agency Portfolio Engine', 'agency-portfolio-engine', 'Gridline Studio', 'Creative Agency', 'A filterable portfolio and case-study hub built for repeatable client proof.', 'The agency portfolio was image-heavy but lacked business results.', 'We separated portfolio visuals from detailed case-study reports.', 'Prospects could now scan visuals quickly and open result-focused proof when needed.', false, [['Case Studies', '9'], ['Portfolio Filters', '5'], ['Bounce Reduction', '-22%']]],
        ] as $i => $c) {
            $case = CaseStudy::create(['title' => $c[0], 'slug' => $c[1], 'client_name' => $c[2], 'industry' => $c[3], 'headline' => $c[4], 'challenge' => $c[5], 'solution' => $c[6], 'results' => $c[7], 'is_featured' => $c[8], 'sort_order' => $i + 1]);
            foreach ($c[9] as $j => $m) {
                $case->metrics()->create(['metric_label' => $m[0], 'metric_value' => $m[1], 'sort_order' => $j + 1]);
            }
        }

        foreach ([
            ['Alex Morgan', 'Creative Director', 'Leads visual direction, template quality, and conversion-first design systems.', 'https://www.linkedin.com/', 'https://twitter.com/'],
            ['Sophia Lee', 'UX Strategist', 'Maps user journeys, section hierarchy, and page experiences for each kit.', 'https://www.linkedin.com/', 'https://twitter.com/'],
            ['Daniel Carter', 'Laravel Developer', 'Builds reusable Blade components, controllers, migrations, and admin workflows.', 'https://www.linkedin.com/', 'https://github.com/'],
            ['Priya Shah', 'Content Architect', 'Creates page structures, AEO-friendly FAQs, service content, and blog frameworks.', 'https://www.linkedin.com/', 'https://twitter.com/'],
            ['Marcus Brown', 'Growth Marketer', 'Optimizes landing pages, CTAs, lead forms, and pricing messages.', 'https://www.linkedin.com/', 'https://twitter.com/'],
            ['Emma Chen', 'Product Designer', 'Turns complex template systems into elegant and reusable page modules.', 'https://www.linkedin.com/', 'https://dribbble.com/'],
        ] as $i => $m) {
            TeamMember::create(['name' => $m[0], 'role' => $m[1], 'bio' => $m[2], 'linkedin_url' => $m[3], 'twitter_url' => $m[4], 'email' => strtolower(str_replace(' ', '.', $m[0])).'@nexatemplate.test', 'sort_order' => $i + 1]);
        }

        foreach ([
            ['Maya Reynolds', 'Founder', 'BrightPath Consulting', 'The template builder gave us a premium web presence without locking us into one rigid layout. We reused sections across services, pricing, and landing pages.', true, false],
            ['James Patel', 'Agency Owner', 'ScaleGrid Studio', 'The case-study structure is exactly what agencies need. Portfolio images show the work, but the reports explain business impact.', true, false],
            ['Olivia Stone', 'Startup Marketer', 'LaunchKit', 'The landing page version removed distractions and helped us focus users on one CTA. It feels fast, sharp, and conversion-ready.', false, true],
            ['Noah Williams', 'Freelance Designer', 'Independent', 'The resume timeline, skills section, and portfolio filters made my personal site feel like a full brand system.', false, false],
            ['Ava Thompson', 'Operations Lead', 'CareBridge', 'The admin starter pages made content updates much easier for our non-technical team.', false, true],
        ] as $i => $t) {
            Testimonial::create(['client_name' => $t[0], 'client_role' => $t[1], 'company' => $t[2], 'testimonial_text' => $t[3], 'rating' => '5.0', 'is_featured' => $t[4], 'is_video' => $t[5], 'video_url' => $t[5] ? '#' : null, 'sort_order' => $i + 1]);
        }

        foreach ([
            ['Basic', '$49', '/month', 'For freelancers and personal brands starting with essential pages.', false, ['6 core templates', 'Portfolio and contact page', 'Basic support', 'One homepage style']],
            ['Pro', '$149', '/month', 'For consultants, agencies, and service providers that need the complete system.', true, ['All 18 templates', '3 homepage variations', 'Admin starter panel', 'Premium section library', 'Priority updates']],
            ['Enterprise', 'Custom', '', 'For teams that need custom modules, dashboards, and private deployment support.', false, ['Custom Laravel modules', 'Advanced admin workflows', 'Team onboarding', 'Private implementation support']],
        ] as $i => $p) {
            $plan = PricingPlan::create(['plan_name' => $p[0], 'price' => $p[1], 'billing_cycle' => $p[2], 'description' => $p[3], 'button_text' => $p[4] ? 'Start Pro' : 'Choose Plan', 'button_link' => '/contact', 'is_recommended' => $p[4], 'sort_order' => $i + 1]);
            foreach ($p[5] as $j => $feature) {
                $plan->features()->create(['feature_text' => $feature, 'sort_order' => $j + 1]);
            }
        }

        foreach ([
            ['General', 'Can I use this for multiple types of websites?', 'Yes. The structure supports portfolio, consultant, agency, startup, utility, and lead-generation pages.'],
            ['General', 'Is the content stored dynamically?', 'Yes. Page content, sections, cards, FAQs, pricing, team members, services, blog posts, and leads are stored in MySQL.'],
            ['Billing', 'Can I change the pricing plans?', 'Yes. Pricing plans and their features are managed from the pricing tables and shown dynamically.'],
            ['Technical', 'Does this use Blade templates?', 'Yes. Public pages are rendered with Blade layouts and section partials.'],
            ['Technical', 'Can I add a new section type?', 'Yes. Add a section Blade file and seed or create records using the matching section_type.'],
            ['Support', 'Is this a complete CMS?', 'It is a premium template-builder starter package. It includes admin starter CRUD, but you can expand it into a full CMS.'],
        ] as $i => $faq) {
            Faq::create(['category' => $faq[0], 'question' => $faq[1], 'answer' => $faq[2], 'sort_order' => $i + 1]);
        }

        foreach ([
            ['Healthcare', 'healthcare', 'bi-heart-pulse', 'Service pages, trust blocks, FAQs, and contact workflows for clinics and consultants.', 'HEALTH'],
            ['Fintech', 'fintech', 'bi-bank', 'Clean authority-first layouts for financial platforms and advisory firms.', 'FIN'],
            ['Retail', 'retail', 'bi-bag-check', 'Portfolio, product, and conversion layouts for commerce-focused brands.', 'SHOP'],
            ['Education', 'education', 'bi-mortarboard', 'Information architecture for schools, courses, training, and coaching.', 'EDU'],
            ['SaaS', 'saas', 'bi-cloud-check', 'Landing pages, pricing, benefits, and waitlist capture for software launches.', 'SAAS'],
            ['Real Estate', 'real-estate', 'bi-buildings', 'Lead capture, local service pages, case studies, and FAQ content for property brands.', 'PROP'],
        ] as $i => $ind) {
            Industry::create(['name' => $ind[0], 'slug' => $ind[1], 'icon' => $ind[2], 'description' => $ind[3], 'logo_text' => $ind[4], 'sort_order' => $i + 1]);
        }

        foreach ([
            ['Laravel', 'technical', 92], ['MySQL', 'technical', 88], ['Bootstrap 5', 'technical', 95], ['Blade Components', 'technical', 90], ['SEO Architecture', 'technical', 84],
            ['Communication', 'soft', null], ['Problem Solving', 'soft', null], ['Leadership', 'soft', null], ['Research', 'soft', null], ['Client Strategy', 'soft', null], ['Time Management', 'soft', null],
        ] as $i => $skill) {
            Skill::create(['name' => $skill[0], 'skill_type' => $skill[1], 'percentage' => $skill[2], 'tag_style' => 'rounded-pill', 'sort_order' => $i + 1]);
        }

        foreach ([
            ['experience', 'Lead Template Architect', 'NexaTemplate Studio', 'Remote', '2024', 'Present', 'Designed modular Laravel website systems for agencies, consultants, and startups.'],
            ['experience', 'Senior Web Designer', 'Gridline Digital', 'New York', '2021', '2024', 'Created reusable UI kits, landing pages, and conversion-focused page frameworks.'],
            ['education', 'BSc in Digital Product Design', 'Modern Design Institute', 'Boston', '2017', '2021', 'Studied design systems, interaction design, information architecture, and web development.'],
            ['certification', 'Laravel Application Architecture', 'Professional Certificate', 'Online', '2025', '2025', 'Advanced Laravel routing, database modeling, Blade templating, and deployment patterns.'],
        ] as $i => $r) {
            ResumeItem::create(['item_type' => $r[0], 'title' => $r[1], 'organization' => $r[2], 'location' => $r[3], 'start_date' => $r[4], 'end_date' => $r[5], 'description' => $r[6], 'sort_order' => $i + 1]);
        }

        $cats = collect(['Design Systems', 'Laravel', 'Growth'])->mapWithKeys(fn ($name) => [$name => BlogCategory::create(['name' => $name, 'slug' => str($name)->slug()])]);
        foreach ([
            ['How to Build a Modular Website Template System', 'modular-website-template-system', 'Design Systems', 'A practical framework for building reusable page sections, cards, CTAs, and grids.', true],
            ['Why Laravel Works Well for Dynamic Template Builders', 'laravel-dynamic-template-builders', 'Laravel', 'How migrations, Eloquent, Blade, and controllers create a scalable content system.', false],
            ['Landing Page Structure That Converts Without Distractions', 'landing-page-structure-converts', 'Growth', 'A simple flow for problem, solution, benefits, process, pricing, FAQ, and CTA.', false],
            ['Portfolio vs Case Studies: How to Use Both', 'portfolio-vs-case-studies', 'Design Systems', 'Portfolio pages show the work, while case studies explain the business results.', false],
            ['Bootstrap 5 Components for Fast Client Builds', 'bootstrap-5-components-client-builds', 'Laravel', 'Cards, accordions, navbars, forms, and grids that speed up dynamic site production.', false],
        ] as $i => $b) {
            BlogPost::create([
                'blog_category_id' => $cats[$b[2]]->id,
                'title' => $b[0], 'slug' => $b[1], 'meta_title' => $b[0], 'meta_description' => $b[3],
                'excerpt' => $b[3], 'content' => '<p>This article explains how premium website template systems can use reusable sections, content models, and strategic layouts to reduce build time while improving quality.</p><p>Use the structure as a starting point, then customize the examples, visuals, case studies, and CTAs for your specific niche.</p>',
                'author_name' => 'NexaTemplate Editorial', 'reading_time' => 6 + $i, 'is_featured' => $b[4], 'status' => 'published', 'published_at' => $now->copy()->subDays($i + 1),
            ]);
        }
    }

    private function seedSections($pages): void
    {
        $section = function ($slug, $type, $order, $heading, $subheading = null, $content = null, $settings = [], $button = null, $link = null, $secondary = null, $secondaryLink = null) use ($pages) {
            // Safety: if a section call passes settings as the 6th argument by mistake,
            // treat that array as settings instead of trying to insert it into the TEXT content column.
            if (is_array($content) && empty($settings) && $button === null && $link === null && $secondary === null && $secondaryLink === null) {
                $settings = $content;
                $content = null;
            }

            $encodeIfArray = fn ($value) => is_array($value)
                ? json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                : $value;

            $pages[$slug]->allSections()->create([
                'section_type' => $type,
                'eyebrow' => $settings['eyebrow'] ?? null,
                'heading' => $encodeIfArray($heading),
                'subheading' => $encodeIfArray($subheading),
                'content' => $encodeIfArray($content),
                'button_text' => $encodeIfArray($button),
                'button_link' => $encodeIfArray($link),
                'secondary_button_text' => $encodeIfArray($secondary),
                'secondary_button_link' => $encodeIfArray($secondaryLink),
                'settings_json' => empty($settings) ? null : json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'sort_order' => $order,
            ]);
        };

        $section('home', 'hero', 1, 'Build Premium Websites Faster With One Dynamic Laravel System', 'A complete 18-page Bootstrap 5 template builder for freelancers, consultants, agencies, and startup landing pages.', null, ['eyebrow' => 'Laravel 13 + Bootstrap 5', 'variant' => 'split'], 'Explore Templates', '/services', 'View Portfolio', '/portfolio');
        $section('home', 'numbers', 2, 'One system. Four kits. Eighteen templates.', 'Reusable sections keep every page cohesive while each template serves a clear purpose.');
        $section('home', 'services_grid', 3, 'Popular Components', 'Launch with dynamic service cards, portfolios, case studies, pricing, testimonials, and more.');
        $section('home', 'portfolio_grid', 4, 'Featured Work Layouts', 'Use filters to present project types clearly.');
        $section('home', 'testimonial_carousel', 5, 'What Clients Say', 'A polished carousel section for high-trust social proof.');
        $section('home', 'final_cta', 6, 'Ready to customize your template builder?', 'Start from the seeded database, then edit content from admin or migrations.', null, [], 'Contact Us', '/contact');

        $section('home-minimal', 'home_minimal_hero', 1, 'Minimal Website Template for Focused Personal Brands', 'Typography-first layout for freelancers, writers, designers, and consultants.', null, ['eyebrow' => 'Home Style A'], 'See Resume', '/resume-cv', 'View Work', '/portfolio');
        $section('home-minimal', 'skills_grid', 2, 'Skills That Prove Capability', 'Technical bars and soft skill tags in one clean section.');
        $section('home-minimal', 'resume_timeline', 3, 'Experience Timeline', 'A compact CV-style flow with a download button.');
        $section('home-minimal', 'final_cta', 4, 'Let your work speak clearly.', 'Use this variation when words, structure, and credibility matter most.', null, [], 'Get In Touch', '/contact');

        $section('home-image-heavy', 'home_image_hero', 1, 'Image-Heavy Agency Homepage for Bold First Impressions', 'A visual layout for agencies, studios, teams, and corporate brands.', null, ['eyebrow' => 'Home Style B'], 'View Case Studies', '/case-studies');
        $section('home-image-heavy', 'case_study_grid', 2, 'Proof Through Reports', 'Show challenge, solution, results, and measurable outcomes.');
        $section('home-image-heavy', 'team_grid', 3, 'Meet the Team', 'Role-based cards with social links and bios.');
        $section('home-image-heavy', 'logo_cloud', 4, 'Industries and Brand Cloud', 'Build instant authority with industry labels and partner-style logos.');

        $section('home-video-slider', 'home_video_slider', 1, 'Video/Slider Homepage for Launch Campaigns', 'A motion-inspired hero with multiple slides and high-impact CTAs.', null, ['eyebrow' => 'Home Style C'], 'Start Launch Page', '/landing-page');
        $section('home-video-slider', 'benefits', 2, 'Designed for Momentum', 'Use slider-style storytelling for startups, campaigns, and product launches.');
        $section('home-video-slider', 'pricing_table', 3, 'Choose Your Build Level', 'A strong pricing section with a recommended plan highlight.');

        $section('about', 'hero', 1, 'A Template Studio Built Around Reusability', 'We design dynamic systems that look premium, remain editable, and scale across many website types.', null, ['eyebrow' => 'About']);
        $section('about', 'story', 2, 'Our Story', 'We created this collection to bridge the gap between static templates and a real dynamic website builder.');
        $section('about', 'numbers', 3, 'Numbers That Build Confidence', 'Show years of experience, completed projects, happy clients, and reusable components.');
        $section('about', 'benefits', 4, 'Why This System Works', 'Shared design language, distinct layouts, reusable content models, and conversion-focused sections.');

        $section('skills', 'hero', 1, 'Skills Template', 'Progress bars for technical strengths and soft skill tags for human capability.', null, ['eyebrow' => 'Freelancer Kit']);
        $section('skills', 'skills_grid', 2, 'Technical and Soft Skills', 'Separate technical mastery from collaborative skills.');

        $section('services', 'hero', 1, 'Services Template', 'A 3-column card layout with icons, short descriptions, and Learn More links.', null, ['eyebrow' => 'Consultant Kit']);
        $section('services', 'services_grid', 2, 'Our Services', 'Each card links to a long-form service detail page.');
        $section('services', 'final_cta', 3, 'Need a custom package?', 'Tell us what you want to build and we will map the right template path.', null, [], 'Request Quote', '/contact');

        $section('portfolio', 'hero', 1, 'Portfolio Template', 'A filterable project gallery for visual work, categories, and project links.', null, ['eyebrow' => 'Artist Kit']);
        $section('portfolio', 'portfolio_grid', 2, 'Filter Projects by Category', 'Users can sort projects without reloading the page.');

        $section('case-studies', 'hero', 1, 'Case Studies Template', 'Report-style cards that explain the challenge, solution, and measurable results.', null, ['eyebrow' => 'Agency Kit']);
        $section('case-studies', 'case_study_grid', 2, 'Business Impact Reports', 'Different from portfolio: these explain the story behind the work.');

        $section('resume-cv', 'hero', 1, 'Resume / CV Template', 'A professional timeline with a prominent download PDF button.', null, ['eyebrow' => 'Freelancer Kit'], 'Download PDF', '/assets/sample-resume.pdf');
        $section('resume-cv', 'resume_timeline', 2, 'Experience, Education, and Certifications', 'A clean timeline for career history.');

        $section('testimonials', 'hero', 1, 'Testimonials Template', 'Carousel, static grid, and video testimonial placeholder in one page.', null, ['eyebrow' => 'Trust Builder']);
        $section('testimonials', 'testimonial_carousel', 2, 'Featured Testimonials', 'Use this slider near home or service pages.');
        $section('testimonials', 'testimonial_grid', 3, 'More Client Feedback', 'Static cards improve scanning and SEO-friendly content.');
        $section('testimonials', 'video_testimonial_placeholder', 4, 'Video Testimonial Placeholder', 'Reserve space for embedded client videos.');

        $section('pricing', 'hero', 1, 'Pricing Template', 'Classic 3-column pricing with a recommended plan that visually pops.', null, ['eyebrow' => 'Conversion']);
        $section('pricing', 'pricing_table', 2, 'Simple Pricing Plans', 'Each plan has dynamic features and CTA buttons.');
        $section('pricing', 'faq_accordion', 3, 'Pricing Questions', 'Answer common objections below the pricing table.');

        $section('faq', 'hero', 1, 'FAQ Template', 'Categorized accordion sections for General, Billing, Technical, and Support questions.', null, ['eyebrow' => 'Knowledge Base']);
        $section('faq', 'faq_accordion', 2, 'Frequently Asked Questions', 'Grouped categories keep long FAQ pages easy to scan.');

        $section('industries-served', 'hero', 1, 'Industries Served Template', 'Industry cards and a logo cloud to build instant authority.', null, ['eyebrow' => 'Agency Kit']);
        $section('industries-served', 'industries_grid', 2, 'Industries We Serve', 'Cards explain relevance by vertical.');
        $section('industries-served', 'logo_cloud', 3, 'Authority Logo Cloud', 'Simple text logos for industries, partners, or client categories.');

        $section('team', 'hero', 1, 'Team Template', 'Individual cards with photos, roles, bios, social links, and email links.', null, ['eyebrow' => 'Agency Kit']);
        $section('team', 'team_grid', 2, 'Meet the Specialists', 'Use this for agencies, studios, and service businesses.');
        $section('team', 'hiring_banner', 3, 'We Are Hiring', 'Add a hiring banner because team-page visitors often include future applicants.', null, [], 'View Open Roles', '/contact');

        $section('blog', 'hero', 1, 'Blog Template', 'Includes featured post hero, grid layout, and classic list layout.', null, ['eyebrow' => 'Content Hub']);
        $section('blog', 'blog_featured', 2, 'Featured Article', 'Highlight one important article above the grid.');
        $section('blog', 'blog_grid', 3, 'Magazine Grid', 'Cards for visual browsing.');
        $section('blog', 'blog_list', 4, 'Classic List Layout', 'Compact row format for readers who prefer scanning headlines.');

        $section('contact', 'hero', 1, 'Contact Template', 'Form, map embed, phone, email, and office hours.', null, ['eyebrow' => 'Contact']);
        $section('contact', 'contact_form', 2, 'Send a Message', 'Store contact messages directly in MySQL.');
        $section('contact', 'map_and_details', 3, 'Visit or Contact Us', 'Dynamic phone, email, map, and office hours from site settings.');

        $section('landing-page', 'landing_hero', 1, 'Launch Faster With a Header-Free Conversion Page', 'No global navigation. Just a logo, focused message, pricing, proof, FAQ, and CTA.', null, ['eyebrow' => 'Startup Landing Page', 'hide_global_header' => true, 'hide_global_footer' => true], 'Start Now', '#lead-form');
        $section('landing-page', 'problem', 2, 'The Problem', 'Most templates look good but are hard to adapt across real business use cases.');
        $section('landing-page', 'solution', 3, 'The Solution', 'A Laravel-powered section system that keeps everything editable and reusable.');
        $section('landing-page', 'benefits', 4, 'Benefits', 'Move faster, stay consistent, capture leads, and reuse proven layouts.');
        $section('landing-page', 'how_it_works', 5, 'How It Works', 'Pick a kit, select sections, edit content, and publish.');
        $section('landing-page', 'pricing_table', 6, 'Choose Your Plan', 'A pricing block designed for conversion.');
        $section('landing-page', 'lead_form', 7, 'Request Early Access', 'Capture startup leads directly into quote_requests.', null, ['id' => 'lead-form']);

        $section('404', 'error_404', 1, 'Page Not Found', 'The page you are looking for may have moved, changed, or never existed.', null, ['eyebrow' => '404'], 'Back to Home', '/home');

        $section('coming-soon', 'coming_soon', 1, 'Something Premium Is Coming Soon', 'Join the launch list and watch the countdown while the new experience is being prepared.', null, ['eyebrow' => 'Coming Soon']);
        $section('coming-soon', 'timeline', 2, 'Launch Timeline', 'Plan, build, test, and release.');
    }

    private function seedMenu($pages, Carbon $now): void
    {
        $menu = Menu::create(['name' => 'Main Menu', 'location' => 'header']);
        foreach ([
            ['Home', 'home'], ['About', 'about'], ['Services', 'services'], ['Portfolio', 'portfolio'],
            ['Case Studies', 'case-studies'], ['Pricing', 'pricing'], ['Blog', 'blog'], ['Contact', 'contact'], ['Landing', 'landing-page'],
        ] as $i => $item) {
            MenuItem::create(['menu_id' => $menu->id, 'page_id' => $pages[$item[1]]->id, 'label' => $item[0], 'sort_order' => $i + 1, 'is_active' => true]);
        }
    }
}
