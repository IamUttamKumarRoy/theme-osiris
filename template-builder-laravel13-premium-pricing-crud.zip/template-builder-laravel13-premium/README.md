# Premium Laravel 13 Template Builder Package

A premium Laravel 13 + MySQL + Bootstrap 5 dynamic template builder containing the complete 18-template system:

1. Home with 3 variations: Minimal, Image-heavy, Video/Slider
2. About with story and statistics
3. Skills with technical progress bars and soft skill tags
4. Services with 3-column icon cards
5. Service Details with long-form content and sticky CTA
6. Portfolio with filterable gallery
7. Case Studies with challenge, solution, and results
8. Resume / CV with timeline and download PDF button
9. Testimonials with carousel, grid, and video placeholder
10. Pricing with 3-column featured plan
11. FAQ with categorized accordions
12. Industries Served with cards and logo cloud
13. Team with cards, roles, bios, and social links
14. Blog with featured post, grid, and list layouts
15. Contact with form, map, phone/email, and office hours
16. Landing Page with no global header/footer
17. Branded 404 Error Page with navigation recovery
18. Coming Soon / Maintenance Page with countdown and email capture

## Setup

```bash
composer install
cp .env.example .env
php artisan key:generate
```

Create the database:

```sql
CREATE DATABASE template_builder_laravel13_premium CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Update `.env`:

```env
DB_DATABASE=template_builder_laravel13_premium
DB_USERNAME=root
DB_PASSWORD=
ADMIN_PASSWORD=change-this-password
COMING_SOON_DATE=2026-12-31T23:59:59
```

Run migrations and seeders:

```bash
php artisan migrate --seed
php artisan serve
```

## Main URLs

```text
/home
/home-minimal
/home-image-heavy
/home-video-slider
/about
/skills
/services
/service/website-design
/portfolio
/case-studies
/resume-cv
/testimonials
/pricing
/faq
/industries-served
/team
/blog
/contact
/landing-page
/coming-soon
/admin/login
```

## Admin

Open:

```text
/admin/login
```

Default password is controlled by:

```env
ADMIN_PASSWORD=change-this-password
```

The admin starter includes dashboard, pages, sections, services, team, portfolio, case studies, testimonials, pricing, FAQ, industries, skills, blog, messages, quotes, and subscribers.

## Notes

This package is a complete premium starter system. It uses Laravel 13 conventions, Eloquent models, migrations, seeders, Blade views, and Bootstrap 5 CDN assets. Composer dependencies are not included in the ZIP; run `composer install` after extracting.


## V3 Pricing Admin Upgrade

This version includes full pricing plan and pricing feature management in the admin panel. Use `/admin/pricing` to add, edit, delete, sort, mark recommended plans, and manage available/unavailable feature bullets.
