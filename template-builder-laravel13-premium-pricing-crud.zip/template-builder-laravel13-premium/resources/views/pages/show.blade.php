@extends('layouts.app')

@section('title', $page->meta_title ?: $page->title)
@section('meta_description', $page->meta_description)

@section('content')
    @foreach($page->sections as $section)
        @includeFirst(['sections.' . $section->section_type, 'sections.default'], ['section' => $section, 'data' => $pageData])
    @endforeach
@endsection
