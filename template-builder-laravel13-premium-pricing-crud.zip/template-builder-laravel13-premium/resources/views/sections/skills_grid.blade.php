<section class="section-pad">
    <div class="container">
        <div class="section-title text-center mx-auto"><span class="eyebrow">Skills</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div>
        <div class="row g-5">
            <div class="col-lg-7"><h4 class="mb-4">Technical Skills</h4>@foreach($data['skills']->where('skill_type','technical') as $skill)<div class="skill-row"><div class="d-flex justify-content-between"><strong>{{ $skill->name }}</strong><span>{{ $skill->percentage }}%</span></div><div class="progress"><div class="progress-bar" style="width: {{ $skill->percentage }}%"></div></div></div>@endforeach</div>
            <div class="col-lg-5"><h4 class="mb-4">Soft Skills</h4><div class="tag-cloud">@foreach($data['skills']->where('skill_type','soft') as $skill)<span>{{ $skill->name }}</span>@endforeach</div></div>
        </div>
    </div>
</section>
