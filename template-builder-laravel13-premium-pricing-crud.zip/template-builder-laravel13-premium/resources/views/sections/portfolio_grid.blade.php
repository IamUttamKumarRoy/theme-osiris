<section class="section-pad">
    <div class="container">
        <div class="section-title text-center mx-auto"><span class="eyebrow">Portfolio</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div>
        @php $cats = $data['portfolioItems']->pluck('category')->filter()->unique()->values(); @endphp
        <div class="filter-pills text-center mb-4"><button class="active" data-filter="all">All</button>@foreach($cats as $cat)<button data-filter="{{ Str::slug($cat) }}">{{ $cat }}</button>@endforeach</div>
        <div class="row g-4 portfolio-grid">
            @foreach($data['portfolioItems'] as $item)
                <div class="col-md-6 col-lg-4 portfolio-entry" data-category="{{ Str::slug($item->category) }}"><div class="portfolio-card"><div class="portfolio-img"><span>{{ $item->category }}</span></div><div class="p-4"><h5>{{ $item->title }}</h5><p>{{ $item->description }}</p><a href="{{ $item->project_url ?? '#' }}" class="learn-link">View Project <i class="bi bi-arrow-up-right"></i></a></div></div></div>
            @endforeach
        </div>
    </div>
</section>
