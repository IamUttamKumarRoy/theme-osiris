<section class="section-pad">
    <div class="container"><div class="section-title text-center mx-auto"><span class="eyebrow">Industries</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div><div class="row g-4">@foreach($data['industries'] as $industry)<div class="col-md-6 col-lg-4"><div class="industry-card h-100"><i class="bi {{ $industry->icon }}"></i><h4>{{ $industry->name }}</h4><p>{{ $industry->description }}</p></div></div>@endforeach</div></div>
</section>
