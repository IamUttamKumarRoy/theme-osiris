<section class="section-pad bg-soft">
    <div class="container"><div class="row align-items-center g-5"><div class="col-lg-5"><span class="eyebrow">Video Proof</span><h2>{{ $section->heading }}</h2><p class="lead text-muted">{{ $section->subheading }}</p></div><div class="col-lg-7"><div class="video-placeholder"><button class="play-button"><i class="bi bi-play-fill"></i></button><div><h4>Video testimonial embed area</h4><p>Add a YouTube, Vimeo, or local video embed here.</p></div></div></div></div></div>
</section>
