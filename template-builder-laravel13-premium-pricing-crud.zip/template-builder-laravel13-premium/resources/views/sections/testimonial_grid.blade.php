<section class="section-pad">
    <div class="container"><div class="section-title text-center mx-auto"><span class="eyebrow">Reviews</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div><div class="row g-4">@foreach($data['testimonials'] as $t)<div class="col-md-6 col-lg-4"><div class="review-card h-100"><div class="stars text-warning">★★★★★</div><p>“{{ $t->testimonial_text }}”</p><strong>{{ $t->client_name }}</strong><span>{{ $t->company }}</span></div></div>@endforeach</div></div>
</section>
