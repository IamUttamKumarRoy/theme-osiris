<section class="landing-hero section-pad text-center">
    <div class="container">
        <span class="eyebrow">{{ $section->eyebrow }}</span>
        <h1 class="display-3 fw-black mx-auto col-lg-9">{{ $section->heading }}</h1>
        <p class="lead text-muted col-lg-7 mx-auto mt-3">{{ $section->subheading }}</p>
        <div class="d-flex justify-content-center gap-3 flex-wrap mt-4">
            <a href="{{ $section->button_link }}" class="btn btn-primary btn-lg rounded-pill px-5">{{ $section->button_text }}</a>
            <a href="{{ url('/pricing') }}" class="btn btn-outline-dark btn-lg rounded-pill px-5">See Pricing</a>
        </div>
        <div class="landing-device shadow-soft mt-5"></div>
    </div>
</section>
