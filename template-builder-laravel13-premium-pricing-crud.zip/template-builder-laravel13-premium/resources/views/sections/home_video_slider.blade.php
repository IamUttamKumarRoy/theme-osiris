<section class="video-slider-hero text-white">
    <div id="heroVideoSlider" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-inner">
            @foreach(['Build visually', 'Launch faster', 'Convert better'] as $i => $slide)
                <div class="carousel-item {{ $i === 0 ? 'active' : '' }}">
                    <div class="video-slide d-flex align-items-center">
                        <div class="container text-center">
                            <span class="eyebrow light">{{ $section->eyebrow }}</span>
                            <h1 class="display-3 fw-black mb-4">{{ $i === 0 ? $section->heading : $slide }}</h1>
                            <p class="lead col-lg-7 mx-auto mb-4">{{ $section->subheading }}</p>
                            <a href="{{ $section->button_link }}" class="btn btn-light btn-lg rounded-pill px-5">{{ $section->button_text }}</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroVideoSlider" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroVideoSlider" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
    </div>
</section>
