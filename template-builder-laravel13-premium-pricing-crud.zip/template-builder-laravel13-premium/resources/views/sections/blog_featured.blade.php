<section class="section-pad bg-soft">
    <div class="container"><div class="section-title text-center mx-auto"><span class="eyebrow">Featured</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div>
    @if($data['featuredPost'])<div class="featured-post-card"><div class="row align-items-center g-4"><div class="col-lg-5"><div class="post-visual"></div></div><div class="col-lg-7"><span class="badge text-bg-primary mb-3">{{ $data['featuredPost']->category?->name }}</span><h2>{{ $data['featuredPost']->title }}</h2><p class="lead text-muted">{{ $data['featuredPost']->excerpt }}</p><a href="{{ route('blog.show',$data['featuredPost']->slug) }}" class="btn btn-primary rounded-pill px-4">Read Featured Post</a></div></div></div>@endif
    </div>
</section>
