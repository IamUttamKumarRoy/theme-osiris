<section class="section-pad">
    <div class="container">
        <div class="section-title text-center mx-auto"><span class="eyebrow">Services</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div>
        <div class="row g-4">
            @foreach($data['services'] as $service)
                <div class="col-md-6 col-lg-4"><div class="service-card h-100"><div class="icon-box"><i class="bi {{ $service->icon ?? 'bi-stars' }}"></i></div><h4>{{ $service->title }}</h4><p>{{ $service->short_description }}</p><div class="mt-auto d-flex justify-content-between align-items-center"><span class="small text-muted">From {{ $service->price_from }}</span><a href="{{ route('services.show',$service->slug) }}" class="learn-link">Learn More <i class="bi bi-arrow-right"></i></a></div></div></div>
            @endforeach
        </div>
    </div>
</section>
