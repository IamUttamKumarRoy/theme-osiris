<section class="section-pad bg-soft">
    <div class="container"><div class="section-title text-center mx-auto"><span class="eyebrow">Process</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div>
    <div class="row g-4">@foreach(['Pick a kit','Choose sections','Edit content','Publish'] as $i => $step)<div class="col-md-6 col-lg-3"><div class="step-card"><span>{{ $i+1 }}</span><h5>{{ $step }}</h5><p>Use the dynamic database records and Blade sections to assemble the exact page flow you need.</p></div></div>@endforeach</div></div>
</section>
