<section class="section-pad">
    <div class="container">
        <div class="section-title mx-auto text-center">
            @if($section->eyebrow)<span class="eyebrow">{{ $section->eyebrow }}</span>@endif
            <h2>{{ $section->heading }}</h2>
            @if($section->subheading)<p>{{ $section->subheading }}</p>@endif
        </div>
        @if($section->content)<div class="content-box">{!! nl2br(e($section->content)) !!}</div>@endif
    </div>
</section>
