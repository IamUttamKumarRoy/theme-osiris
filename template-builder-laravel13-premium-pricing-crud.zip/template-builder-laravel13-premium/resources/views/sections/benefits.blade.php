<section class="section-pad">
    <div class="container">
        <div class="section-title mx-auto text-center"><span class="eyebrow">Benefits</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div>
        <div class="row g-4">
            @foreach([['bi-grid-1x2','Reusable Sections','Build pages quickly from modular Blade partials.'],['bi-database-check','Dynamic MySQL Content','Edit services, posts, team, pricing, and FAQs from database records.'],['bi-phone','Responsive Bootstrap 5','Every public page uses mobile-friendly Bootstrap grids.'],['bi-lightning-charge','Conversion Ready','CTA, pricing, lead, and contact sections are built in.']] as $b)
                <div class="col-md-6 col-lg-3"><div class="feature-card h-100"><i class="bi {{ $b[0] }}"></i><h5>{{ $b[1] }}</h5><p>{{ $b[2] }}</p></div></div>
            @endforeach
        </div>
    </div>
</section>
