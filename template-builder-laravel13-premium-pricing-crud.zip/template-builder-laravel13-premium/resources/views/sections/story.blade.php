<section class="section-pad">
    <div class="container">
        <div class="row g-5 align-items-center">
            <div class="col-lg-5"><div class="story-card shadow-soft"><i class="bi bi-gem"></i><h3>Built to scale from one page to a full business site.</h3></div></div>
            <div class="col-lg-7"><span class="eyebrow">Story</span><h2>{{ $section->heading }}</h2><p class="lead text-muted">{{ $section->subheading }}</p><p>{{ $section->content ?? 'This system was designed so creators can reuse one design language while serving multiple website personas: freelancers, consultants, agencies, startups, and utility pages.' }}</p></div>
        </div>
    </div>
</section>
