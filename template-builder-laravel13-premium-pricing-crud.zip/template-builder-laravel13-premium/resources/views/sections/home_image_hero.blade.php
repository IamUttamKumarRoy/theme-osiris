<section class="image-hero section-pad">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-5">
                <span class="eyebrow">{{ $section->eyebrow }}</span>
                <h1 class="display-4 fw-black">{{ $section->heading }}</h1>
                <p class="lead text-muted">{{ $section->subheading }}</p>
                <a href="{{ $section->button_link }}" class="btn btn-primary btn-lg rounded-pill px-4">{{ $section->button_text }}</a>
            </div>
            <div class="col-lg-7">
                <div class="image-collage">
                    <div class="collage-card c1"></div><div class="collage-card c2"></div><div class="collage-card c3"></div><div class="collage-card c4"></div>
                </div>
            </div>
        </div>
    </div>
</section>
