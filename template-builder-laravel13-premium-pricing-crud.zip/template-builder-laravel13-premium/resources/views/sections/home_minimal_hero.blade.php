<section class="minimal-hero section-pad">
    <div class="container text-center">
        <span class="eyebrow">{{ $section->eyebrow }}</span>
        <h1 class="minimal-title mx-auto">{{ $section->heading }}</h1>
        <p class="lead text-muted mx-auto col-lg-7">{{ $section->subheading }}</p>
        <div class="d-flex justify-content-center gap-3 flex-wrap mt-4">
            <a href="{{ $section->button_link }}" class="btn btn-dark btn-lg rounded-pill px-4">{{ $section->button_text }}</a>
            <a href="{{ $section->secondary_button_link }}" class="btn btn-outline-dark btn-lg rounded-pill px-4">{{ $section->secondary_button_text }}</a>
        </div>
    </div>
</section>
