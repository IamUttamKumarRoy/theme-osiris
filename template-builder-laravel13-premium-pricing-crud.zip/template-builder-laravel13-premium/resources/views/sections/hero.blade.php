<section class="hero-section section-pad overflow-hidden">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                @if($section->eyebrow)<span class="eyebrow">{{ $section->eyebrow }}</span>@endif
                <h1 class="display-4 fw-black mb-4">{{ $section->heading }}</h1>
                <p class="lead text-muted mb-4">{{ $section->subheading }}</p>
                <div class="d-flex flex-wrap gap-3">
                    @if($section->button_text)<a href="{{ $section->button_link }}" class="btn btn-primary btn-lg rounded-pill px-4">{{ $section->button_text }}</a>@endif
                    @if($section->secondary_button_text)<a href="{{ $section->secondary_button_link }}" class="btn btn-outline-dark btn-lg rounded-pill px-4">{{ $section->secondary_button_text }}</a>@endif
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-art shadow-soft">
                    <div class="hero-window-top"><span></span><span></span><span></span></div>
                    <div class="hero-grid-art">
                        <div class="art-card tall"></div><div class="art-card"></div><div class="art-card"></div><div class="art-card wide"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
