<section class="section-pad bg-soft">
    <div class="container">
        <div class="section-title text-center mx-auto"><span class="eyebrow">Stats</span><h2>{{ $section->heading }}</h2><p>{{ $section->subheading }}</p></div>
        <div class="row g-4">
            @foreach([['18','Premium Templates'], ['4','Website Kits'], ['3','Homepage Variations'], ['100%','Dynamic Data']] as $stat)
                <div class="col-6 col-lg-3"><div class="stat-card"><h3>{{ $stat[0] }}</h3><p>{{ $stat[1] }}</p></div></div>
            @endforeach
        </div>
    </div>
</section>
