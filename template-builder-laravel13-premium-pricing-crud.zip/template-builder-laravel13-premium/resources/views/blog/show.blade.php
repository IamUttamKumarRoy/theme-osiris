@extends('layouts.app')
@section('title', $post->meta_title ?: $post->title)
@section('meta_description', $post->meta_description ?: $post->excerpt)
@section('content')
<section class="blog-detail-hero section-pad bg-soft"><div class="container text-center"><span class="eyebrow">{{ $post->category?->name }}</span><h1 class="display-4 fw-black col-lg-9 mx-auto">{{ $post->title }}</h1><p class="text-muted">{{ $post->author_name }} · {{ $post->reading_time }} min read · {{ optional($post->published_at)->format('M d, Y') }}</p></div></section>
<section class="section-pad"><div class="container"><div class="row justify-content-center"><article class="col-lg-8 blog-content">{!! $post->content !!}</article></div></div></section>
@if($relatedPosts->count())<section class="section-pad bg-soft"><div class="container"><h2 class="mb-4">Related Posts</h2><div class="row g-4">@foreach($relatedPosts as $rp)<div class="col-md-4"><a class="blog-card h-100 text-decoration-none" href="{{ route('blog.show',$rp->slug) }}"><div class="post-visual small"></div><div class="p-4"><h5>{{ $rp->title }}</h5><p>{{ $rp->excerpt }}</p></div></a></div>@endforeach</div></div></section>@endif
@endsection
