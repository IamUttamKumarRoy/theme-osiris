@extends('layouts.admin')
@section('title',$title)
@section('content')
<div class="d-flex justify-content-between align-items-center mb-4"><div><h1 class="fw-black">{{ $title }}</h1><p class="text-muted">Review database records. Main edit forms are included for pages, sections, services, and team.</p></div></div>
<div class="admin-card"><div class="table-responsive"><table class="table align-middle"><thead><tr>@foreach($columns as $col)<th>{{ Str::headline($col) }}</th>@endforeach @if($editRoute)<th></th>@endif</tr></thead><tbody>@foreach($items as $item)<tr>@foreach($columns as $col)<td>{{ is_bool($item->$col) ? ($item->$col ? 'Yes' : 'No') : Str::limit(strip_tags((string)$item->$col), 80) }}</td>@endforeach @if($editRoute)<td class="text-end"><a href="{{ route($editRoute, $item) }}" class="btn btn-sm btn-outline-primary rounded-pill">Edit</a></td>@endif</tr>@endforeach</tbody></table></div>{{ $items->links() }}</div>
@endsection
