@extends('layouts.admin')
@section('title', $feature->exists ? 'Edit Pricing Feature' : 'Add Pricing Feature')
@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div>
        <h1 class="fw-black mb-1">{{ $feature->exists ? 'Edit Pricing Feature' : 'Add Pricing Feature' }}</h1>
        <p class="text-muted mb-0">Plan: <strong>{{ $plan->plan_name }}</strong></p>
    </div>
    <a href="{{ route('admin.pricing.edit', $plan) }}" class="btn btn-outline-secondary rounded-pill">Back to Plan</a>
</div>

@if($errors->any())
    <div class="alert alert-danger"><strong>Please fix the following:</strong><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
@endif

<form class="admin-card" method="POST" action="{{ $feature->exists ? route('admin.pricing.features.update', $feature) : route('admin.pricing.features.store', $plan) }}">
    @csrf
    @if($feature->exists) @method('PUT') @endif
    <div class="row g-3">
        <div class="col-lg-8">
            <label class="form-label">Feature Text</label>
            <input name="feature_text" class="form-control" value="{{ old('feature_text', $feature->feature_text) }}" placeholder="All 18 templates included" required>
        </div>
        <div class="col-lg-2">
            <label class="form-label">Sort Order</label>
            <input name="sort_order" type="number" class="form-control" value="{{ old('sort_order', $feature->sort_order ?? 0) }}" required>
        </div>
        <div class="col-lg-2 d-flex align-items-end">
            <div class="form-check form-switch mb-2">
                <input class="form-check-input" type="checkbox" name="is_available" value="1" id="available" {{ old('is_available', $feature->exists ? $feature->is_available : true) ? 'checked' : '' }}>
                <label class="form-check-label" for="available">Available</label>
            </div>
        </div>
    </div>
    <button class="btn btn-primary rounded-pill mt-4">{{ $feature->exists ? 'Save Feature' : 'Add Feature' }}</button>
</form>
@endsection
