@extends('layouts.admin')
@section('title','Pricing Plans')
@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div>
        <h1 class="fw-black mb-1">Pricing Plans</h1>
        <p class="text-muted mb-0">Manage pricing cards and their related feature bullets. Changes appear on the public pricing section automatically.</p>
    </div>
    <a href="{{ route('admin.pricing.create') }}" class="btn btn-primary rounded-pill"><i class="bi bi-plus-lg"></i> Add Plan</a>
</div>

<div class="row g-4">
@forelse($plans as $plan)
    <div class="col-lg-4">
        <div class="admin-card h-100">
            <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
                <div>
                    @if($plan->is_recommended)<span class="badge text-bg-primary rounded-pill mb-2">Recommended</span>@endif
                    <h3 class="h5 fw-bold mb-1">{{ $plan->plan_name }}</h3>
                    <div class="text-muted small">Sort: {{ $plan->sort_order }} · {{ $plan->features_count }} features</div>
                </div>
                <div class="text-end">
                    <div class="fw-black fs-4">{{ $plan->price }}</div>
                    <small class="text-muted">{{ $plan->billing_cycle }}</small>
                </div>
            </div>
            <p class="text-muted">{{ $plan->description }}</p>
            <ul class="list-unstyled vstack gap-2 mb-4">
                @forelse($plan->features as $feature)
                    <li class="d-flex justify-content-between align-items-start gap-3 {{ $feature->is_available ? '' : 'text-muted text-decoration-line-through' }}">
                        <span><i class="bi {{ $feature->is_available ? 'bi-check-circle-fill text-success' : 'bi-x-circle text-muted' }} me-1"></i>{{ $feature->feature_text }}</span>
                        <span class="btn-group btn-group-sm">
                            <a href="{{ route('admin.pricing.features.edit', $feature) }}" class="btn btn-outline-secondary">Edit</a>
                            <form method="POST" action="{{ route('admin.pricing.features.destroy', $feature) }}" onsubmit="return confirm('Delete this feature?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-outline-danger">Delete</button>
                            </form>
                        </span>
                    </li>
                @empty
                    <li class="text-muted">No features added yet.</li>
                @endforelse
            </ul>
            <div class="d-flex flex-wrap gap-2">
                <a href="{{ route('admin.pricing.edit', $plan) }}" class="btn btn-outline-primary rounded-pill">Edit Plan</a>
                <a href="{{ route('admin.pricing.features.create', $plan) }}" class="btn btn-outline-success rounded-pill">Add Feature</a>
                <form method="POST" action="{{ route('admin.pricing.destroy', $plan) }}" onsubmit="return confirm('Delete this plan and all its features?')">
                    @csrf @method('DELETE')
                    <button class="btn btn-outline-danger rounded-pill">Delete</button>
                </form>
            </div>
        </div>
    </div>
@empty
    <div class="col-12"><div class="admin-card text-center text-muted">No pricing plans found.</div></div>
@endforelse
</div>
<div class="mt-4">{{ $plans->links() }}</div>
@endsection
