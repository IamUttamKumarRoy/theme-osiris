@extends('layouts.admin')
@section('title', $plan->exists ? 'Edit Pricing Plan' : 'Create Pricing Plan')
@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div>
        <h1 class="fw-black mb-1">{{ $plan->exists ? 'Edit Pricing Plan' : 'Create Pricing Plan' }}</h1>
        <p class="text-muted mb-0">Update the pricing card title, price, CTA, highlight state, and sorting order.</p>
    </div>
    <a href="{{ route('admin.pricing') }}" class="btn btn-outline-secondary rounded-pill">Back to Pricing</a>
</div>

@if($errors->any())
    <div class="alert alert-danger"><strong>Please fix the following:</strong><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
@endif

<div class="row g-4">
    <div class="col-lg-8">
        <form class="admin-card" method="POST" action="{{ $plan->exists ? route('admin.pricing.update', $plan) : route('admin.pricing.store') }}">
            @csrf
            @if($plan->exists) @method('PUT') @endif
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Plan Name</label>
                    <input name="plan_name" class="form-control" value="{{ old('plan_name', $plan->plan_name) }}" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Price</label>
                    <input name="price" class="form-control" value="{{ old('price', $plan->price) }}" placeholder="$149" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Billing Cycle</label>
                    <input name="billing_cycle" class="form-control" value="{{ old('billing_cycle', $plan->billing_cycle) }}" placeholder="/month">
                </div>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4">{{ old('description', $plan->description) }}</textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Button Text</label>
                    <input name="button_text" class="form-control" value="{{ old('button_text', $plan->button_text) }}" placeholder="Choose Plan">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Button Link</label>
                    <input name="button_link" class="form-control" value="{{ old('button_link', $plan->button_link) }}" placeholder="/contact">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Sort Order</label>
                    <input name="sort_order" type="number" class="form-control" value="{{ old('sort_order', $plan->sort_order ?? 0) }}" required>
                </div>
                <div class="col-md-8 d-flex align-items-end">
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="is_recommended" value="1" id="recommended" {{ old('is_recommended', $plan->is_recommended) ? 'checked' : '' }}>
                        <label class="form-check-label" for="recommended">Mark this plan as recommended / featured</label>
                    </div>
                </div>
            </div>
            <button class="btn btn-primary rounded-pill mt-4">{{ $plan->exists ? 'Save Pricing Plan' : 'Create Pricing Plan' }}</button>
        </form>
    </div>

    <div class="col-lg-4">
        <div class="admin-card">
            <h4 class="h5 fw-bold">Features</h4>
            @if($plan->exists)
                <p class="text-muted small">Add, edit, delete, sort, or disable feature bullets for this plan.</p>
                <a href="{{ route('admin.pricing.features.create', $plan) }}" class="btn btn-outline-success rounded-pill w-100 mb-3">Add Feature</a>
                <ul class="list-group list-group-flush">
                    @forelse($plan->features as $feature)
                        <li class="list-group-item px-0 d-flex justify-content-between gap-2">
                            <span class="{{ $feature->is_available ? '' : 'text-muted text-decoration-line-through' }}">{{ $feature->feature_text }}</span>
                            <a href="{{ route('admin.pricing.features.edit', $feature) }}" class="small">Edit</a>
                        </li>
                    @empty
                        <li class="list-group-item px-0 text-muted">No features yet.</li>
                    @endforelse
                </ul>
            @else
                <p class="text-muted small mb-0">Create the plan first, then add feature bullets.</p>
            @endif
        </div>
    </div>
</div>
@endsection
