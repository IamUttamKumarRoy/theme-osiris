@extends('layouts.admin')
@section('title','Dashboard')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-4"><div><h1 class="fw-black">Dashboard</h1><p class="text-muted">Manage the premium template builder starter data.</p></div><a href="{{ url('/home') }}" class="btn btn-primary rounded-pill" target="_blank">View Site</a></div>
<div class="row g-4 mb-5">@foreach($counts as $label=>$count)<div class="col-md-3"><div class="admin-stat"><span>{{ $label }}</span><strong>{{ $count }}</strong></div></div>@endforeach</div>
<div class="row g-4"><div class="col-lg-6"><div class="admin-card"><h4>Recent Messages</h4><div class="list-group list-group-flush">@forelse($recentMessages as $m)<div class="list-group-item px-0"><strong>{{ $m->name }}</strong><br><span class="text-muted">{{ $m->subject ?: $m->email }}</span></div>@empty<p class="text-muted">No messages yet.</p>@endforelse</div></div></div><div class="col-lg-6"><div class="admin-card"><h4>Recent Quotes</h4><div class="list-group list-group-flush">@forelse($recentQuotes as $q)<div class="list-group-item px-0"><strong>{{ $q->name }}</strong><br><span class="text-muted">{{ $q->service_interest ?: $q->email }}</span></div>@empty<p class="text-muted">No quotes yet.</p>@endforelse</div></div></div></div>
@endsection
