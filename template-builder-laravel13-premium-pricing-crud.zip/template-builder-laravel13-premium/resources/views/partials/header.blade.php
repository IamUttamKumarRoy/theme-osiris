<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top border-bottom nav-blur">
    <div class="container py-2">
        <a class="navbar-brand fw-black d-flex align-items-center gap-2" href="{{ url('/home') }}">
            <span class="brand-mark"><i class="bi bi-layers-half"></i></span>
            <span>{{ $settings['site_name'] ?? 'NexaTemplate Studio' }}</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center gap-lg-1">
                @foreach($mainMenu ?? [] as $item)
                    @php $url = $item->url ?: ($item->page ? url('/'.$item->page->slug) : '#'); @endphp
                    <li class="nav-item"><a class="nav-link" href="{{ $url }}" target="{{ $item->target }}">{{ $item->label }}</a></li>
                @endforeach
                <li class="nav-item ms-lg-2"><a href="{{ url('/contact') }}" class="btn btn-primary rounded-pill px-4">Get Started</a></li>
            </ul>
        </div>
    </div>
</nav>
