<footer class="footer-dark py-5 mt-5">
    <div class="container">
        <div class="row g-4 align-items-start">
            <div class="col-lg-5">
                <div class="d-flex align-items-center gap-2 mb-3"><span class="brand-mark"><i class="bi bi-layers-half"></i></span><h4 class="mb-0 fw-black">{{ $settings['site_name'] ?? 'NexaTemplate Studio' }}</h4></div>
                <p class="text-white-50 mb-4">{{ $settings['tagline'] ?? 'Premium dynamic Laravel template builder.' }}</p>
                <div class="d-flex gap-2">
                    <a class="social" href="#"><i class="bi bi-linkedin"></i></a>
                    <a class="social" href="#"><i class="bi bi-twitter-x"></i></a>
                    <a class="social" href="#"><i class="bi bi-github"></i></a>
                </div>
            </div>
            <div class="col-lg-3">
                <h6 class="text-uppercase small text-white-50">Pages</h6>
                <div class="d-grid gap-2">
                    @foreach(($mainMenu ?? [])->take(6) as $item)
                        @php $url = $item->url ?: ($item->page ? url('/'.$item->page->slug) : '#'); @endphp
                        <a href="{{ $url }}" class="footer-link">{{ $item->label }}</a>
                    @endforeach
                </div>
            </div>
            <div class="col-lg-4">
                <h6 class="text-uppercase small text-white-50">Newsletter</h6>
                <p class="text-white-50">Get template updates and launch notes.</p>
                <form method="post" action="{{ route('newsletter.store') }}" class="d-flex gap-2">
                    @csrf
                    <input type="hidden" name="source" value="footer">
                    <input type="email" name="email" class="form-control rounded-pill" placeholder="Email address" required>
                    <button class="btn btn-light rounded-pill px-4">Join</button>
                </form>
            </div>
        </div>
        <div class="border-top border-secondary mt-5 pt-4 text-white-50 small">© {{ date('Y') }} {{ $settings['site_name'] ?? 'NexaTemplate Studio' }}. Built with Laravel 13, MySQL, Blade, and Bootstrap 5.</div>
    </div>
</footer>
