<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', $settings['site_name'] ?? 'Premium Template Builder')</title>
    <meta name="description" content="@yield('meta_description', $settings['tagline'] ?? 'Premium dynamic Laravel template builder')">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="{{ asset('assets/css/template-builder.css') }}" rel="stylesheet">
</head>
<body>
    @if(empty($hideHeader))
        @include('partials.header')
    @else
        <div class="landing-topbar py-3">
            <div class="container d-flex align-items-center justify-content-between">
                <a href="{{ url('/home') }}" class="brand-mini text-decoration-none fw-black">{{ $settings['site_name'] ?? 'NexaTemplate Studio' }}</a>
                <a href="#lead-form" class="btn btn-primary rounded-pill px-4">Start Now</a>
            </div>
        </div>
    @endif

    @if(session('success'))
        <div class="container pt-4"><div class="alert alert-success rounded-4 shadow-sm">{{ session('success') }}</div></div>
    @endif
    @if(session('error'))
        <div class="container pt-4"><div class="alert alert-danger rounded-4 shadow-sm">{{ session('error') }}</div></div>
    @endif

    <main>@yield('content')</main>

    @if(empty($hideFooter))
        @include('partials.footer')
    @endif

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('assets/js/template-builder.js') }}"></script>
</body>
</html>
