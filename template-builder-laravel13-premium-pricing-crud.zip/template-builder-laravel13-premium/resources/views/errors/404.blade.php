@extends('layouts.app')
@section('title', 'Page Not Found')
@section('content')
    @if($page)
        @foreach($page->sections as $section)
            @includeFirst(['sections.' . $section->section_type, 'sections.default'], ['section' => $section, 'data' => $pageData])
        @endforeach
    @else
        <section class="section-pad"><div class="container text-center"><h1>404</h1><p>Page not found.</p><a href="{{ url('/home') }}" class="btn btn-primary">Back Home</a></div></section>
    @endif
@endsection
