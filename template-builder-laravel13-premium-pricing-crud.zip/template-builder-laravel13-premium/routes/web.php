<?php

use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\WebsiteController;
use Illuminate\Support\Facades\Route;

Route::get('/', [WebsiteController::class, 'home'])->name('home');

Route::get('/service/{slug}', [WebsiteController::class, 'service'])->name('services.show');
Route::get('/blog/{slug}', [WebsiteController::class, 'blogPost'])->name('blog.show');

Route::post('/contact-submit', [WebsiteController::class, 'storeContact'])->name('contact.store');
Route::post('/newsletter-submit', [WebsiteController::class, 'storeNewsletter'])->name('newsletter.store');
Route::post('/quote-submit', [WebsiteController::class, 'storeQuote'])->name('quote.store');

Route::prefix('admin')->group(function () {
    Route::get('/login', [AdminAuthController::class, 'login'])->name('admin.login');
    Route::post('/login', [AdminAuthController::class, 'authenticate'])->name('admin.authenticate');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');

    Route::middleware('admin.password')->group(function () {
        Route::get('/', [AdminController::class, 'dashboard'])->name('admin.dashboard');
        Route::get('/pages', [AdminController::class, 'pages'])->name('admin.pages');
        Route::get('/pages/{page}/edit', [AdminController::class, 'editPage'])->name('admin.pages.edit');
        Route::put('/pages/{page}', [AdminController::class, 'updatePage'])->name('admin.pages.update');
        Route::get('/pages/{page}/sections', [AdminController::class, 'sections'])->name('admin.sections');
        Route::get('/sections/{section}/edit', [AdminController::class, 'editSection'])->name('admin.sections.edit');
        Route::put('/sections/{section}', [AdminController::class, 'updateSection'])->name('admin.sections.update');
        Route::get('/services', [AdminController::class, 'services'])->name('admin.services');
        Route::get('/services/{service}/edit', [AdminController::class, 'editService'])->name('admin.services.edit');
        Route::put('/services/{service}', [AdminController::class, 'updateService'])->name('admin.services.update');
        Route::get('/team', [AdminController::class, 'team'])->name('admin.team');
        Route::get('/team/{member}/edit', [AdminController::class, 'editTeamMember'])->name('admin.team.edit');
        Route::put('/team/{member}', [AdminController::class, 'updateTeamMember'])->name('admin.team.update');
        Route::get('/portfolio', [AdminController::class, 'portfolio'])->name('admin.portfolio');
        Route::get('/case-studies', [AdminController::class, 'caseStudies'])->name('admin.case-studies');
        Route::get('/testimonials', [AdminController::class, 'testimonials'])->name('admin.testimonials');
        Route::get('/pricing', [AdminController::class, 'pricing'])->name('admin.pricing');
        Route::get('/pricing/create', [AdminController::class, 'createPricingPlan'])->name('admin.pricing.create');
        Route::post('/pricing', [AdminController::class, 'storePricingPlan'])->name('admin.pricing.store');
        Route::get('/pricing/{plan}/edit', [AdminController::class, 'editPricingPlan'])->name('admin.pricing.edit');
        Route::put('/pricing/{plan}', [AdminController::class, 'updatePricingPlan'])->name('admin.pricing.update');
        Route::delete('/pricing/{plan}', [AdminController::class, 'destroyPricingPlan'])->name('admin.pricing.destroy');
        Route::get('/pricing/{plan}/features/create', [AdminController::class, 'createPricingFeature'])->name('admin.pricing.features.create');
        Route::post('/pricing/{plan}/features', [AdminController::class, 'storePricingFeature'])->name('admin.pricing.features.store');
        Route::get('/pricing-features/{feature}/edit', [AdminController::class, 'editPricingFeature'])->name('admin.pricing.features.edit');
        Route::put('/pricing-features/{feature}', [AdminController::class, 'updatePricingFeature'])->name('admin.pricing.features.update');
        Route::delete('/pricing-features/{feature}', [AdminController::class, 'destroyPricingFeature'])->name('admin.pricing.features.destroy');
        Route::get('/faqs', [AdminController::class, 'faqs'])->name('admin.faqs');
        Route::get('/industries', [AdminController::class, 'industries'])->name('admin.industries');
        Route::get('/skills', [AdminController::class, 'skills'])->name('admin.skills');
        Route::get('/blog', [AdminController::class, 'blog'])->name('admin.blog');
        Route::get('/messages', [AdminController::class, 'messages'])->name('admin.messages');
        Route::get('/quotes', [AdminController::class, 'quotes'])->name('admin.quotes');
        Route::get('/subscribers', [AdminController::class, 'subscribers'])->name('admin.subscribers');
    });
});

Route::get('/{slug}', [WebsiteController::class, 'page'])
    ->where('slug', '[A-Za-z0-9\-]+')
    ->name('page.show');

Route::fallback([WebsiteController::class, 'notFound'])->name('fallback.404');
