<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('builder:about', function () {
    $this->info('Premium Laravel 13 Template Builder is installed.');
});
