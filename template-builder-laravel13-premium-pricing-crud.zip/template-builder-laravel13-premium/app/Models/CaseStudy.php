<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CaseStudy extends Model
{
    protected $guarded = [];


    protected $casts = ['is_featured' => 'boolean'];

    public function metrics()
    {
        return $this->hasMany(CaseStudyMetric::class)->orderBy('sort_order');
    }

}
