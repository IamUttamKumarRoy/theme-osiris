<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $guarded = [];


    protected $casts = [
        'is_system' => 'boolean',
        'published_at' => 'datetime',
    ];

    public function sections()
    {
        return $this->hasMany(PageSection::class)->where('is_active', true)->orderBy('sort_order');
    }

    public function allSections()
    {
        return $this->hasMany(PageSection::class)->orderBy('sort_order');
    }

}
