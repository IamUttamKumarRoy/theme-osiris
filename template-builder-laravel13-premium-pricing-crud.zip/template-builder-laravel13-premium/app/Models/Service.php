<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    protected $guarded = [];


    protected $casts = ['is_featured' => 'boolean', 'is_active' => 'boolean'];

    public function details()
    {
        return $this->hasMany(ServiceDetail::class)->orderBy('sort_order');
    }

    public function processSteps()
    {
        return $this->hasMany(ServiceProcessStep::class)->orderBy('sort_order');
    }

}
