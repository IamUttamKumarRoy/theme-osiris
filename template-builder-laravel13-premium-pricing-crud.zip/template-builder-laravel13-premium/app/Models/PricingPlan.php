<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PricingPlan extends Model
{
    protected $guarded = [];


    protected $casts = ['is_recommended' => 'boolean'];

    public function features()
    {
        return $this->hasMany(PricingFeature::class)->orderBy('sort_order');
    }

}
