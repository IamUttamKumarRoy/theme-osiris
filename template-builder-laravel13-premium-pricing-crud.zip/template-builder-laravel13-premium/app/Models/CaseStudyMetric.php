<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CaseStudyMetric extends Model
{
    protected $guarded = [];


    public function caseStudy()
    {
        return $this->belongsTo(CaseStudy::class);
    }

}
