<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PageSection extends Model
{
    protected $guarded = [];


    protected $casts = [
        'settings_json' => 'array',
        'is_active' => 'boolean',
    ];

    public function setSettingsJsonAttribute($value): void
    {
        if (is_array($value)) {
            $this->attributes['settings_json'] = empty($value)
                ? null
                : json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            return;
        }

        $this->attributes['settings_json'] = $value ?: null;
    }

    public function page()
    {
        return $this->belongsTo(Page::class);
    }

}
