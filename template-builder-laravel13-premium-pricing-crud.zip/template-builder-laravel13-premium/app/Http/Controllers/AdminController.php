<?php

namespace App\Http\Controllers;

use App\Models\BlogPost;
use App\Models\CaseStudy;
use App\Models\ContactMessage;
use App\Models\Faq;
use App\Models\Industry;
use App\Models\NewsletterSubscriber;
use App\Models\Page;
use App\Models\PageSection;
use App\Models\PortfolioItem;
use App\Models\PricingPlan;
use App\Models\PricingFeature;
use App\Models\QuoteRequest;
use App\Models\Service;
use App\Models\Skill;
use App\Models\TeamMember;
use App\Models\Testimonial;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminController extends Controller
{
    public function dashboard(): View
    {
        return view('admin.dashboard', [
            'counts' => [
                'Pages' => Page::count(),
                'Sections' => PageSection::count(),
                'Services' => Service::count(),
                'Portfolio' => PortfolioItem::count(),
                'Team' => TeamMember::count(),
                'Messages' => ContactMessage::count(),
                'Quotes' => QuoteRequest::count(),
                'Subscribers' => NewsletterSubscriber::count(),
                'Pricing Plans' => PricingPlan::count(),
                'Pricing Features' => PricingFeature::count(),
            ],
            'recentMessages' => ContactMessage::latest()->limit(5)->get(),
            'recentQuotes' => QuoteRequest::latest()->limit(5)->get(),
        ]);
    }

    public function pages(): View
    {
        return view('admin.index', [
            'title' => 'Pages',
            'items' => Page::latest()->paginate(50),
            'columns' => ['title', 'slug', 'template_type', 'status'],
            'editRoute' => 'admin.pages.edit',
        ]);
    }

    public function editPage(Page $page): View
    {
        return view('admin.edit-page', compact('page'));
    }

    public function updatePage(Request $request, Page $page): RedirectResponse
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'slug' => ['required', 'string', 'max:255'],
            'meta_title' => ['nullable', 'string', 'max:255'],
            'meta_description' => ['nullable', 'string'],
            'template_type' => ['required', 'string', 'max:100'],
            'status' => ['required', 'in:published,draft'],
        ]);
        $page->update($data);
        return back()->with('success', 'Page updated successfully.');
    }

    public function sections(Page $page): View
    {
        return view('admin.index', [
            'title' => 'Sections for '.$page->title,
            'items' => $page->allSections()->paginate(100),
            'columns' => ['section_type', 'heading', 'sort_order', 'is_active'],
            'editRoute' => 'admin.sections.edit',
        ]);
    }

    public function editSection(PageSection $section): View
    {
        return view('admin.edit-section', compact('section'));
    }

    public function updateSection(Request $request, PageSection $section): RedirectResponse
    {
        $data = $request->validate([
            'section_type' => ['required', 'string', 'max:100'],
            'eyebrow' => ['nullable', 'string', 'max:255'],
            'heading' => ['nullable', 'string', 'max:255'],
            'subheading' => ['nullable', 'string'],
            'content' => ['nullable', 'string'],
            'button_text' => ['nullable', 'string', 'max:255'],
            'button_link' => ['nullable', 'string', 'max:255'],
            'sort_order' => ['required', 'integer'],
            'is_active' => ['nullable', 'boolean'],
        ]);
        $data['is_active'] = $request->boolean('is_active');
        $section->update($data);
        return back()->with('success', 'Section updated successfully.');
    }

    public function services(): View { return $this->resourceIndex('Services', Service::orderBy('sort_order')->paginate(50), ['title', 'slug', 'price_from', 'is_featured'], 'admin.services.edit'); }
    public function editService(Service $service): View { return view('admin.edit-service', compact('service')); }
    public function updateService(Request $request, Service $service): RedirectResponse
    {
        $data = $request->validate(['title'=>['required','string','max:255'],'slug'=>['required','string','max:255'],'short_description'=>['nullable','string'],'full_description'=>['nullable','string'],'icon'=>['nullable','string','max:255'],'price_from'=>['nullable','string','max:255'],'is_featured'=>['nullable','boolean'],'is_active'=>['nullable','boolean'],'sort_order'=>['required','integer']]);
        $data['is_featured'] = $request->boolean('is_featured'); $data['is_active'] = $request->boolean('is_active');
        $service->update($data); return back()->with('success','Service updated.');
    }

    public function team(): View { return $this->resourceIndex('Team Members', TeamMember::orderBy('sort_order')->paginate(50), ['name', 'role', 'email', 'is_active'], 'admin.team.edit'); }
    public function editTeamMember(TeamMember $member): View { return view('admin.edit-team', compact('member')); }
    public function updateTeamMember(Request $request, TeamMember $member): RedirectResponse
    {
        $data = $request->validate(['name'=>['required','string','max:255'],'role'=>['nullable','string','max:255'],'bio'=>['nullable','string'],'linkedin_url'=>['nullable','string','max:255'],'twitter_url'=>['nullable','string','max:255'],'github_url'=>['nullable','string','max:255'],'email'=>['nullable','email','max:255'],'is_active'=>['nullable','boolean'],'sort_order'=>['required','integer']]);
        $data['is_active'] = $request->boolean('is_active'); $member->update($data); return back()->with('success','Team member updated.');
    }

    public function portfolio(): View { return $this->resourceIndex('Portfolio Items', PortfolioItem::orderBy('sort_order')->paginate(50), ['title', 'slug', 'category', 'is_featured'], null); }
    public function caseStudies(): View { return $this->resourceIndex('Case Studies', CaseStudy::orderBy('sort_order')->paginate(50), ['title', 'client_name', 'industry', 'is_featured'], null); }
    public function testimonials(): View { return $this->resourceIndex('Testimonials', Testimonial::orderBy('sort_order')->paginate(50), ['client_name', 'company', 'rating', 'is_video'], null); }
    public function pricing(): View
    {
        return view('admin.pricing.index', [
            'plans' => PricingPlan::with('features')->withCount('features')->orderBy('sort_order')->paginate(50),
        ]);
    }

    public function createPricingPlan(): View
    {
        return view('admin.pricing.plan-form', ['plan' => new PricingPlan()]);
    }

    public function storePricingPlan(Request $request): RedirectResponse
    {
        $data = $this->validatePricingPlan($request);
        $data['is_recommended'] = $request->boolean('is_recommended');
        $plan = PricingPlan::create($data);

        return redirect()->route('admin.pricing.edit', $plan)->with('success', 'Pricing plan created. Now add features.');
    }

    public function editPricingPlan(PricingPlan $plan): View
    {
        $plan->load('features');
        return view('admin.pricing.plan-form', compact('plan'));
    }

    public function updatePricingPlan(Request $request, PricingPlan $plan): RedirectResponse
    {
        $data = $this->validatePricingPlan($request);
        $data['is_recommended'] = $request->boolean('is_recommended');
        $plan->update($data);

        return back()->with('success', 'Pricing plan updated.');
    }

    public function destroyPricingPlan(PricingPlan $plan): RedirectResponse
    {
        $plan->delete();
        return redirect()->route('admin.pricing')->with('success', 'Pricing plan deleted with its related features.');
    }

    public function createPricingFeature(PricingPlan $plan): View
    {
        return view('admin.pricing.feature-form', ['plan' => $plan, 'feature' => new PricingFeature()]);
    }

    public function storePricingFeature(Request $request, PricingPlan $plan): RedirectResponse
    {
        $data = $this->validatePricingFeature($request);
        $data['is_available'] = $request->boolean('is_available');
        $plan->features()->create($data);

        return redirect()->route('admin.pricing.edit', $plan)->with('success', 'Pricing feature added.');
    }

    public function editPricingFeature(PricingFeature $feature): View
    {
        $feature->load('plan');
        return view('admin.pricing.feature-form', ['plan' => $feature->plan, 'feature' => $feature]);
    }

    public function updatePricingFeature(Request $request, PricingFeature $feature): RedirectResponse
    {
        $data = $this->validatePricingFeature($request);
        $data['is_available'] = $request->boolean('is_available');
        $feature->update($data);

        return redirect()->route('admin.pricing.edit', $feature->plan)->with('success', 'Pricing feature updated.');
    }

    public function destroyPricingFeature(PricingFeature $feature): RedirectResponse
    {
        $plan = $feature->plan;
        $feature->delete();

        return redirect()->route('admin.pricing.edit', $plan)->with('success', 'Pricing feature deleted.');
    }
    public function faqs(): View { return $this->resourceIndex('FAQs', Faq::orderBy('category')->orderBy('sort_order')->paginate(100), ['category', 'question', 'is_active'], null); }
    public function industries(): View { return $this->resourceIndex('Industries', Industry::orderBy('sort_order')->paginate(50), ['name', 'slug', 'logo_text', 'is_active'], null); }
    public function skills(): View { return $this->resourceIndex('Skills', Skill::orderBy('sort_order')->paginate(50), ['name', 'skill_type', 'percentage', 'is_active'], null); }
    public function blog(): View { return $this->resourceIndex('Blog Posts', BlogPost::latest('published_at')->paginate(50), ['title', 'slug', 'author_name', 'status'], null); }
    public function messages(): View { return $this->resourceIndex('Contact Messages', ContactMessage::latest()->paginate(50), ['name', 'email', 'subject', 'status'], null); }
    public function quotes(): View { return $this->resourceIndex('Quote Requests', QuoteRequest::latest()->paginate(50), ['name', 'email', 'service_interest', 'status'], null); }
    public function subscribers(): View { return $this->resourceIndex('Newsletter Subscribers', NewsletterSubscriber::latest()->paginate(50), ['name', 'email', 'source', 'status'], null); }

    private function validatePricingPlan(Request $request): array
    {
        return $request->validate([
            'plan_name' => ['required', 'string', 'max:255'],
            'price' => ['required', 'string', 'max:255'],
            'billing_cycle' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'button_text' => ['nullable', 'string', 'max:255'],
            'button_link' => ['nullable', 'string', 'max:255'],
            'is_recommended' => ['nullable', 'boolean'],
            'sort_order' => ['required', 'integer'],
        ]);
    }

    private function validatePricingFeature(Request $request): array
    {
        return $request->validate([
            'feature_text' => ['required', 'string', 'max:255'],
            'is_available' => ['nullable', 'boolean'],
            'sort_order' => ['required', 'integer'],
        ]);
    }

    private function resourceIndex(string $title, $items, array $columns, ?string $editRoute): View
    {
        return view('admin.index', compact('title', 'items', 'columns', 'editRoute'));
    }
}
