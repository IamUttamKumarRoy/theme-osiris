<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminAuthController extends Controller
{
    public function login(): View
    {
        return view('admin.login');
    }

    public function authenticate(Request $request): RedirectResponse
    {
        $request->validate(['password' => ['required', 'string']]);

        if (hash_equals((string) env('ADMIN_PASSWORD', 'change-this-password'), (string) $request->password)) {
            $request->session()->put('admin_authenticated', true);
            return redirect()->route('admin.dashboard')->with('success', 'Welcome back to your template builder.');
        }

        return back()->with('error', 'Invalid admin password.');
    }

    public function logout(Request $request): RedirectResponse
    {
        $request->session()->forget('admin_authenticated');
        return redirect()->route('admin.login')->with('success', 'You have been logged out.');
    }
}
