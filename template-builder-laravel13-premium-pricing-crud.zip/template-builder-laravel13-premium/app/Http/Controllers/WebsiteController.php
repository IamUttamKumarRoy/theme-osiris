<?php

namespace App\Http\Controllers;

use App\Models\BlogPost;
use App\Models\CaseStudy;
use App\Models\ContactMessage;
use App\Models\Faq;
use App\Models\Industry;
use App\Models\MenuItem;
use App\Models\NewsletterSubscriber;
use App\Models\Page;
use App\Models\PortfolioItem;
use App\Models\PricingPlan;
use App\Models\QuoteRequest;
use App\Models\ResumeItem;
use App\Models\Service;
use App\Models\SiteSetting;
use App\Models\Skill;
use App\Models\TeamMember;
use App\Models\Testimonial;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WebsiteController extends Controller
{
    public function home(): RedirectResponse
    {
        return redirect()->route('page.show', 'home');
    }

    public function page(string $slug): View
    {
        $page = Page::with('sections')
            ->where('slug', $slug)
            ->where('status', 'published')
            ->firstOrFail();

        $pageSettings = $page->sections->pluck('settings_json')->filter()->collapse();

        return view('pages.show', array_merge($this->globalData(), [
            'page' => $page,
            'pageData' => $this->pageData(),
            'hideHeader' => (bool) ($pageSettings['hide_global_header'] ?? false),
            'hideFooter' => (bool) ($pageSettings['hide_global_footer'] ?? false),
        ]));
    }

    public function service(string $slug): View
    {
        $service = Service::with(['details', 'processSteps'])->where('slug', $slug)->where('is_active', true)->firstOrFail();

        return view('services.show', array_merge($this->globalData(), [
            'service' => $service,
            'services' => Service::where('is_active', true)->orderBy('sort_order')->get(),
            'faqsByCategory' => Faq::where('is_active', true)->orderBy('sort_order')->get()->groupBy('category'),
        ]));
    }

    public function blogPost(string $slug): View
    {
        $post = BlogPost::with('category')
            ->where('slug', $slug)
            ->where('status', 'published')
            ->firstOrFail();

        return view('blog.show', array_merge($this->globalData(), [
            'post' => $post,
            'relatedPosts' => BlogPost::where('status', 'published')
                ->where('id', '!=', $post->id)
                ->latest('published_at')
                ->limit(3)
                ->get(),
        ]));
    }

    public function notFound()
    {
        $page = Page::with('sections')->where('slug', '404')->first();
        return response()->view('errors.404', array_merge($this->globalData(), [
            'page' => $page,
            'pageData' => $this->pageData(),
            'hideHeader' => false,
            'hideFooter' => false,
        ]), 404);
    }

    public function storeContact(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:100'],
            'subject' => ['nullable', 'string', 'max:255'],
            'message' => ['required', 'string', 'max:5000'],
        ]);
        ContactMessage::create($data);
        return back()->with('success', 'Your message has been submitted successfully.');
    }

    public function storeNewsletter(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['nullable', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'source' => ['nullable', 'string', 'max:150'],
        ]);
        NewsletterSubscriber::updateOrCreate(
            ['email' => $data['email']],
            ['name' => $data['name'] ?? null, 'source' => $data['source'] ?? 'website', 'status' => 'subscribed']
        );
        return back()->with('success', 'You have been subscribed successfully.');
    }

    public function storeQuote(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:100'],
            'company_name' => ['nullable', 'string', 'max:255'],
            'service_interest' => ['nullable', 'string', 'max:255'],
            'budget_range' => ['nullable', 'string', 'max:100'],
            'project_timeline' => ['nullable', 'string', 'max:100'],
            'message' => ['nullable', 'string', 'max:5000'],
        ]);
        QuoteRequest::create($data);
        return back()->with('success', 'Your quote request has been submitted successfully.');
    }

    private function globalData(): array
    {
        return [
            'settings' => SiteSetting::pluck('setting_value', 'setting_key'),
            'mainMenu' => MenuItem::with('page')
                ->where('menu_id', 1)
                ->where('is_active', true)
                ->where(function ($query) {
                    $query->whereNotNull('page_id')->orWhereNotNull('url');
                })
                ->orderBy('sort_order')
                ->get(),
        ];
    }

    private function pageData(): array
    {
        return [
            'services' => Service::where('is_active', true)->orderBy('sort_order')->get(),
            'portfolioItems' => PortfolioItem::orderBy('sort_order')->get(),
            'caseStudies' => CaseStudy::with('metrics')->orderBy('sort_order')->get(),
            'teamMembers' => TeamMember::where('is_active', true)->orderBy('sort_order')->get(),
            'testimonials' => Testimonial::orderBy('sort_order')->get(),
            'pricingPlans' => PricingPlan::with('features')->orderBy('sort_order')->get(),
            'faqsByCategory' => Faq::where('is_active', true)->orderBy('category')->orderBy('sort_order')->get()->groupBy('category'),
            'industries' => Industry::where('is_active', true)->orderBy('sort_order')->get(),
            'blogPosts' => BlogPost::with('category')->where('status', 'published')->latest('published_at')->get(),
            'featuredPost' => BlogPost::with('category')->where('status', 'published')->where('is_featured', true)->latest('published_at')->first(),
            'skills' => Skill::where('is_active', true)->orderBy('sort_order')->get(),
            'resumeItems' => ResumeItem::orderBy('sort_order')->get(),
        ];
    }
}
