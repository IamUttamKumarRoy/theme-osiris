<?php

namespace App\Http\Controllers;

abstract class Controller
{
    // Base controller for the premium builder package.
}
