
/* ========================================================================== 
   Theme Switcher
   --------------------------------------------------------------------------
   Handles only theme selection, data-theme, data-bs-theme, and localStorage.
   Keep this separate from auth page interactions for ThemeForest-grade structure.
========================================================================== */
(function () {
  'use strict';

  const THEME_MODES = {
    light: 'light', dark: 'dark', obsidian: 'dark', vercel: 'dark', 'deep-space': 'dark', netflix: 'dark',
    microsoft: 'light', google: 'light', apple: 'light', vscode: 'dark', aws: 'dark', royal: 'light',
    spotify: 'dark', figma: 'light', slack: 'light', airbnb: 'light', uber: 'dark', sapphire: 'light',
    nebula: 'dark', aurora: 'light', phoenix: 'light', sakura: 'light', sunset: 'light', rose: 'light',
    slate: 'light', emerald: 'light', ocean: 'light', 'midnight-teal': 'dark', cyber: 'dark', 'cosmic-aurora': 'dark'
  };

  const DEFAULT_THEME = 'cosmic-aurora';

  function titleCase(value) {
    return value.replace(/-/g, ' ').replace(/\b\w/g, char => char.toUpperCase());
  }

  function applyTheme(themeName, persist = true) {
    if (!Object.prototype.hasOwnProperty.call(THEME_MODES, themeName)) return;
    const mode = THEME_MODES[themeName];
    document.documentElement.setAttribute('data-theme', themeName);
    document.documentElement.setAttribute('data-bs-theme', mode);
    document.documentElement.style.colorScheme = mode;
    if (persist) {
      try { localStorage.setItem('aether-theme', themeName); localStorage.setItem('uttam-theme', themeName); } catch (_) {}
    }
  }

  function initThemeSelector(selector) {
    if (!selector) return;

    if (!selector.options.length) {
      Object.keys(THEME_MODES).forEach(themeName => {
        const option = document.createElement('option');
        option.value = themeName;
        option.textContent = titleCase(themeName);
        selector.appendChild(option);
      });
    }

    let savedTheme = DEFAULT_THEME;
    try { savedTheme = localStorage.getItem('aether-theme') || localStorage.getItem('uttam-theme') || DEFAULT_THEME; } catch (_) {}
    if (!Object.prototype.hasOwnProperty.call(THEME_MODES, savedTheme)) savedTheme = DEFAULT_THEME;

    selector.value = savedTheme;
    applyTheme(savedTheme, false);

    selector.addEventListener('change', () => applyTheme(selector.value));
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-auth-theme-selector], #themeSelector').forEach(initThemeSelector);
  });
})();
