import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import postcss from 'postcss';
import { execFileSync } from 'node:child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const htmlFiles = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith('.html')) htmlFiles.push(full);
  }
}
walk(root);

const errors = [];
const warnings = [];
let themeRefs = 0;

for (const file of htmlFiles) {
  const html = fs.readFileSync(file, 'utf8');
  const rel = path.relative(root, file);
  const themeMatches = [...html.matchAll(/<link\b[^>]*href=["']([^"']*assets\/css\/theme\.min\.css)["'][^>]*>/gi)];
  if (themeMatches.length !== 1) errors.push(`${rel}: expected exactly one theme.min.css reference, found ${themeMatches.length}`);
  themeRefs += themeMatches.length;

  if (/assets\/css\/(?:core|pages|auth)\//i.test(html) || /assets\/app\.css/i.test(html)) {
    errors.push(`${rel}: legacy stylesheet reference remains`);
  }

  const idCounts = new Map();
  for (const tagMatch of html.matchAll(/<[a-z][^>]*>/gi)) {
    const idMatch = tagMatch[0].match(/\bid=["']([^"']+)["']/i);
    if (!idMatch) continue;
    idCounts.set(idMatch[1], (idCounts.get(idMatch[1]) || 0) + 1);
  }
  for (const [id, count] of idCounts) {
    if (count > 1) errors.push(`${rel}: duplicate id "${id}" appears ${count} times`);
  }

  if (!/^\s*<!doctype html>/i.test(html)) errors.push(`${rel}: missing HTML5 doctype`);

  const bootstrapPos = html.search(/assets\/vendor\/bootstrap\/css\/bootstrap\.min\.css/i);
  const themePos = html.search(/assets\/css\/theme\.min\.css/i);
  if (bootstrapPos < 0 || themePos < 0 || themePos < bootstrapPos) {
    errors.push(`${rel}: theme.min.css must load after Bootstrap CSS`);
  }

  const assetRefs = [...html.matchAll(/<(?:link|script|img|source|video|audio|a)\b[^>]*(?:href|src)=["']([^"'#?]+)["'][^>]*>/gi)].map(m => m[1]);
  for (const ref of assetRefs) {
    if (/^(?:https?:|data:|mailto:|tel:|javascript:)/i.test(ref)) continue;
    const target = path.resolve(path.dirname(file), ref);
    if (!fs.existsSync(target)) {
      if (ref.includes('assets/')) errors.push(`${rel}: missing asset ${ref}`);
      else warnings.push(`${rel}: unresolved local link ${ref}`);
    }
  }
}

for (const required of [
  'assets/css/theme.css',
  'assets/css/theme.min.css',
  'assets/css/theme.css.map',
  'src/scss/theme.scss',
  'src/scss/layout/_sidebar.scss',
  'src/scss/overrides/_sidebar-integrity.scss',
  'assets/vendor/bootstrap/css/bootstrap.min.css',
  'assets/js/dashboard.js'
]) {
  if (!fs.existsSync(path.join(root, required))) errors.push(`Missing required file: ${required}`);
}

for (const obsolete of ['assets/css/core', 'assets/css/pages', 'assets/css/auth', 'assets/app.css']) {
  if (fs.existsSync(path.join(root, obsolete))) errors.push(`Obsolete CSS path still exists: ${obsolete}`);
}

try {
  const css = fs.readFileSync(path.join(root, 'assets/css/theme.css'), 'utf8');
  postcss.parse(css, { from: 'assets/css/theme.css' });
  const requiredSidebarMarkers = [
    'isolation: isolate',
    'background-clip: padding-box',
    'border-inline-end-color: transparent',
    '[dir=rtl] #sidebar'
  ];
  for (const marker of requiredSidebarMarkers) {
    if (!css.includes(marker)) errors.push(`Compiled CSS is missing sidebar integrity rule: ${marker}`);
  }
} catch (error) {
  errors.push(`Compiled CSS parse failure: ${error.message}`);
}

const jsRoot = path.join(root, 'assets/js');
for (const file of fs.readdirSync(jsRoot).filter(name => name.endsWith('.js'))) {
  try {
    execFileSync(process.execPath, ['--check', path.join(jsRoot, file)], { stdio: 'pipe' });
  } catch (error) {
    errors.push(`JavaScript syntax failure in assets/js/${file}`);
  }
}

const scssEntry = fs.readFileSync(path.join(root, 'src/scss/theme.scss'), 'utf8');
for (const match of scssEntry.matchAll(/@use\s+["']([^"']+)["']/g)) {
  const partial = match[1];
  const dir = path.dirname(partial);
  const base = path.basename(partial);
  const target = path.join(root, 'src/scss', dir, `_${base}.scss`);
  if (!fs.existsSync(target)) errors.push(`Missing SCSS partial imported by theme.scss: ${partial}`);
}

const report = {
  htmlFiles: htmlFiles.length,
  themeStylesheetReferences: themeRefs,
  compiledCssBytes: fs.statSync(path.join(root, 'assets/css/theme.css')).size,
  minifiedCssBytes: fs.statSync(path.join(root, 'assets/css/theme.min.css')).size,
  errors: errors.length,
  warnings: warnings.length
};
fs.writeFileSync(path.join(root, 'template-validation.json'), JSON.stringify(report, null, 2));

if (errors.length) {
  console.error('\nValidation errors:');
  errors.slice(0, 100).forEach(error => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`Validated ${htmlFiles.length} HTML files with ${themeRefs} unified theme references.`);
console.log(`Parsed production CSS successfully (${report.minifiedCssBytes.toLocaleString()} minified bytes).`);
if (warnings.length) console.log(`${warnings.length} non-blocking demo navigation warnings recorded.`);
