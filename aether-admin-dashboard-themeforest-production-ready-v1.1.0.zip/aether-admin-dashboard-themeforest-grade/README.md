# Aether Bootstrap 5 Admin Dashboard

Production-ready static HTML admin dashboard with a component-based SCSS architecture, Bootstrap 5.3.2, multiple visual themes, responsive layouts, authentication pages, dashboards, ecommerce, CRM, forms, tables, charts, documentation, and application pages.

## Quick start

```bash
npm install
npm run build
```

Open `index.html` or run a local server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Development commands

```bash
npm run build:css   # Compile, prefix, minify, and generate source map
npm run watch:css   # Watch SCSS source during development
npm run validate    # Validate all HTML/CSS references and the compiled build
npm run build       # Build CSS and run the full validation suite
```

## CSS workflow

Edit files inside `src/scss/`. Do not edit `assets/css/theme.css`, `assets/css/theme.min.css`, or `assets/css/theme.css.map` directly because they are generated files.

Every HTML page loads:

1. `assets/vendor/bootstrap-icons/bootstrap-icons.css`
2. `assets/vendor/bootstrap/css/bootstrap.min.css`
3. `assets/css/theme.min.css`

The original page-specific CSS bundles have been consolidated into reusable SCSS components and cross-page patterns.

## Main folders

```text
src/scss/
├── abstracts/   # Sass functions, mixins, and theme tokens
├── base/        # Reset and accessibility foundations
├── layout/      # Shell, sidebar, header, content, footer
├── components/  # Buttons, cards, forms, tables, feedback, overlays, media, charts
├── patterns/    # Authentication, commerce, communication, productivity, docs
├── utilities/   # Helpers and animations
├── overrides/   # Final polish and sidebar integrity fixes
└── theme.scss   # Main entry file
```

See `SCSS-ARCHITECTURE.md` for customization guidance and `PRODUCTION-AUDIT.md` for the release validation summary.
