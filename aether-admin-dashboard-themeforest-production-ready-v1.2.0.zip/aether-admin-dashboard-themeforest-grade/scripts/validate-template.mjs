import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import postcss from 'postcss';
import { execFileSync } from 'node:child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const htmlFiles = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith('.html')) htmlFiles.push(full);
  }
}
walk(root);

const errors = [];
const warnings = [];
let themeRefs = 0;
let bootRefs = 0;
let bootstrapJsRefs = 0;
let appRefs = 0;

for (const file of htmlFiles) {
  const html = fs.readFileSync(file, 'utf8');
  const rel = path.relative(root, file);

  const themeMatches = [...html.matchAll(/<link\b[^>]*href=["']([^"']*assets\/css\/theme\.min\.css)["'][^>]*>/gi)];
  if (themeMatches.length !== 1) errors.push(`${rel}: expected exactly one theme.min.css reference, found ${themeMatches.length}`);
  themeRefs += themeMatches.length;

  if (/assets\/css\/(?:core|pages|auth)\//i.test(html) || /assets\/app\.css/i.test(html)) {
    errors.push(`${rel}: legacy stylesheet reference remains`);
  }

  const scriptTags = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)];
  const sources = [];
  for (const match of scriptTags) {
    const src = match[1].match(/\bsrc=["']([^"']+)["']/i)?.[1];
    if (src) sources.push({ src, index: match.index });
    else if (match[2].trim()) errors.push(`${rel}: inline JavaScript remains`);
  }

  const boot = sources.filter(({ src }) => /assets\/js\/theme-boot\.js(?:[?#].*)?$/i.test(src));
  const bootstrapJs = sources.filter(({ src }) => /assets\/vendor\/bootstrap\/js\/bootstrap\.bundle\.min\.js(?:[?#].*)?$/i.test(src));
  const app = sources.filter(({ src }) => /assets\/js\/app\.js(?:[?#].*)?$/i.test(src));
  bootRefs += boot.length;
  bootstrapJsRefs += bootstrapJs.length;
  appRefs += app.length;

  if (boot.length !== 1) errors.push(`${rel}: expected one theme-boot.js reference, found ${boot.length}`);
  if (bootstrapJs.length !== 1) errors.push(`${rel}: expected one Bootstrap bundle reference, found ${bootstrapJs.length}`);
  if (app.length !== 1) errors.push(`${rel}: expected one app.js reference, found ${app.length}`);
  if (sources.length !== 3) errors.push(`${rel}: expected exactly three runtime JavaScript files, found ${sources.length}`);

  if (sources.some(({ src }) => /(?:dashboard|aether-polish|auth-pages|auth-demo|theme-switcher|assets\/js\/auth)\.js(?:[?#].*)?$/i.test(src))) {
    errors.push(`${rel}: legacy custom JavaScript reference remains`);
  }
  if (/\son(?:click|change|input|submit|keydown|keyup|mouseover|mouseout|focus|blur)\s*=/i.test(html)) {
    errors.push(`${rel}: inline event attribute remains`);
  }

  const themeCssPos = html.search(/assets\/css\/theme\.min\.css/i);
  const bootPos = boot[0]?.index ?? -1;
  const bootstrapJsPos = bootstrapJs[0]?.index ?? -1;
  const appPos = app[0]?.index ?? -1;
  if (bootPos < 0 || themeCssPos < 0 || bootPos > themeCssPos) errors.push(`${rel}: theme-boot.js must load before theme CSS`);
  if (bootstrapJsPos < 0 || appPos < 0 || bootstrapJsPos > appPos) errors.push(`${rel}: app.js must load after Bootstrap JS`);

  const idCounts = new Map();
  for (const tagMatch of html.matchAll(/<[a-z][^>]*>/gi)) {
    const idMatch = tagMatch[0].match(/\bid=["']([^"']+)["']/i);
    if (!idMatch) continue;
    idCounts.set(idMatch[1], (idCounts.get(idMatch[1]) || 0) + 1);
  }
  for (const [id, count] of idCounts) {
    if (count > 1) errors.push(`${rel}: duplicate id "${id}" appears ${count} times`);
  }

  if (!/^\s*<!doctype html>/i.test(html)) errors.push(`${rel}: missing HTML5 doctype`);

  const bootstrapCssPos = html.search(/assets\/vendor\/bootstrap\/css\/bootstrap\.min\.css/i);
  if (bootstrapCssPos < 0 || themeCssPos < 0 || themeCssPos < bootstrapCssPos) {
    errors.push(`${rel}: theme.min.css must load after Bootstrap CSS`);
  }

  const assetRefs = [...html.matchAll(/<(?:link|script|img|source|video|audio|a)\b[^>]*(?:href|src)=["']([^"'#?]+)["'][^>]*>/gi)].map(match => match[1]);
  for (const ref of assetRefs) {
    if (/^(?:https?:|data:|mailto:|tel:|javascript:)/i.test(ref)) continue;
    const target = path.resolve(path.dirname(file), ref);
    if (!fs.existsSync(target)) {
      if (ref.includes('assets/')) errors.push(`${rel}: missing asset ${ref}`);
      else warnings.push(`${rel}: unresolved local link ${ref}`);
    }
  }
}

for (const required of [
  'assets/css/theme.css',
  'assets/css/theme.min.css',
  'assets/css/theme.css.map',
  'src/scss/theme.scss',
  'src/scss/layout/_sidebar.scss',
  'src/scss/overrides/_sidebar-integrity.scss',
  'assets/vendor/bootstrap/css/bootstrap.min.css',
  'assets/vendor/bootstrap/js/bootstrap.bundle.min.js',
  'assets/js/theme-boot.js',
  'assets/js/app.js'
]) {
  if (!fs.existsSync(path.join(root, required))) errors.push(`Missing required file: ${required}`);
}

for (const obsolete of [
  'assets/css/core', 'assets/css/pages', 'assets/css/auth', 'assets/app.css',
  'assets/js/dashboard.js', 'assets/js/aether-polish.js', 'assets/js/auth.js',
  'assets/js/auth-pages.js', 'assets/js/auth-demo.js', 'assets/js/theme-switcher.js'
]) {
  if (fs.existsSync(path.join(root, obsolete))) errors.push(`Obsolete path still exists: ${obsolete}`);
}

const customJsFiles = fs.readdirSync(path.join(root, 'assets/js')).filter(name => name.endsWith('.js')).sort();
if (customJsFiles.join(',') !== 'app.js,theme-boot.js') {
  errors.push(`assets/js must contain only app.js and theme-boot.js; found: ${customJsFiles.join(', ')}`);
}

try {
  const css = fs.readFileSync(path.join(root, 'assets/css/theme.css'), 'utf8');
  postcss.parse(css, { from: 'assets/css/theme.css' });
  for (const marker of ['isolation: isolate', 'background-clip: padding-box', 'border-inline-end-color: transparent', '[dir=rtl] #sidebar']) {
    if (!css.includes(marker)) errors.push(`Compiled CSS is missing sidebar integrity rule: ${marker}`);
  }
} catch (error) {
  errors.push(`Compiled CSS parse failure: ${error.message}`);
}

for (const file of [
  path.join(root, 'assets/js/theme-boot.js'),
  path.join(root, 'assets/js/app.js'),
  path.join(root, 'assets/vendor/bootstrap/js/bootstrap.bundle.min.js')
]) {
  try {
    execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' });
  } catch (_) {
    errors.push(`JavaScript syntax failure in ${path.relative(root, file)}`);
  }
}

const appSource = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
for (const marker of ['var ClickHandlers = [', "document.addEventListener('click', Events.click)", 'CommandPalette.commands', 'Auth.submit', 'window.Aether']) {
  if (!appSource.includes(marker)) errors.push(`app.js is missing architecture marker: ${marker}`);
}
if ((appSource.match(/document\.addEventListener\('click'/g) || []).length !== 1) {
  errors.push('app.js must register exactly one delegated document click listener');
}

const scssEntry = fs.readFileSync(path.join(root, 'src/scss/theme.scss'), 'utf8');
for (const match of scssEntry.matchAll(/@use\s+["']([^"']+)["']/g)) {
  const partial = match[1];
  const dir = path.dirname(partial);
  const base = path.basename(partial);
  const target = path.join(root, 'src/scss', dir, `_${base}.scss`);
  if (!fs.existsSync(target)) errors.push(`Missing SCSS partial imported by theme.scss: ${partial}`);
}

const report = {
  htmlFiles: htmlFiles.length,
  themeStylesheetReferences: themeRefs,
  themeBootReferences: bootRefs,
  bootstrapJsReferences: bootstrapJsRefs,
  applicationJsReferences: appRefs,
  runtimeJsFilesPerPage: 3,
  customRuntimeJsFiles: customJsFiles.length,
  appJsBytes: fs.statSync(path.join(root, 'assets/js/app.js')).size,
  themeBootBytes: fs.statSync(path.join(root, 'assets/js/theme-boot.js')).size,
  compiledCssBytes: fs.statSync(path.join(root, 'assets/css/theme.css')).size,
  minifiedCssBytes: fs.statSync(path.join(root, 'assets/css/theme.min.css')).size,
  errors: errors.length,
  warnings: warnings.length
};
fs.writeFileSync(path.join(root, 'template-validation.json'), JSON.stringify(report, null, 2));

if (errors.length) {
  console.error('\nValidation errors:');
  errors.slice(0, 150).forEach(error => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`Validated ${htmlFiles.length} HTML files with one CSS bundle and three runtime JS files per page.`);
console.log(`Parsed production CSS and all JavaScript successfully.`);
console.log(`Custom runtime JavaScript: ${customJsFiles.join(', ')}.`);
if (warnings.length) console.log(`${warnings.length} non-blocking demo navigation warnings recorded.`);
