import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as sass from 'sass';
import postcss from 'postcss';
import autoprefixer from 'autoprefixer';
import cssnano from 'cssnano';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const input = path.join(root, 'src/scss/theme.scss');
const outputDir = path.join(root, 'assets/css');
const output = path.join(outputDir, 'theme.css');
const outputMin = path.join(outputDir, 'theme.min.css');
const mapFile = path.join(outputDir, 'theme.css.map');
const banner = `/*! Aether Bootstrap 5 Admin Dashboard | Production Build | ${new Date().getFullYear()} */\n`;

await fs.mkdir(outputDir, { recursive: true });

const compiled = sass.compile(input, {
  style: 'expanded',
  sourceMap: true,
  sourceMapIncludeSources: true,
  loadPaths: [path.join(root, 'src/scss')],
  quietDeps: true
});

const expanded = await postcss([autoprefixer]).process(compiled.css, {
  from: input,
  to: output,
  map: {
    inline: false,
    annotation: path.basename(mapFile),
    prev: compiled.sourceMap
  }
});

await fs.writeFile(output, banner + expanded.css, 'utf8');
if (expanded.map) await fs.writeFile(mapFile, expanded.map.toString(), 'utf8');

const minified = await postcss([
  autoprefixer,
  cssnano({ preset: ['default', { discardComments: { removeAll: true } }] })
]).process(compiled.css, { from: input, to: outputMin, map: false });

await fs.writeFile(outputMin, banner + minified.css, 'utf8');

const expandedBytes = Buffer.byteLength(banner + expanded.css);
const minifiedBytes = Buffer.byteLength(banner + minified.css);
console.log(`Built assets/css/theme.css (${expandedBytes.toLocaleString()} bytes)`);
console.log(`Built assets/css/theme.min.css (${minifiedBytes.toLocaleString()} bytes)`);
