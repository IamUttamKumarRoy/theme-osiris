/* ========================================================================
   Aether Admin Dashboard - Application Bundle
   ThemeForest production build: shared UI, layout, auth and demo behaviors.

   Event architecture
   - One delegated click router for independent click actions
   - One delegated handler per input/change/focus/keyboard event family
   - DOM-conditional modules: code runs only when matching markup exists
======================================================================== */
(function (window, document) {
  'use strict';

  /* ---------------------------------------------------------------------
     Configuration
  --------------------------------------------------------------------- */
  var ROOT = document.documentElement;
  var STORAGE = Object.freeze({
    theme: 'aether-theme',
    legacyTheme: 'uttam-theme',
    sidebar: 'aether-sidebar-collapsed',
    rememberedEmail: 'aether-remembered-email'
  });

  var THEMES = Object.freeze({
    light: { label: 'Light', mode: 'light' },
    dark: { label: 'Dark', mode: 'dark' },
    obsidian: { label: 'Obsidian', mode: 'dark' },
    vercel: { label: 'Vercel Black', mode: 'dark' },
    'deep-space': { label: 'Deep Space', mode: 'dark' },
    netflix: { label: 'Netflix Red', mode: 'dark' },
    microsoft: { label: 'Microsoft Fluent', mode: 'light' },
    google: { label: 'Google Material 3', mode: 'light' },
    apple: { label: 'Apple SF', mode: 'light' },
    vscode: { label: 'VSCode Dark', mode: 'dark' },
    aws: { label: 'AWS Orange', mode: 'dark' },
    royal: { label: 'Royal', mode: 'light' },
    spotify: { label: 'Spotify Green', mode: 'dark' },
    figma: { label: 'Figma Purple', mode: 'light' },
    slack: { label: 'Slack Sidebar', mode: 'light' },
    airbnb: { label: 'Airbnb Pink', mode: 'light' },
    uber: { label: 'Uber Black', mode: 'dark' },
    sapphire: { label: 'Sapphire Glass', mode: 'light' },
    nebula: { label: 'Nebula', mode: 'dark' },
    aurora: { label: 'Aurora', mode: 'light' },
    phoenix: { label: 'Phoenix', mode: 'light' },
    sakura: { label: 'Sakura', mode: 'light' },
    sunset: { label: 'Sunset', mode: 'light' },
    rose: { label: 'Rose', mode: 'light' },
    slate: { label: 'Slate', mode: 'light' },
    emerald: { label: 'Emerald', mode: 'light' },
    ocean: { label: 'Ocean', mode: 'light' },
    'midnight-teal': { label: 'Midnight Teal', mode: 'dark' },
    cyber: { label: 'Cyber', mode: 'dark' },
    'cosmic-aurora': { label: 'Cosmic Aurora', mode: 'dark' }
  });

  var state = {
    commandTrigger: null,
    toastTimer: 0,
    resizeFrame: 0,
    scrollFrame: 0,
    touchedFields: new WeakSet(),
    resendTimers: new WeakMap()
  };

  /* ---------------------------------------------------------------------
     Utilities
  --------------------------------------------------------------------- */
  function qs(selector, scope) {
    return (scope || document).querySelector(selector);
  }

  function qsa(selector, scope) {
    return Array.prototype.slice.call((scope || document).querySelectorAll(selector));
  }

  function safeGet(key) {
    try { return window.localStorage.getItem(key); } catch (_) { return null; }
  }

  function safeSet(key, value) {
    try { window.localStorage.setItem(key, value); } catch (_) {}
  }

  function safeRemove(key) {
    try { window.localStorage.removeItem(key); } catch (_) {}
  }

  function owns(object, key) {
    return Object.prototype.hasOwnProperty.call(object, key);
  }

  function ready(callback) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', callback, { once: true });
    else callback();
  }

  function appScript() {
    return qsa('script[src]').find(function (script) {
      return /(?:^|\/)assets\/js\/app\.js(?:[?#].*)?$/.test(script.getAttribute('src') || '');
    });
  }

  function templateUrl(path) {
    var script = appScript();
    if (!script || !script.src) return path;
    return new URL('../../' + String(path || '').replace(/^\/+/, ''), script.src).href;
  }

  function formDataObject(form) {
    return Object.fromEntries(new FormData(form).entries());
  }

  function isReducedMotion() {
    return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  /* ---------------------------------------------------------------------
     Theme module
  --------------------------------------------------------------------- */
  var Theme = {
    current: function () {
      var forced = ROOT.getAttribute('data-force-theme');
      if (owns(THEMES, forced)) return forced;
      var saved = safeGet(STORAGE.theme) || safeGet(STORAGE.legacyTheme);
      if (owns(THEMES, saved)) return saved;
      var fallback = ROOT.getAttribute('data-default-theme') || ROOT.getAttribute('data-theme') || 'light';
      return owns(THEMES, fallback) ? fallback : 'light';
    },

    accent: function () {
      return window.getComputedStyle(ROOT).getPropertyValue('--t-accent').trim() || '#38bdf8';
    },

    apply: function (themeName, persist) {
      var forced = ROOT.getAttribute('data-force-theme');
      var selected = owns(THEMES, forced) ? forced : (owns(THEMES, themeName) ? themeName : 'light');
      var theme = THEMES[selected];

      ROOT.setAttribute('data-theme', selected);
      ROOT.setAttribute('data-bs-theme', theme.mode);
      ROOT.style.colorScheme = theme.mode;

      if (persist !== false && !owns(THEMES, forced)) {
        safeSet(STORAGE.theme, selected);
        safeSet(STORAGE.legacyTheme, selected);
      }

      qsa('.theme-swatch[data-theme]').forEach(function (button) {
        var active = button.dataset.theme === selected;
        button.classList.toggle('active', active);
        button.classList.toggle('is-active', active);
        button.setAttribute('aria-pressed', String(active));
      });

      qsa('[data-auth-theme-selector], [data-auth-theme-select], #themeSelector').forEach(function (select) {
        if (select.tagName === 'SELECT') {
          select.value = selected;
          select.disabled = owns(THEMES, forced);
        }
      });

      var label = qs('#themePreviewLabel');
      if (label) label.textContent = theme.label;

      window.requestAnimationFrame(function () {
        var accent = Theme.accent();
        var meta = qs('#metaThemeColor');
        if (meta) meta.setAttribute('content', accent);
        qsa('.js-theme-avatar[data-avatar-name]').forEach(function (image) {
          image.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(image.dataset.avatarName || 'User') +
            '&background=' + accent.replace('#', '') + '&color=0f172a&bold=true&size=34';
        });
      });
    },

    buildSelectors: function () {
      qsa('[data-auth-theme-selector], [data-auth-theme-select], #themeSelector').forEach(function (select) {
        if (select.tagName !== 'SELECT' || select.options.length) return;
        var fragment = document.createDocumentFragment();
        Object.keys(THEMES).forEach(function (key) {
          var option = document.createElement('option');
          option.value = key;
          option.textContent = THEMES[key].label;
          fragment.appendChild(option);
        });
        select.appendChild(fragment);
      });
    },

    filter: function (query) {
      var normalized = String(query || '').trim().toLowerCase();
      var visible = 0;
      qsa('.theme-swatch[data-theme]').forEach(function (button) {
        var theme = THEMES[button.dataset.theme];
        var haystack = [button.title, button.dataset.theme, theme && theme.label].join(' ').toLowerCase();
        var match = haystack.indexOf(normalized) !== -1;
        button.hidden = !match;
        if (match) visible += 1;
      });
      qsa('.theme-grid').forEach(function (grid) {
        grid.hidden = !qsa('.theme-swatch:not([hidden])', grid).length;
      });
      qsa('.theme-group-label').forEach(function (label) {
        var grid = label.nextElementSibling;
        label.hidden = Boolean(grid && grid.classList.contains('theme-grid') && grid.hidden);
      });
      var empty = qs('#themeNoResults');
      if (empty) empty.hidden = visible > 0;
    },

    preview: function (button) {
      var label = qs('#themePreviewLabel');
      var theme = button && THEMES[button.dataset.theme];
      if (label && theme) label.textContent = button.title || theme.label;
    },

    init: function () {
      Theme.buildSelectors();
      Theme.apply(Theme.current(), false);
    }
  };

  /* ---------------------------------------------------------------------
     Layout module
  --------------------------------------------------------------------- */
  var Layout = {
    mobile: function () {
      return window.matchMedia('(max-width: 767.98px)').matches;
    },

    openSidebar: function () {
      var sidebar = qs('#sidebar');
      var overlay = qs('#sidebarOverlay');
      var toggle = qs('#sidebarCollapse');
      if (!sidebar) return;
      sidebar.classList.add('sidebar-open', 'active');
      if (overlay) overlay.classList.add('active');
      if (toggle) toggle.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
    },

    closeSidebar: function () {
      var sidebar = qs('#sidebar');
      var overlay = qs('#sidebarOverlay');
      var toggle = qs('#sidebarCollapse');
      if (sidebar) sidebar.classList.remove('sidebar-open', 'active');
      if (overlay) overlay.classList.remove('active');
      if (toggle) toggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    },

    toggleSidebar: function () {
      var wrapper = qs('#adminWrapper');
      var sidebar = qs('#sidebar');
      var toggle = qs('#sidebarCollapse');
      if (!sidebar) return;

      if (Layout.mobile()) {
        if (sidebar.classList.contains('sidebar-open') || sidebar.classList.contains('active')) Layout.closeSidebar();
        else Layout.openSidebar();
        return;
      }

      if (!wrapper) return;
      var collapsed = wrapper.classList.toggle('sidebar-collapsed');
      if (toggle) toggle.setAttribute('aria-expanded', String(!collapsed));
      safeSet(STORAGE.sidebar, String(collapsed));
    },

    syncViewport: function () {
      if (!Layout.mobile()) Layout.closeSidebar();
    },

    updateHeader: function () {
      var header = qs('.admin-header');
      if (header) header.classList.toggle('is-scrolled', window.scrollY > 8);
    },

    markActiveLink: function () {
      var current = new URL(window.location.href);
      var best = null;
      qsa('.admin-sidebar__nav a.nav-link[href], .sidebarnav a.nav-link[href]').forEach(function (link) {
        try {
          var target = new URL(link.getAttribute('href'), current);
          if (target.pathname.replace(/\/$/, '/index.html') === current.pathname.replace(/\/$/, '/index.html')) best = link;
        } catch (_) {}
      });
      if (!best) return;
      qsa('.admin-sidebar__nav a.nav-link.active, .sidebarnav a.nav-link.active').forEach(function (link) {
        if (link !== best) {
          link.classList.remove('active');
          link.removeAttribute('aria-current');
        }
      });
      best.classList.add('active');
      best.setAttribute('aria-current', 'page');
      var collapse = best.closest('.collapse');
      if (collapse) {
        collapse.classList.add('show');
        var trigger = qs('[data-bs-target="#' + CSS.escape(collapse.id) + '"]');
        if (trigger) trigger.setAttribute('aria-expanded', 'true');
      }
    },

    init: function () {
      var wrapper = qs('#adminWrapper');
      var toggle = qs('#sidebarCollapse');
      if (wrapper && !Layout.mobile()) {
        var collapsed = safeGet(STORAGE.sidebar) === 'true';
        wrapper.classList.toggle('sidebar-collapsed', collapsed);
        if (toggle) toggle.setAttribute('aria-expanded', String(!collapsed));
      }
      var nav = qs('.admin-sidebar__nav');
      if (nav && !window.location.hash) nav.scrollTop = 0;
      Layout.markActiveLink();
      Layout.updateHeader();
    }
  };

  /* ---------------------------------------------------------------------
     Command palette module
  --------------------------------------------------------------------- */
  var CommandPalette = {
    elements: function () {
      return {
        backdrop: qs('#commandPaletteBackdrop'),
        input: qs('#commandPaletteInput'),
        list: qs('#commandPaletteList')
      };
    },

    commands: function () {
      var seen = new Set();
      return qsa('.admin-sidebar__nav a[href][data-page], .sidebarnav a[href][data-page]').reduce(function (items, link) {
        var href = link.getAttribute('href');
        if (!href || href === '#' || seen.has(href)) return items;
        seen.add(href);
        var icon = qs('.bi', link);
        items.push({
          label: link.dataset.page || link.textContent.trim(),
          href: href,
          icon: icon ? Array.from(icon.classList).find(function (name) { return name.indexOf('bi-') === 0; }) : 'bi-file-earmark'
        });
        return items;
      }, []);
    },

    render: function (query) {
      var elements = CommandPalette.elements();
      if (!elements.list) return;
      var filter = String(query || '').trim().toLowerCase();
      var matches = CommandPalette.commands().filter(function (item) {
        return item.label.toLowerCase().indexOf(filter) !== -1;
      }).slice(0, 80);

      elements.list.replaceChildren();
      if (!matches.length) {
        var empty = document.createElement('div');
        empty.className = 'command-palette__item text-muted';
        empty.textContent = 'No matching command found.';
        elements.list.appendChild(empty);
        return;
      }

      var fragment = document.createDocumentFragment();
      matches.forEach(function (item) {
        var link = document.createElement('a');
        link.className = 'command-palette__item text-decoration-none';
        link.href = item.href;
        var icon = document.createElement('i');
        icon.className = 'bi ' + (item.icon || 'bi-file-earmark');
        icon.setAttribute('aria-hidden', 'true');
        var label = document.createElement('span');
        label.textContent = item.label;
        link.append(icon, label);
        fragment.appendChild(link);
      });
      elements.list.appendChild(fragment);
    },

    open: function (trigger) {
      var elements = CommandPalette.elements();
      if (!elements.backdrop) return;
      state.commandTrigger = trigger || document.activeElement;
      if (elements.input) elements.input.value = '';
      CommandPalette.render('');
      elements.backdrop.classList.add('show');
      elements.backdrop.setAttribute('aria-hidden', 'false');
      window.setTimeout(function () { if (elements.input) elements.input.focus(); }, isReducedMotion() ? 0 : 30);
    },

    close: function () {
      var elements = CommandPalette.elements();
      if (!elements.backdrop) return;
      elements.backdrop.classList.remove('show');
      elements.backdrop.setAttribute('aria-hidden', 'true');
      if (elements.input) elements.input.value = '';
      if (state.commandTrigger && typeof state.commandTrigger.focus === 'function') state.commandTrigger.focus();
      state.commandTrigger = null;
    }
  };

  /* ---------------------------------------------------------------------
     Feedback module
  --------------------------------------------------------------------- */
  var Feedback = {
    toast: function (message) {
      if (!message) return;
      var toast = qs('.aether-toast');
      if (!toast) {
        toast = document.createElement('div');
        toast.className = 'aether-toast';
        toast.setAttribute('role', 'status');
        toast.setAttribute('aria-live', 'polite');
        document.body.appendChild(toast);
      }
      toast.textContent = message;
      toast.classList.add('is-visible');
      window.clearTimeout(state.toastTimer);
      state.toastTimer = window.setTimeout(function () { toast.classList.remove('is-visible'); }, 2200);
    },

    alert: function (scope, type, message) {
      var container = scope && scope.querySelector ? scope : document;
      var alert = qs('[data-auth-alert]', container) || qs('[data-auth-alert]');
      if (!alert) return;
      var icon = qs('[data-auth-alert-icon]', alert) || qs('[data-auth-alert-icon]', container);
      var text = qs('[data-auth-alert-message]', alert) || qs('[data-auth-alert-message]', container);
      var normalized = type === 'danger' ? 'danger' : (type === 'success' ? 'success' : 'info');

      alert.hidden = false;
      alert.classList.remove('alert-success', 'alert-danger', 'alert-info', 'is-success', 'is-error', 'is-danger', 'is-info');
      alert.classList.add('show', 'is-visible', 'alert-' + normalized, normalized === 'danger' ? 'is-error' : 'is-' + normalized);
      if (text) text.textContent = message || '';
      if (icon) {
        icon.className = normalized === 'success' ? 'bi bi-check-circle-fill' :
          (normalized === 'danger' ? 'bi bi-exclamation-triangle-fill' : 'bi bi-info-circle-fill');
      }
    },

    hideAlert: function (scope) {
      var alert = qs('[data-auth-alert]', scope) || qs('[data-auth-alert]');
      if (!alert) return;
      alert.hidden = true;
      alert.classList.remove('show', 'is-visible');
    }
  };

  /* ---------------------------------------------------------------------
     Authentication module
  --------------------------------------------------------------------- */
  var Auth = {
    value: function (field) {
      if (field.type === 'checkbox') return field.checked ? (field.value || '1') : '';
      return String(field.value || '').trim();
    },

    feedback: function (field) {
      if (!field.id) return null;
      var form = field.closest('[data-auth-form]');
      return qs('[data-feedback-for="' + CSS.escape(field.id) + '"]', form || document);
    },

    setFieldState: function (field, error, showValid) {
      var invalid = Boolean(error);
      var hasValue = Boolean(Auth.value(field));
      var group = field.closest('.input-group, .auth-control-group');
      var feedback = Auth.feedback(field);
      var message = feedback && qs('[data-feedback-message]', feedback);

      field.classList.toggle('is-invalid', invalid);
      field.classList.toggle('is-valid', !invalid && Boolean(showValid) && hasValue && field.type !== 'checkbox');
      field.setAttribute('aria-invalid', String(invalid));
      if (group) {
        group.classList.toggle('is-invalid', invalid);
        group.classList.toggle('is-valid', !invalid && Boolean(showValid) && hasValue);
      }
      if (feedback) {
        feedback.classList.toggle('is-visible', invalid);
        feedback.style.display = invalid ? 'flex' : '';
      }
      if (message && error) message.textContent = error;
    },

    validateField: function (field, showValid) {
      var rules = String(field.dataset.validate || '').split('|').filter(Boolean);
      var value = Auth.value(field);
      var label = field.dataset.label || (field.name ? field.name.replace(/[-_]/g, ' ') : 'This field');
      var error = '';

      if (rules.indexOf('required') !== -1 && !value) error = field.dataset.errorRequired || label + ' is required.';
      if (!error && rules.indexOf('checkbox') !== -1 && !field.checked) error = field.dataset.errorRequired || label + ' is required.';
      if (!error && rules.indexOf('email') !== -1 && value && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
        error = field.dataset.errorEmail || 'Please enter a valid email address.';
      }
      if (!error && rules.indexOf('minlength') !== -1) {
        var minimum = Number(field.dataset.minLength || field.getAttribute('minlength') || 1);
        if (value.length < minimum) error = field.dataset.errorMinlength || label + ' must be at least ' + minimum + ' characters.';
      }
      if (!error && rules.indexOf('exactlength') !== -1) {
        var exact = Number(field.dataset.exactLength || field.getAttribute('maxlength') || 1);
        if (value.length !== exact) error = field.dataset.errorExactlength || label + ' must be ' + exact + ' characters.';
      }
      if (!error && rules.indexOf('password') !== -1) {
        var passwordMinimum = Number(field.dataset.minLength || field.getAttribute('minlength') || 8);
        if (value.length < passwordMinimum) error = field.dataset.errorPassword || 'Password must be at least ' + passwordMinimum + ' characters.';
      }
      if (!error && rules.indexOf('confirm') !== -1 && field.dataset.match) {
        var form = field.closest('[data-auth-form]');
        var target = form && qs(field.dataset.match, form);
        if (target && value !== String(target.value || '')) error = field.dataset.errorConfirm || 'Passwords do not match.';
      }

      Auth.setFieldState(field, error, showValid);
      return !error;
    },

    validateForm: function (form) {
      var valid = qsa('[data-validate]', form).map(function (field) {
        state.touchedFields.add(field);
        return Auth.validateField(field, true);
      }).every(Boolean);
      var first = qs('.is-invalid, [aria-invalid="true"]', form);
      if (!valid && first && typeof first.focus === 'function') first.focus();
      return valid;
    },

    scorePassword: function (value) {
      var score = 0;
      if (value.length >= 8) score += 1;
      if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score += 1;
      if (/\d/.test(value)) score += 1;
      if (/[^A-Za-z0-9]/.test(value)) score += 1;
      return score;
    },

    updateStrength: function (input) {
      if (!input.dataset.passwordStrength) return;
      var form = input.closest('[data-auth-form]') || document;
      var value = input.value || '';
      var score = Auth.scorePassword(value);
      var bar = qs(input.dataset.passwordStrength, form) || qs(input.dataset.passwordStrength);
      var live = qs('[data-strength-text-for="' + CSS.escape(input.id) + '"]', form) || qs('[data-strength-text-for="' + CSS.escape(input.id) + '"]');
      var labels = ['empty', 'weak', 'fair', 'good', 'strong'];
      if (bar) bar.dataset.strength = String(score);
      if (live) live.textContent = 'Password strength: ' + labels[value.length ? score || 1 : 0];
      qsa('[data-rule-for="' + CSS.escape(input.id) + '"]', form).forEach(function (rule) {
        var type = rule.dataset.rule;
        var passed = (type === 'length' && value.length >= 8) ||
          (type === 'case' && /[a-z]/.test(value) && /[A-Z]/.test(value)) ||
          (type === 'number' && /\d/.test(value)) ||
          (type === 'symbol' && /[^A-Za-z0-9]/.test(value));
        rule.classList.toggle('is-valid', passed);
        var icon = qs('.bi, i', rule);
        if (icon) icon.className = passed ? 'bi bi-check-circle-fill me-1' : 'bi bi-circle me-1';
      });
    },

    otpInputs: function (field) {
      var form = field.closest('[data-auth-form]');
      var grid = field.closest('.auth-otp-grid, [data-otp-grid]');
      return qsa('[data-otp-input]', grid || form || document);
    },

    syncOtp: function (field) {
      var form = field.closest('[data-auth-form]');
      if (!form) return;
      var inputs = Auth.otpInputs(field);
      var hidden = qs('[data-otp-hidden]', form);
      if (hidden) {
        hidden.value = inputs.map(function (input) { return input.value.replace(/\D/g, ''); }).join('');
        if (state.touchedFields.has(hidden)) Auth.validateField(hidden, true);
      }
    },

    togglePassword: function (button) {
      var targetId = button.getAttribute('aria-controls') || button.dataset.target;
      var input = (targetId && document.getElementById(targetId)) || qs('input', button.closest('.input-group, .auth-control-group'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      button.setAttribute('aria-pressed', String(show));
      button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      var icon = qs('.bi, i', button);
      if (icon) icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
      input.focus();
    },

    rememberedEmail: function () {
      var raw = safeGet(STORAGE.rememberedEmail);
      if (!raw) return '';
      try {
        var parsed = JSON.parse(raw);
        if (parsed.savedAt && Date.now() - parsed.savedAt < 2592000000 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(parsed.email)) return parsed.email;
      } catch (_) {}
      safeRemove(STORAGE.rememberedEmail);
      return '';
    },

    saveRememberedEmail: function (form) {
      var remember = qs('[data-auth-remember]', form);
      var email = qs('[data-auth-email]', form);
      if (!remember || !email) return;
      if (!remember.checked) return safeRemove(STORAGE.rememberedEmail);
      safeSet(STORAGE.rememberedEmail, JSON.stringify({ email: email.value.trim(), savedAt: Date.now() }));
    },

    setLoading: function (form, loading) {
      var button = qs('[data-auth-submit-button]', form);
      if (!button) return;
      if (loading) {
        if (!button.dataset.defaultHtml) button.dataset.defaultHtml = button.innerHTML;
        button.innerHTML = '<span class="auth-btn-spinner btn-spinner" aria-hidden="true"></span><span>' +
          (button.dataset.loadingText || 'Processing...') + '</span>';
        button.setAttribute('aria-busy', 'true');
      } else {
        button.innerHTML = button.dataset.defaultHtml || button.innerHTML;
        button.removeAttribute('aria-busy');
      }
      button.disabled = loading;
      form.classList.toggle('is-submitting', loading);
    },

    resolveRedirect: function (value) {
      return value ? new URL(value, window.location.href).href : '';
    },

    ajax: async function (form) {
      var response = await window.fetch(form.action, {
        method: form.method || 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(formDataObject(form))
      });
      if (!response.ok) throw new Error('Request failed. Please try again.');
      return response.json().catch(function () { return {}; });
    },

    submit: async function (form, event) {
      Feedback.hideAlert(form);
      if (!Auth.validateForm(form)) {
        event.preventDefault();
        Feedback.alert(form, 'danger', 'Please fix the highlighted fields and try again.');
        return;
      }
      Auth.saveRememberedEmail(form);
      if (form.dataset.authNative === 'true') return;

      event.preventDefault();
      Auth.setLoading(form, true);
      try {
        var message = form.dataset.successMessage || 'Request completed successfully.';
        if (form.dataset.authAjax === 'true') {
          var result = await Auth.ajax(form);
          message = result.message || message;
        } else {
          await new Promise(function (resolve) { window.setTimeout(resolve, 650); });
        }
        Feedback.alert(form, 'success', message);
        var redirect = Auth.resolveRedirect(form.dataset.redirect);
        if (redirect) window.setTimeout(function () { window.location.href = redirect; }, 800);
      } catch (error) {
        Feedback.alert(form, 'danger', error.message || 'Request failed. Please try again.');
      } finally {
        Auth.setLoading(form, false);
      }
    },

    resend: function (button) {
      if (state.resendTimers.has(button)) return;
      var form = button.closest('[data-auth-form]');
      var seconds = Number(button.dataset.cooldown || 30);
      var original = button.dataset.defaultText || button.textContent;
      var left = seconds;
      button.disabled = true;
      Feedback.alert(form, 'info', button.dataset.resendMessage || 'A new code has been sent.');
      var timer = window.setInterval(function () {
        button.textContent = 'Resend in ' + left + 's';
        left -= 1;
        if (left < 0) {
          window.clearInterval(timer);
          state.resendTimers.delete(button);
          button.disabled = false;
          button.textContent = original;
        }
      }, 1000);
      state.resendTimers.set(button, timer);
    },

    demoAction: function (button) {
      var form = button.closest('[data-auth-form]');
      var label = button.dataset.authDemoAction || button.dataset.socialProvider || 'This action';
      Feedback.alert(form || document, 'info', label + ' is ready for backend integration.');
    },

    retry: function (button) {
      var scope = button.closest('.auth-card, [data-auth-form]') || document;
      var original = button.innerHTML;
      button.disabled = true;
      button.innerHTML = '<span class="auth-btn-spinner" aria-hidden="true"></span><span>' + (button.dataset.loadingText || 'Checking...') + '</span>';
      window.setTimeout(function () {
        Feedback.alert(scope, window.navigator.onLine ? 'success' : 'info', window.navigator.onLine ?
          'Connection restored. You can continue.' : 'Still offline. Please check your network and try again.');
        button.disabled = false;
        button.innerHTML = original;
      }, 900);
    },

    initForms: function () {
      qsa('[data-auth-form]').forEach(function (form) {
        var remember = qs('[data-auth-remember]', form);
        var email = qs('[data-auth-email]', form);
        var remembered = Auth.rememberedEmail();
        if (remember && email && remembered && !email.value) {
          email.value = remembered;
          remember.checked = true;
        }
        qsa('[data-password-strength]', form).forEach(Auth.updateStrength);
        var firstOtp = qs('[data-otp-input]', form);
        if (firstOtp) Auth.syncOtp(firstOtp);
      });
    },

    initClock: function () {
      var clock = qs('[data-lock-clock]');
      if (!clock) return;
      var update = function () {
        clock.textContent = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date());
      };
      update();
      window.setInterval(update, 30000);
    },

    initCountdowns: function () {
      qsa('[data-auth-countdown]').forEach(function (container) {
        var raw = container.dataset.targetDate;
        var target = raw ? new Date(raw) : new Date(Date.now() + 1814400000);
        var update = function () {
          var difference = Math.max(0, target.getTime() - Date.now());
          var values = {
            days: Math.floor(difference / 86400000),
            hours: Math.floor((difference % 86400000) / 3600000),
            minutes: Math.floor((difference % 3600000) / 60000),
            seconds: Math.floor((difference % 60000) / 1000)
          };
          Object.keys(values).forEach(function (key) {
            var node = qs('[data-countdown-' + key + ']', container);
            if (node) node.textContent = String(values[key]).padStart(2, '0');
          });
        };
        update();
        window.setInterval(update, 1000);
      });
    },

    init: function () {
      Auth.initForms();
      Auth.initClock();
      Auth.initCountdowns();
    }
  };

  /* ---------------------------------------------------------------------
     Bootstrap module
  --------------------------------------------------------------------- */
  var Bootstrap = {
    init: function () {
      if (!window.bootstrap) return;
      qsa('[data-bs-toggle="tooltip"]').forEach(function (element) {
        window.bootstrap.Tooltip.getOrCreateInstance(element);
      });
      qsa('[data-bs-toggle="popover"]').forEach(function (element) {
        window.bootstrap.Popover.getOrCreateInstance(element);
      });
    }
  };

  /* ---------------------------------------------------------------------
     Segregated click handlers
  --------------------------------------------------------------------- */
  var ClickHandlers = [
    {
      selector: '.theme-swatch[data-theme]',
      handle: function (button) { Theme.apply(button.dataset.theme, true); }
    },
    {
      selector: '#sidebarCollapse',
      handle: function () { Layout.toggleSidebar(); }
    },
    {
      selector: '#sidebarOverlay',
      handle: function () { Layout.closeSidebar(); }
    },
    {
      selector: '.js-logout',
      handle: function () {
        if (window.confirm('Are you sure you want to log out?')) window.location.href = templateUrl('auth/login.html');
      }
    },
    {
      selector: '[data-toast]',
      handle: function (button) { Feedback.toast(button.dataset.toast || 'Action completed'); }
    },
    {
      selector: '[data-password-toggle], #togglePassword',
      handle: function (button) { Auth.togglePassword(button); }
    },
    {
      selector: '[data-auth-resend]',
      handle: function (button) { Auth.resend(button); }
    },
    {
      selector: '[data-auth-demo-action], [data-social-provider]',
      preventDefault: true,
      handle: function (button) { Auth.demoAction(button); }
    },
    {
      selector: '[data-auth-retry]',
      handle: function (button) { Auth.retry(button); }
    },
    {
      selector: '#commandPaletteBackdrop',
      matchTargetOnly: true,
      handle: function () { CommandPalette.close(); }
    }
  ];

  var Events = {
    click: function (event) {
      for (var index = 0; index < ClickHandlers.length; index += 1) {
        var route = ClickHandlers[index];
        var target = route.matchTargetOnly ? (event.target.matches(route.selector) ? event.target : null) : event.target.closest(route.selector);
        if (!target) continue;
        if (route.preventDefault) event.preventDefault();
        route.handle(target, event);
        return;
      }
    },

    input: function (event) {
      var target = event.target;
      if (target.matches('#themeSearch')) Theme.filter(target.value);
      if (target.matches('#commandPaletteInput')) CommandPalette.render(target.value);
      if (target.matches('[data-password-strength]')) Auth.updateStrength(target);
      if (target.matches('[data-otp-input]')) {
        target.value = target.value.replace(/\D/g, '').slice(0, 1);
        var inputs = Auth.otpInputs(target);
        var index = inputs.indexOf(target);
        if (target.value && inputs[index + 1]) inputs[index + 1].focus();
        Auth.syncOtp(target);
      }
      if (target.matches('[data-validate]') && state.touchedFields.has(target)) Auth.validateField(target, true);
      if (target.id) {
        var form = target.closest('[data-auth-form]');
        if (form) qsa('[data-match="#' + CSS.escape(target.id) + '"]', form).forEach(function (confirm) {
          if (state.touchedFields.has(confirm)) Auth.validateField(confirm, true);
        });
      }
    },

    change: function (event) {
      var target = event.target;
      if (target.matches('[data-auth-theme-selector], [data-auth-theme-select], #themeSelector')) Theme.apply(target.value, true);
      if (target.matches('[data-validate]')) Auth.validateField(target, true);
    },

    focusout: function (event) {
      var target = event.target;
      if (!target.matches('[data-validate]')) return;
      state.touchedFields.add(target);
      Auth.validateField(target, true);
    },

    focusin: function (event) {
      if (event.target.matches('#globalSearchInput')) CommandPalette.open(event.target);
    },

    keydown: function (event) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        CommandPalette.open(document.activeElement);
        return;
      }
      if (event.key === 'Escape') {
        CommandPalette.close();
        Layout.closeSidebar();
        return;
      }
      if (!event.target.matches('[data-otp-input]')) return;
      var inputs = Auth.otpInputs(event.target);
      var index = inputs.indexOf(event.target);
      if (event.key === 'Backspace' && !event.target.value && inputs[index - 1]) inputs[index - 1].focus();
      if (event.key === 'ArrowLeft' && inputs[index - 1]) inputs[index - 1].focus();
      if (event.key === 'ArrowRight' && inputs[index + 1]) inputs[index + 1].focus();
    },

    paste: function (event) {
      if (!event.target.matches('[data-otp-input]')) return;
      event.preventDefault();
      var inputs = Auth.otpInputs(event.target);
      var text = (event.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, inputs.length);
      inputs.forEach(function (input, index) { input.value = text[index] || ''; });
      Auth.syncOtp(event.target);
      var focusIndex = Math.max(0, Math.min(text.length, inputs.length) - 1);
      if (inputs[focusIndex]) inputs[focusIndex].focus();
    },

    mouseover: function (event) {
      var button = event.target.closest('.theme-swatch[data-theme]');
      if (!button || (event.relatedTarget && button.contains(event.relatedTarget))) return;
      Theme.preview(button);
    },

    submit: function (event) {
      var form = event.target.closest('[data-auth-form]');
      if (form) Auth.submit(form, event);
    },

    resize: function () {
      window.cancelAnimationFrame(state.resizeFrame);
      state.resizeFrame = window.requestAnimationFrame(Layout.syncViewport);
    },

    scroll: function () {
      window.cancelAnimationFrame(state.scrollFrame);
      state.scrollFrame = window.requestAnimationFrame(Layout.updateHeader);
    }
  };

  /* ---------------------------------------------------------------------
     Initialization
  --------------------------------------------------------------------- */
  function init() {
    Theme.init();
    Layout.init();
    Auth.init();
    Bootstrap.init();

    document.addEventListener('click', Events.click);
    document.addEventListener('input', Events.input);
    document.addEventListener('change', Events.change);
    document.addEventListener('focusout', Events.focusout);
    document.addEventListener('focusin', Events.focusin);
    document.addEventListener('keydown', Events.keydown);
    document.addEventListener('paste', Events.paste);
    document.addEventListener('mouseover', Events.mouseover);
    document.addEventListener('submit', Events.submit);
    window.addEventListener('resize', Events.resize, { passive: true });
    window.addEventListener('scroll', Events.scroll, { passive: true });
  }

  window.Aether = Object.freeze({
    version: '1.2.0',
    theme: Object.freeze({ apply: Theme.apply, current: Theme.current, themes: THEMES }),
    toast: Feedback.toast,
    commandPalette: Object.freeze({ open: CommandPalette.open, close: CommandPalette.close }),
    auth: Object.freeze({ validateForm: Auth.validateForm, showAlert: Feedback.alert, setLoading: Auth.setLoading })
  });

  ready(init);
})(window, document);
