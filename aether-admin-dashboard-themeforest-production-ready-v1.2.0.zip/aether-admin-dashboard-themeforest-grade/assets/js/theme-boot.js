/* ========================================================================
   Aether Theme Boot
   Critical, dependency-free theme initialization. Load in <head> before CSS.
======================================================================== */
(function () {
  'use strict';

  var MODES = {
    light: 'light', dark: 'dark', obsidian: 'dark', vercel: 'dark', 'deep-space': 'dark', netflix: 'dark',
    microsoft: 'light', google: 'light', apple: 'light', vscode: 'dark', aws: 'dark', royal: 'light',
    spotify: 'dark', figma: 'light', slack: 'light', airbnb: 'light', uber: 'dark', sapphire: 'light',
    nebula: 'dark', aurora: 'light', phoenix: 'light', sakura: 'light', sunset: 'light', rose: 'light',
    slate: 'light', emerald: 'light', ocean: 'light', 'midnight-teal': 'dark', cyber: 'dark',
    'cosmic-aurora': 'dark'
  };

  try {
    var root = document.documentElement;
    var forced = root.getAttribute('data-force-theme');
    var fallback = root.getAttribute('data-default-theme') || root.getAttribute('data-theme') || 'light';
    var saved = localStorage.getItem('aether-theme') || localStorage.getItem('uttam-theme');
    var theme = MODES[forced] ? forced : (MODES[saved] ? saved : (MODES[fallback] ? fallback : 'light'));
    var mode = MODES[theme];

    root.setAttribute('data-theme', theme);
    root.setAttribute('data-bs-theme', mode);
    root.style.colorScheme = mode;
  } catch (_) {
    /* Storage can be unavailable in privacy-restricted contexts. */
  }
})();
