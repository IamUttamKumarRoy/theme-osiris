# SCSS Architecture

## Import order

`src/scss/theme.scss` is the single entry point. Its order is intentional:

1. **Abstracts** — functions, mixins, compile-time settings, runtime theme variables.
2. **Base** — reset and accessibility rules.
3. **Layout** — application shell and responsive structural regions.
4. **Components** — reusable interface components shared by multiple pages.
5. **Patterns** — larger domain patterns used across related page groups.
6. **Utilities** — helpers and animation definitions.
7. **Overrides** — final visual polish and boundary fixes.

## Where to edit

### Theme colors and design tokens

Edit:

```text
src/scss/abstracts/_variables.scss
```

Runtime theme palettes use CSS custom properties, so theme switching remains available without rebuilding JavaScript.

### Sidebar and shell

Edit:

```text
src/scss/layout/_shell.scss
src/scss/layout/_sidebar.scss
src/scss/layout/_header.scss
src/scss/layout/_content.scss
src/scss/layout/_footer.scss
```

Keep the final sidebar boundary rules in `src/scss/overrides/_sidebar-integrity.scss` unless you intentionally redesign the sidebar separator.

### Reusable UI components

Edit the relevant partial in `src/scss/components/`:

- `_buttons.scss`
- `_cards.scss`
- `_forms.scss`
- `_tables.scss`
- `_navigation.scss`
- `_feedback.scss`
- `_overlays.scss`
- `_media.scss`
- `_charts.scss`

### Domain-level page patterns

Use `src/scss/patterns/` for larger patterns that are shared within a feature family but are not universal components.

## Adding a new component

1. Create `src/scss/components/_component-name.scss`.
2. Add `@use "components/component-name";` to `src/scss/theme.scss` in the appropriate order.
3. Run `npm run build`.
4. Use the component classes in any HTML page without adding another stylesheet link.

## Generated files

The build creates:

```text
assets/css/theme.css
assets/css/theme.css.map
assets/css/theme.min.css
```

`theme.min.css` is the production file used by all pages. `theme.css` and its source map are included for debugging and buyer customization.
