# JavaScript Architecture

## Runtime files

Aether intentionally ships with only three JavaScript files in the browser runtime:

```text
assets/js/theme-boot.js
assets/vendor/bootstrap/js/bootstrap.bundle.min.js
assets/js/app.js
```

`theme-boot.js` is loaded synchronously in the document head before CSS to prevent theme flashing. Bootstrap remains isolated as a vendor file. All Aether functionality lives in the readable `app.js` bundle.

## Application modules

`app.js` is organized into clear internal modules:

- **Utilities** — selectors, storage guards, URL resolution, and small shared helpers
- **Theme** — theme persistence, swatches, selectors, filtering, metadata, and avatars
- **Layout** — desktop/mobile sidebar state, header scroll state, and active navigation
- **CommandPalette** — builds commands from sidebar links instead of duplicating a page registry
- **Feedback** — one toast implementation and shared authentication alerts
- **Auth** — validation, OTP, password strength, loading states, demo submission, and countdowns
- **Bootstrap** — conditional tooltip and popover initialization
- **Events** — delegated routing for click, input, change, focus, keyboard, paste, resize, and scroll

## Click event policy

Aether registers exactly one delegated document click listener:

```js
document.addEventListener('click', Events.click);
```

Individual click behaviors are segregated in the `ClickHandlers` route list. Each route owns one selector and one named action. This avoids repeated listeners across hundreds of controls and keeps click behavior easy to extend.

To add a new click action, add one route to `ClickHandlers`:

```js
{
  selector: '[data-example-action]',
  handle: function (button) {
    // Feature-specific behavior.
  }
}
```

Prefer `data-*` hooks over visual CSS classes. Do not add inline `onclick` attributes.

## DOM-conditional initialization

The common application bundle is safe on every page because modules query for their required markup and return when it is absent. Authentication code does not require a separate auth bundle, and dashboard code does not execute against missing dashboard elements.

## Public API

A small frozen API is available for integrations:

```js
Aether.version
Aether.theme.current()
Aether.theme.apply('dark')
Aether.toast('Saved successfully')
Aether.commandPalette.open()
Aether.commandPalette.close()
Aether.auth.validateForm(form)
```

## Third-party plugins

Load plugin JavaScript after Bootstrap and before `app.js` when the shared application bundle must detect it during initialization. When a plugin needs page-only configuration, use a small inline-free plugin initializer only after confirming that the total runtime file policy remains appropriate for your customized project.

## Validation

Run:

```bash
npm run validate
```

The validator checks:

- exactly three runtime JavaScript references per HTML page
- theme boot before theme CSS
- Bootstrap before `app.js`
- no inline scripts or inline event attributes
- no legacy JavaScript files
- exactly one delegated document click listener
- JavaScript syntax for both custom files and Bootstrap
- all local asset references and duplicate HTML IDs
