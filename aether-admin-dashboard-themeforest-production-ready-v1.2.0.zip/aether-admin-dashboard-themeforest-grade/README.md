# Aether Bootstrap 5 Admin Dashboard

Production-ready static HTML admin dashboard with Bootstrap 5.3.2, a component-based SCSS architecture, a consolidated JavaScript runtime, multiple visual themes, responsive layouts, authentication pages, dashboards, ecommerce, CRM, forms, tables, charts, documentation, and application pages.

## Quick start

```bash
npm install
npm run build
```

Open `index.html` or run a local server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Development commands

```bash
npm run build:css   # Compile, prefix, minify, and generate the CSS source map
npm run watch:css   # Watch SCSS source during development
npm run validate    # Validate HTML, CSS, JavaScript, assets, IDs, and script order
npm run build       # Build CSS and run the complete validation suite
```

## CSS workflow

Edit files inside `src/scss/`. Do not edit `assets/css/theme.css`, `assets/css/theme.min.css`, or `assets/css/theme.css.map` directly because they are generated files.

Every HTML page loads:

1. `assets/vendor/bootstrap-icons/bootstrap-icons.css`
2. `assets/vendor/bootstrap/css/bootstrap.min.css`
3. `assets/css/theme.min.css`

The original page-specific CSS bundles have been consolidated into reusable SCSS components and cross-page patterns.

## JavaScript workflow

Every page uses exactly three runtime JavaScript files:

1. `assets/js/theme-boot.js` — critical theme initialization in the document head
2. `assets/vendor/bootstrap/js/bootstrap.bundle.min.js` — isolated Bootstrap vendor runtime
3. `assets/js/app.js` — all Aether layout, theme, command palette, feedback, authentication, and demo interactions

`app.js` uses one delegated document click listener with separate named handlers for each action. Modules initialize only when matching markup exists, so the same bundle safely serves all 210 pages. Do not add page-specific click scripts unless a third-party plugin genuinely requires an isolated initializer.

## Main folders

```text
src/scss/
├── abstracts/   # Sass functions, mixins, and theme tokens
├── base/        # Reset and accessibility foundations
├── layout/      # Shell, sidebar, header, content, footer
├── components/  # Buttons, cards, forms, tables, feedback, overlays, media, charts
├── patterns/    # Authentication, commerce, communication, productivity, docs
├── utilities/   # Helpers and animations
├── overrides/   # Final polish and sidebar integrity fixes
└── theme.scss   # Main entry file

assets/js/
├── theme-boot.js # Critical pre-render theme setup
└── app.js        # Consolidated application runtime
```

See `SCSS-ARCHITECTURE.md`, `JS-ARCHITECTURE.md`, and `PRODUCTION-AUDIT.md` for customization and release guidance.
